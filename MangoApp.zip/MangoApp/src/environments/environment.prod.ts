export const environment = {
  production: true,
  baseUrl: 'https://schmersalprojectapi.azurewebsites.net',
  userMangBaseUrl: "https://schuserservice.azurewebsites.net",
  fourEyeQualityBaseUrl: "https://schriskassessmentdev.azurewebsites.net"
};
