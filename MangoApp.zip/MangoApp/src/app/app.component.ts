import { Component, EventEmitter, Injectable, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { LanguageSupportService } from './services/language-support.service';
import { LocalSettingsService } from './services/local-settings/local-settings.service';
import { EventTypes, OidcSecurityService, PublicEventsService } from 'angular-auth-oidc-client';
import { Router } from '@angular/router';
import { isNotBlank, isNotNullAndUndefined } from './utilities/utils';
import { AuthCookieManagerService } from './services/auth-cookie-manager/auth-cookie-manager.service';
import { authCookieKey } from './utilities/constant';
import { UserAuthService } from './services/user-auth/user-auth.service';
import { filter } from 'rxjs/operators';
import { NavController, Platform } from '@ionic/angular';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent implements OnInit {
  showLoader = false;
  selectedLanguage: string;
  constructor(private translate: TranslateService,
    public language: LanguageSupportService,
    public localSettingsSrv: LocalSettingsService,
    private loader: LoaderService,
    private oidcSecurityService: OidcSecurityService,
    public publicEventsService: PublicEventsService,
    private router: Router,
    public authCookieManagerService: AuthCookieManagerService,
    public userAuthService: UserAuthService,
    private nav: NavController,
    private platform: Platform,
  ) {
    let langPref = localSettingsSrv.getLanguagePreference('ln_pref');
    translate.setDefaultLang(langPref ? langPref : 'en');
    loader
      .getLoaderStats()
      .subscribe((res: boolean) => (this.showLoader = res));
  }

  ngOnInit() {
    this.platform.ready().then(() => {
      this.initializeAuth();
    });
  }

  initializeAuth() {
    // publicEvent will be called when refrersh token or silent token will be refreshed automatically
    this.publicEventsService
      .registerForEvents()
      .pipe(filter((notification) => notification.type === EventTypes.SilentRenewStarted))
      .subscribe((value) => {
        const authInfo = this.userAuthService.getAuthenticationInfo();
        authInfo && this.authCookieManagerService.write(authCookieKey, authInfo, true);
      });

    //checking user authentcation
    this.oidcSecurityService.checkAuth().subscribe(({ isAuthenticated, userData, accessToken, idToken }) => {
      if (isAuthenticated && isNotBlank(accessToken) && isNotNullAndUndefined(accessToken)) {
        const authInfo = this.userAuthService.getAuthenticationInfo();
        authInfo && this.authCookieManagerService.write(authCookieKey, authInfo);
        //this.router.navigate(['/dashboard']);
        this.nav.navigateRoot('/dashboard');
      } else {
        const cookieInfo = this.authCookieManagerService.read(authCookieKey);
        if (cookieInfo && isNotBlank(cookieInfo.cookie_expiry_time) && isNotNullAndUndefined(cookieInfo.cookie_expiry_time) &&
          isNotBlank(cookieInfo.access_token) && isNotNullAndUndefined(cookieInfo.access_token)) this.userAuthService.login()
        else this.nav.navigateRoot('/login');
      }
    });
  }
}

@Injectable({
  providedIn: 'root',
})
export class LoaderService {
  private apiCounts = 0;
  private loaderSubject = new EventEmitter();
  getLoaderStats() {
    return this.loaderSubject.asObservable();
  }
  showLoader() {
    this.apiCounts++;
    this.loaderSubject.emit(true);
  }
  hideLoader() {
    this.apiCounts--;
    if (this.apiCounts < 1) {
      this.loaderSubject.emit(false);
    }
  }
}
