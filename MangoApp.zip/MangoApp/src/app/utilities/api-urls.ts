import { environment } from 'src/environments/environment';
const domain = '';
export const ApiUrlss = {
  getProjectWidget: `${domain}/path`,
};
export class ApiUrls {
  //public static getProjectWidget = environment.baseUrl + '/demofe/projects';
  public static getProjectWidget =
    environment.baseUrl + '/api/projectservice/projects';
  public static getProjectDetail =
    environment.baseUrl + '/api/projectservice/project';
  // public static getTaskManagers = environment.baseUrl + '/tasks';
  // public static getTaskManagers = environment.baseUrl + '/api/taskmanager/get';
  public static getTaskManagers = `https://schtaskmanagerapi.azurewebsites.net/api/taskmanager/tasks`;
  public static getProjectManagementEffortMetrics =
    environment.baseUrl + '/api/projectservice/effortsmetrics';
  public static getProjectDetailServiceOrder =
    environment.baseUrl + '/api/projectservice/projectorders';
  public static getProjectDetailServiceListBasedonServiceOrderAndType =
    environment.baseUrl + '/api/projectservice/service';
  public static getProjectDetailMachineListBasedonServiceOrderAndType =
    environment.baseUrl + '/api/projectservice/machines';
  public static getProjectDetailMachinesListBasedonServiceOrderAndType =
    `https://schprojectdev.azurewebsites.net/api/Project/machines`;
  public static updateLogActualHours = `https://schprojectdev.azurewebsites.net/api/Project/addactualhours`;
  public static getSearchedCustomer = `https://schcustomerapi.azurewebsites.net/api/Customer/search`;
  public static getCustomerContactInfo = `https://schcustomerapi.azurewebsites.net/api/Customer/searchbyid`;
  public static createProject =
    environment.baseUrl + '/api/projectservice/create';

  public static createOffer =
    environment.offerBaseURL + 'Offer/create';
  // 'https://projectapi20220102135438.azurewebsites.net/api/Project/project'
  public static editProject =
    environment.baseUrl + '/api/projectservice/update';

  public static getOrderManagementOrderTrackerDeatils =
    'https://schmersalorderapiservice.azurewebsites.net/api/orderservice/orders';
  public static getOrderManagementOrderDeatil =
    'https://schmersalorderapiservice.azurewebsites.net/api/orderservice/orders';

  public static getOrderManagementEffortMetrics =
    'https://schmersalorderapiservice.azurewebsites.net/api/orderservice/effortsmetrics';

  //Offer Management API END
  public static getOfferManagementDetails =
    // 'https://schofferstatusapi.azurewebsites.net/api/OfferStatusService/offermanagementdetails';
    environment.offerBaseURL + 'Offer/';

  public static viewOfferDetailsById =
    environment.offerBaseURL + 'Offer/offerdetails/';

  public static viewOfferServiceDetails =
    environment.offerBaseURL + 'Offer/Offerservicedetails/';

  public static getOfferMachineDetails =
    environment.offerBaseURL + 'Offer/Offermachinedetails/';

  public static deleteOffer =
    environment.offerBaseURL + 'Offer/deleteoffer';

  public static deleteOfferservice =
    environment.offerBaseURL + 'Offer/deleteofferservice';
  public static getOfferStatusService =
    environment.offerBaseURL + 'Offer/Get';

  public static offerEffortmetrics =
    environment.offerBaseURL + 'Offer/effortmetrics';

  public static searchServiceCustomerName =
    'https://schcustomerapi.azurewebsites.net/api/Customer/search/';

  public static offerCustomerInfo =
    'https://schcustomerapi.azurewebsites.net/api/Customer/searchbyid/';

  public static customerProjectIdByCustName =
    environment.offerBaseURL + 'Offer/getprojectsbycustomerid/';

  // public static getmastermachinedetails =
  //   environment.offerBaseURL + 'mastermachineservice/getmastermachinedetails';

  public static searchMachineMaster =
    environment.offerBaseURL + 'MasterMachine/SearchMasterMachines';

  //Offer Management API END

  //bucket lists
  public static bucketLists =
    environment.baseUrl + '/api/BucketService/buckets';
  public static createBucket =
    environment.baseUrl + '/api/BucketService/bucket';

  //upload Functionlaity 
  public static uploadLibrary = 'https://offerapiservicedev.azurewebsites.net/api/MasterMachine/FileUploadForLibraryManagent';

  public static getNotification = 'https://schsignalrnotifications.azurewebsites.net/notify'

  //upload Machine Details Api
  public static uploadMasterData =
    // 'https://schmersalapiservice.azurewebsites.net/api/MasterMachine/MasterMachineFileUploadJson';
    'https://offerapiservicedev.azurewebsites.net/api/MasterMachine/MasterMachineFileUploadJson'

  // RoadMap
  public static uploadRoadMap = environment.offerBaseURL + 'Library/RoadMap';

  //ControlMeasure
  public static uploadControl = environment.offerBaseURL + 'Library/CounterMeasure';
  public static getConsoleData =
    environment.offerBaseURL + 'Library/CounterMeasure/'


  // Intial Measure
  public static IntialHazard = environment.offerBaseURL + 'Library/InitialHazard';
  public static getInitialMeasure = environment.offerBaseURL + 'Library/InitialHazard/'

  //Bookmark
  public static onAddBookmark = environment.offerBaseURL + 'Library/library/';

  public static onRemoveBookmark = environment.offerBaseURL + 'Library/deletebookmark';

  //MachineLibrary List 
  public static getMachineLibrary =
    environment.offerBaseURL + 'MasterMachine/GetMasterMachineDetails';

  public static getRoadMapLibrary =
    environment.offerBaseURL + 'Library/RoadMap';

  public static getSelectedBookmarkData =
    environment.offerBaseURL + 'Library/library/';

     //get Opportunities 
  public static getOpportunitiesDataList = environment.offerBaseURL + 'Opportunity'



  //RA APIS LIST
  public static getRoadmapSteps = environment.riskAssessmentBaseUrl + 'RiskAssessment/roadmaps'
  public static getRoadmapList = environment.riskAssessmentBaseUrl + 'RiskAssessment/roadmaps'
  public static machineLimits = environment.riskAssessmentBaseUrl + 'RiskAssessment/machinelimits'
  public static configureRoadmap = environment.riskAssessmentBaseUrl + 'RiskAssessment/configureroadmap'
  public static addCustomRoadmap = environment.offerBaseURL + 'Library/customroadmap'
  public static addCustomsection = environment.offerBaseURL + 'Library/customsection'
  public static addCustomSubSection = environment.offerBaseURL + 'Library/CustomSubSection'
  public static getMachineModesList = environment.riskAssessmentBaseUrl + 'RiskAssessment/machinemodes'
  public static getLifeCyclePhasesList = environment.riskAssessmentBaseUrl + 'RiskAssessment/lifecyclephases'
  public static getConfiguredroadmaps = environment.riskAssessmentBaseUrl + 'RiskAssessment/'
  public static gethazardTypeList = environment.riskAssessmentBaseUrl + 'RiskAssessment/hazardtypes'
  public static gethazardSourceList = environment.riskAssessmentBaseUrl + 'RiskAssessment/hazardsources'
  public static gethazardConsequencesList = environment.riskAssessmentBaseUrl + 'RiskAssessment/hazardconsequences'
  public static getInitialHazardsList = environment.riskAssessmentBaseUrl + 'RiskAssessment/initialhazards'
  public static getCounterMeasuresList = environment.riskAssessmentBaseUrl + 'RiskAssessment/countermeasures'
  public static extendRoadmap = environment.riskAssessmentBaseUrl + 'RiskAssessment/extendroadmap'

  // User Managment Console
  public static getUsers = environment.userMangBaseUrl + '/api/User/users';
  public static getRoles = environment.userMangBaseUrl + '/api/role/roles';
  public static getRoleAssignments = environment.userMangBaseUrl + '/api/userroleassociation/getuserswithrole';
  public static addRoleToUsers = environment.userMangBaseUrl + '//api/userroleassociation/addroletousers';
  public static getGroupsWithCount = environment.userMangBaseUrl + '/api/group/groupwithusercount';
  public static getSearchedUserInfoToAdd = environment.userMangBaseUrl + '/api/User/adusers';
  public static addNewUsersToAd = environment.userMangBaseUrl + '/api/User/addusertoad';
  public static addNewRole = environment.userMangBaseUrl + '/api/role';
  public static createGroupAndAddusers = environment.userMangBaseUrl + '/api/ugassociation';

  //Four Eye Quality
  public static getFourEyeQualityPerformInfo = environment.fourEyeQualityBaseUrl + '/api/FourEyesQuality';

 
}
