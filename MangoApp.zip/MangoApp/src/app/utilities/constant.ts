export const authClientId = "angular-client";
export const authIdpAuthorityUrl = "https://schidentityserverdev.azurewebsites.net";
export const authCookieKey = 'bluePrint_auth_cookie_key';