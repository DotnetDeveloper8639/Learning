import { environment } from 'src/environments/environment';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { LoadingController } from '@ionic/angular';
import { LoaderService } from '../app.component';
import { ApiUrls } from '../utilities/api-urls';
import { UserAuthService } from './user-auth/user-auth.service';
@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  private loading: any;
  // https://schcustomerapi.azurewebsites.net/api/Customer/search/j
  noLoaderApis = [
    ApiUrls.searchServiceCustomerName,
    // ApiUrls.gethazardSourceList,
    // ApiUrls.gethazardTypeList
  ];

  constructor(
    public loadingController: LoadingController,
    private loader: LoaderService,
    public userAuthService: UserAuthService
  ) { }

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const token = this.userAuthService.getAccessToken();
    if (token) {
      req = req.clone({
        setHeaders: {
          'Authorization': `Bearer ${token}`,
        }
      });
    }
    const hadLoader = this.noLoaderApis.every((each) =>
      req.url.startsWith(each)
    );
    console.log(req.url, this.noLoaderApis, hadLoader);
    if (!hadLoader) {
      this.loader.showLoader();
    }
    if (req.url.startsWith(environment.baseUrl) && req.url.startsWith(environment.offerBaseURL)) {
      // this.loading = await this.loaderPresent();

      req = req.clone({
        setHeaders: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json;',
        },
      });
    }
    // if (this.loading) {
    //   this.loading.dismiss();
    // }
    return next.handle(req).pipe(
      finalize(() => {
        if (!hadLoader) {
          this.loader.hideLoader();
        }
      })
    );
  }

  public async loaderPresent(): Promise<any> {
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-loader-class',
      message: 'Please wait ...',
      backdropDismiss: true,
    });

    await loading.present();

    return loading;
  }
}
