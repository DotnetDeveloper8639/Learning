import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { ApiUrls } from 'src/app/utilities/api-urls';

@Injectable({
  providedIn: 'root',
})
export class BackendCallService {
  constructor(public http: HttpClient) { }

  getProjectLists() {
    const _self = this;
    let urlParams = new HttpParams();
    return _self.http
      .get<any>(`${ApiUrls.getProjectWidget}`, { params: urlParams })
      .toPromise();
  }

  getTaskManagerData() {
    const _self = this;
    let urlParams = new HttpParams();
    // return _self.http
    //   .get<any>(`${ApiUrls.getTaskManagers}`, { params: urlParams })
    //   .toPromise();
    return _self.http
      .get<any>(`${ApiUrls.getTaskManagers}`, { params: urlParams })
      .toPromise();
  }

  getprojectDetail(projectId) {
    const _self = this;
    let urlParams = new HttpParams();
    return _self.http
      .get<any>(`${ApiUrls.getProjectDetail}/${projectId}`, {
        params: urlParams,
      })
      .toPromise();
  }

  getProjecDetailOrderService(projectId) {
    let urlParams = new HttpParams();
    return this.http
      .get<any>(`${ApiUrls.getProjectDetailServiceOrder}/${projectId}`, {
        params: urlParams,
      })
      .toPromise();
  }

  getProjectDetailServiceListsInfo(orderId, serviceType, projectId) {
    let urlParams = new HttpParams();
    return this.http
      .get<any>(
        `${ApiUrls.getProjectDetailServiceListBasedonServiceOrderAndType}/${orderId}/${serviceType}/${projectId}`,
        {
          params: urlParams,
        }
      )
      .toPromise();
  }

  getProjectDetailMachineListsInfo(orderId, serviceType, projectId) {
    let urlParams = new HttpParams();
    return this.http
      .get<any>(
        // `${ApiUrls.getProjectDetailMachineListBasedonServiceOrderAndType}/${orderId}/${serviceType}/${projectId}`,
        `${ApiUrls.getProjectDetailMachinesListBasedonServiceOrderAndType}/${orderId}/${serviceType}/${projectId}`,
        {
          params: urlParams,
        }
      )
      .toPromise();
  }

  updateLogActualHoursInfo(logActualHoursInfo) {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) }
    return this.http
      .post<any>(ApiUrls.updateLogActualHours, JSON.stringify(logActualHoursInfo), httpOptions)
      .toPromise();
  }

  getOfferManagementDetails() {
    return this.http.get(`${ApiUrls.getOfferManagementDetails}`);
  }

  viewOfferDetailsById(project_id, offer_id) {
    return this.http.get(
      `${ApiUrls.viewOfferDetailsById}${project_id},${offer_id}`
    );
  }

  viewOfferServiceDetails(project_id, offer_id, service_type) {
    return this.http.get(
      `${ApiUrls.viewOfferServiceDetails}${project_id},${offer_id},${service_type}`
    );
  }

  getOfferMachineDetails(project_id, offer_id, service_id) {
    return this.http.get(
      `${ApiUrls.getOfferMachineDetails}${project_id},${offer_id},${service_id}`
    );
  }
  getProjectEffortMetrics() {
    const _self = this;
    let urlParams = new HttpParams();
    return _self.http
      .get<any>(`${ApiUrls.getProjectManagementEffortMetrics}`, {
        params: urlParams,
      })
      .toPromise();
  }

  getProjectSearchedCustomer(customerName) {
    let urlParams = new HttpParams();
    return this.http
      .get<any>(`${ApiUrls.getSearchedCustomer}/${customerName}`, {
        params: urlParams,
      })
      .toPromise();
  }

  getProjecManagemetContactInfo(erp_Customer_Id) {
    let urlParams = new HttpParams();
    return this.http
      .get<any>(`${ApiUrls.getCustomerContactInfo}/${erp_Customer_Id}`, {
        params: urlParams,
      })
      .toPromise();
  }

  createProject(projectInfo) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };
    const body = JSON.stringify(projectInfo);
    return this.http
      .post<any>(ApiUrls.createProject, body, httpOptions)
      .toPromise();
  }

  editProject(projectInfo) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };
    return this.http
      .put<any>(ApiUrls.editProject, JSON.stringify(projectInfo), httpOptions)
      .toPromise();
  }

  createOffer(data: any) {
    return this.http.post(`${ApiUrls.createOffer}`, data);
  }

  getOrderManagementEffortmetrics() {
    const _self = this;
    let urlParams = new HttpParams();
    return _self.http
      .get<any>(`${ApiUrls.getOrderManagementEffortMetrics}`, {
        params: urlParams,
      })
      .toPromise();
  }

  getOrderManagementDetails() {
    const _self = this;
    let urlParams = new HttpParams();
    return _self.http
      .get<any>(`${ApiUrls.getOrderManagementOrderTrackerDeatils}`, {
        params: urlParams,
      })
      .toPromise();
  }

  getOrderDetail(id) {
    const _self = this;
    let urlParams = new HttpParams();
    return _self.http
      .get<any>(`${ApiUrls.getOrderManagementOrderDeatil}/${id}`, {
        params: urlParams,
      })
      .toPromise();
  }

  deleteOffer(data: any) {
    return this.http.post(`${ApiUrls.deleteOffer}`, data);
  }

  deleteOfferService(data: any) {
    return this.http.post(`${ApiUrls.deleteOfferservice}`, data);
  }

  getOfferStatusService() {
    return this.http.get(`${ApiUrls.getOfferStatusService}`);
  }

  offerEffortmetrics() {
    return this.http.get(
      `${ApiUrls.offerEffortmetrics}`
      // https://schmersalapiservice.azurewebsites.net/api/OfferStatusService/effortmetrics
    );
  }

  searchServiceCustomerName(ev) {
    let urlParams = new HttpParams(); //https://schcustomerapi.azurewebsites.net/api/Customer/search/j
    return this.http.get(`${ApiUrls.searchServiceCustomerName}${ev}`, {
      params: urlParams,
    });
  }

  offerCustomerInfoSearchByErpId(erp_Customer_Id) {
    let urlParams = new HttpParams();
    return this.http.get(`${ApiUrls.offerCustomerInfo}${erp_Customer_Id}`, {
      params: urlParams,
    });
  }

  // customerProjectIdByEmail(data) {
  //   let urlParams = new HttpParams();
  //   return this.http.get(
  //     `https://schofferstatusapi.azurewebsites.net/api/OfferStatusService/getprojectsids/${data}`,
  //     {
  //       params: urlParams,
  //     }
  //   );
  // }

  customerProjectIdByCustName(data) {
    return this.http.get(`${ApiUrls.customerProjectIdByCustName}${data}`);
  }
  // getmastermachinedetails() {
  //   return this.http.get(`${ApiUrls.getmastermachinedetails}`);
  // }

  getBucketLists(projectId, orderId, serviceType) {
    let urlParams = new HttpParams().set('project_id', projectId).set('order_id', orderId).set('service_type', serviceType)
    return this.http
      .get<any>(`${ApiUrls.bucketLists}?`, {
        params: urlParams,
      })
      .toPromise();
  }

  createNewBucket(bucketInfo) {
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
    return this.http
      .post<any>(ApiUrls.createBucket, JSON.stringify(bucketInfo), httpOptions)
      .toPromise();
  }

  editBuckets(bucketInfo) {
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
    return this.http
      .put<any>(ApiUrls.bucketLists, JSON.stringify(bucketInfo), httpOptions)
      .toPromise();
  }

  deleteBuckets(bucketInfo) {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    return this.http
      .delete<any>(ApiUrls.bucketLists, { headers, body: JSON.stringify(bucketInfo) })
      .toPromise();
  }

  uploadDocument(data: any) {
    return this.http.post(`${ApiUrls.uploadLibrary}`, data);
  }

  getNotification() {
    return this.http.get(`${ApiUrls.getNotification}`);
  }

  uploadMasterData(data: any) {
    return this.http.post(`${ApiUrls.uploadMasterData}`, data);
  }

  uploadRoadMapData(data) {
    return this.http.post(`${ApiUrls.uploadRoadMap}`, data);
  }

  uploadControlMeasure(data) {
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
    return this.http.post(`${ApiUrls.uploadControl}`, data, httpOptions);
  }

  uploadIntialHazard(data) {
    return this.http.post(`${ApiUrls.IntialHazard}`, data);
  }

  searchMachineMaster(data: any) {
    return this.http.get(`${ApiUrls.searchMachineMaster}/${data}`);
  }

  getMasterLibrary() {
    return this.http.get(`${ApiUrls.getMachineLibrary}`);
  }

  getRoadMapDetails() {
    return this.http.get(`${ApiUrls.getRoadMapLibrary}`)
  }

  getRoadmapSteps(roadmapId, userId, serviceMachineId) {
    // return this.http.get(`${ApiUrls.getRoadmapSteps+"/4afed9b0-4b2b-4256-83ce-15a1b19c8e01"}`);
    return this.http.get(`${ApiUrls.getRoadmapSteps}/${roadmapId}/${userId}/${serviceMachineId}`);
  }

  getRoadmapList() {
    return this.http.get(`${ApiUrls.getRoadmapList}`);
  }

  getMachineModesList() {
    return this.http.get(`${ApiUrls.getMachineModesList}`);
  }

  getLifeCyclePhasesList() {
    return this.http.get(`${ApiUrls.getLifeCyclePhasesList}`);
  }

  configureRoadmap(data) {
    return this.http.post(`${ApiUrls.configureRoadmap}`, data);
  }

  getConfiguredroadmaps(id) {
    return this.http.get(`${ApiUrls.getConfiguredroadmaps}${id}/configuredroadmaps`);
  }

  addCustomRoadmap(data) {
    return this.http.post(`${ApiUrls.addCustomRoadmap}`, data);
  }

  addCustomsection(data) {
    return this.http.post(`${ApiUrls.addCustomsection}`, data);
  }

  addCustomSubSection(data) {
    return this.http.post(`${ApiUrls.addCustomSubSection}`, data);
  }

  machineLimits(data) {
    return this.http.post(`${ApiUrls.machineLimits}`, data);
  }

  gethazardTypeList() {
    return this.http.get(`${ApiUrls.gethazardTypeList}`)
  }

  gethazardSourceList() {
    return this.http.get(`${ApiUrls.gethazardSourceList}`)
  }

  gethazardConsequencesList() {
    return this.http.get(`${ApiUrls.gethazardConsequencesList}`)
  }

  getInitialHazardsList() {
    return this.http.get(`${ApiUrls.getInitialHazardsList}`)
  }

  getCounterMeasuresList() {
    return this.http.get(`${ApiUrls.getCounterMeasuresList}`)
  }

  extendRoadmap(data) {
    return this.http.post(`${ApiUrls.extendRoadmap}`, data);
  }

  createBookmark(userId, data) {
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
    return this.http.post<any>(ApiUrls.onAddBookmark + userId, JSON.stringify(data), httpOptions)
      .toPromise();
  }

  getBookmarDataDetails(userId) {
    return this.http.get(`${ApiUrls.getSelectedBookmarkData + userId}`)
  }

  getConsoleLibrary(userId) {
    return this.http.get(`${ApiUrls.getConsoleData + userId}`)
  }

  getInitialMeasure(userId) {
    return this.http.get(`${ApiUrls.getInitialMeasure + userId}`)
  }

  deleteBookmarkData(id) {
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
    return this.http.post<any>(ApiUrls.onRemoveBookmark, id, httpOptions)
      .toPromise();
  }

  getOpportunitiesData(){
    return this.http.get(`${ApiUrls.getOpportunitiesDataList}`)
  }

  // User Management Console
  getAllUsers() {
    const _self = this;
    let urlParams = new HttpParams();
    return _self.http
      .get<any>(`${ApiUrls.getUsers}`, {
        params: urlParams,
      })
      .toPromise();
  }

  getAllRoles() {
    const _self = this;
    let urlParams = new HttpParams();
    return _self.http
      .get<any>(`${ApiUrls.getRoles}`, {
        params: urlParams,
      })
      .toPromise();
  }

  getAllRoleAssignments() {
    const _self = this;
    let urlParams = new HttpParams();
    return _self.http
      .get<any>(`${ApiUrls.getRoleAssignments}`, {
        params: urlParams,
      })
      .toPromise();
  }

  getAllGroupsWithCount() {
    const _self = this;
    let urlParams = new HttpParams();
    return _self.http
      .get<any>(`${ApiUrls.getGroupsWithCount}`, {
        params: urlParams,
      })
      .toPromise();
  }

  searchUserInfoToAdd() {
    const _self = this;
    let urlParams = new HttpParams();
    return _self.http
      .get<any>(`${ApiUrls.getSearchedUserInfoToAdd}`, {
        params: urlParams,
      })
      .toPromise();
  }

  addNewUsersToAd(userLists) {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) }
    return this.http
      .post<any>(ApiUrls.addNewUsersToAd, JSON.stringify(userLists), httpOptions)
      .toPromise();
  }

  addNewRole(newRole) {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) }
    return this.http
      .post<any>(ApiUrls.addNewRole, JSON.stringify(newRole), httpOptions)
      .toPromise();
  }

  assignRoleToUsers(roleAssignmentInfo) {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) }
    return this.http
      .post<any>(ApiUrls.addRoleToUsers, JSON.stringify(roleAssignmentInfo), httpOptions)
      .toPromise();
  }

  createGroupAndAddUsers(groupLists) {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) }
    return this.http
      .post<any>(ApiUrls.createGroupAndAddusers, JSON.stringify(groupLists), httpOptions)
      .toPromise();
  }

  getFourEyeQualityPerformInfo(servicemachineid) {
    let urlParams = new HttpParams();
    return this.http.get(`${ApiUrls.getFourEyeQualityPerformInfo}/${servicemachineid}/performrequst4eyesquality`,
      { params: urlParams }).toPromise();
  }

  getFourEyeQualityRoadMapLists(servicemachineid) {
    let urlParams = new HttpParams();
    return this.http.get(`${ApiUrls.getFourEyeQualityPerformInfo}/${servicemachineid}/4eyesquealityroadmaps`,
      { params: urlParams }).toPromise();
  }

  getFourEyeQualityHazardCheckListsInfo(hazardmachineid) {
    let urlParams = new HttpParams();
    return this.http.get(`${ApiUrls.getFourEyeQualityPerformInfo}/${hazardmachineid}/hazarddetails`,
      { params: urlParams }).toPromise();
  }

}
