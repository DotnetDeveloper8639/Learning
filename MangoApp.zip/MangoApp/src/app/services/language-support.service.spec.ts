import { TestBed } from '@angular/core/testing';

import { LanguageSupportService } from './language-support.service';

describe('LanguageSupportService', () => {
  let service: LanguageSupportService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LanguageSupportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
