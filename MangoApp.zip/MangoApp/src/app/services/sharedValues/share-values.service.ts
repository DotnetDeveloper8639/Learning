import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import {
  isNotEmptyArray,
  isNotNullAndUndefined,
  isObjectEmpty,
} from 'src/app/utilities/utils';
import { ToastController } from '@ionic/angular';
import { ModalController } from '@ionic/angular';
import { AlertModalPage } from 'src/app/components/alert-modal/alert-modal.page';
import * as moment from 'moment';
import { UserAuthService } from '../user-auth/user-auth.service';
@Injectable({
  providedIn: 'root',
})
export class ShareValuesService {
  sideNavChangeData: string = 'dash';
  extendedRoadMapPayload: any = {}
  machineList = [];
  listOfServices: any = [];
  offer_id;
  project_id;
  edit_flow_temp_Encrypted_project_id: string
  customers: any = {};
  customersInfo = new BehaviorSubject(null);
  customersInfoData;
  eachSelectedContactDetails: any;
  offerDetailsContact_id: any;
  isFourEyeQualityCheckRequested: boolean = false;
  selectedRoadmapsList = [];
  private roadMapStatusLists = [];
  machineModeList = []
  public dashboardCustomizationValueSubmitted: BehaviorSubject<{}> =
    new BehaviorSubject<{}>({
      isValueChanged: true,
    });
  bucketLists = [
    { title: 'Welding Machines' },
    { title: 'Press Machines' },
    { title: 'Lathe Machines' },
    { title: 'Cutting Machines' },
    { title: 'Hydraulic Machines' },
    { title: 'Pneumatic Machines' }
  ]


  fedExStatusStepperData = [
    { name: 'Opportunity Created', isdone: true },
    { name: 'Quotation Created', isdone: false },
    { name: 'Quotation Approved', isdone: false },
    { name: 'Quotation Sent', isdone: false },
    { name: 'PO Received', isdone: false },
    { name: 'Order Released', isdone: false },
    { name: 'Order Planning', isdone: false },
    { name: 'Order Execution', isdone: false },
    { name: 'Quality Check', isdone: false },
    { name: 'RA Report  Generated', isdone: false }
  ]

  constructor(public toastController: ToastController, public modalController: ModalController, public userAuth: UserAuthService,) { }

  updateDashboardCustomizationSubject(data): void {
    this.dashboardCustomizationValueSubmitted.next(data);
  }

  getDashboardCustomizationSubjectData(): Observable<{}> {
    return this.dashboardCustomizationValueSubmitted;
  }

  setRoadMapStatusLists(lists = []) {
    this.roadMapStatusLists = lists
  }

  getRoadMapStatusLists() {
    return this.roadMapStatusLists
  }

  initializaCreateBucketList(bucketName, bucketId, projectId, orderId, machineLists = []) {
    let body = {
      "bucket_Name": bucketName,
      "bucket_Id": bucketId,
      "project_Id": projectId,
      "order_Id": orderId,
      "machine_Id": [],
      //"bucket_Id": "",
      //"offer_Id": "",
      //"service_Id": "",
      //"user_Id": ""
    }
    if (!bucketName) delete (body.bucket_Name)
    if (!bucketId) delete (body.bucket_Id)
    if (isNotEmptyArray(machineLists)) body.machine_Id = machineLists
    return body;
  }

  uploadList() {
    let body = {

      //"bucket_Id": "",
      //"offer_Id": "",
      //"service_Id": "",
      //"user_Id": ""
    }
    // body.machine_Id = machineLists
    return body;
  }
  initialiizeEditBucketInfo(bucketLists) {
    let bucket = [];
    if (isNotEmptyArray(bucketLists)) {
      bucketLists.forEach(_bl => {
        let body = {
          "bucket_Id": _bl.bucketId,
          "bucket_Name": _bl.newTitle || _bl.title,
        }
        bucket.push(body);
      })
    }
    return bucket;
  }

  initializeDeleteBucketInfo(bucketLists) {
    let bucket = [];
    if (isNotEmptyArray(bucketLists)) {
      bucketLists.forEach(_bl => {
        bucket.push(_bl.bucket_Id);
      })
    }
    return bucket;
  }

  convertToUtcFormat(date) {
    return moment.utc(moment(date)).format()
  }

  initializeCreateProject(projectInfo, customerInfo) {
    let body = {
      project_Id: null,
      erp_project_Id: null,
      project_Name: projectInfo.name,
      description: projectInfo.textDescription,
      Start_Date: projectInfo.date,
      end_Date: projectInfo.endDate,
      status: 'Initiated',
      controlling_Area_Code: customerInfo.controlling_Area_Code,
      customer_Id: customerInfo.customer_Id,
      company_Code: customerInfo.company_Code,
      customer_Name: customerInfo.customer_Name,
      assignedStaff: [],
      customerDetails: {
        customer_Id: customerInfo.customer_Id,
        customer_Name: customerInfo.customer_Name,
        erp_Customer_Id: customerInfo.erp_Customer_Id,
        country_Code: customerInfo.country_Code,
        city: customerInfo.city,
        zipcode: customerInfo.zipcode,
        street: customerInfo.street,
        phone_Number: customerInfo.phone_Number,
        company_Name: customerInfo.company_Name,
        controlling_Area_Code: customerInfo.controlling_Area_Code,
        language: customerInfo.language,
        contacts: [
          {
            contact_Id: customerInfo.selectedContactList.contact_Id,
            erp_Contact_Id: customerInfo.selectedContactList.erp_Contact_Id,
            first_Name: customerInfo.selectedContactList.first_Name,
            last_Name: customerInfo.selectedContactList.last_Name,
            display_Name: customerInfo.selectedContactList.display_Name,
            email_Address: customerInfo.selectedContactList.email_Address,
            title: customerInfo.selectedContactList.title,
            language: customerInfo.selectedContactList.language,
            phone_Number: customerInfo.selectedContactList.phone_Number,
            department: customerInfo.selectedContactList.department,
          },
        ],
      },
    };
    if (
      isNotNullAndUndefined(customerInfo.assignedStaff) &&
      !isObjectEmpty(customerInfo.assignedStaff)
    ) {
      let _asPayLoad = {
        first_Name: customerInfo.assignedStaff.first_Name,
        last_Name: customerInfo.assignedStaff.last_Name,
        display_Name: customerInfo.assignedStaff.display_Name,
        login_Name: customerInfo.assignedStaff,
        email_Address: customerInfo.assignedStaff.login_Name,
        user_Role: customerInfo.assignedStaff.user_Role,
      };
      body.assignedStaff.push(_asPayLoad);
    }
    return body;
  }

  initializeEditProject(projectId, projectInfo, customerInfo) {
    let body = {
      "project_Id": projectId,
      "project_Name": projectInfo.projectName,
      "project_Description": projectInfo.projectDesc,
      "end_Date": projectInfo.endDate,
      "start_Date": projectInfo.startDate,
      "contacts": [
        {
          "contact_Id": customerInfo.selectedContactList.contact_Id,
          "erp_Contact_Id": customerInfo.selectedContactList.erp_Contact_Id,
          "first_Name": customerInfo.selectedContactList.first_Name,
          "last_Name": customerInfo.selectedContactList.last_Name,
          "display_Name": customerInfo.selectedContactList.display_Name,
          "email_Address": customerInfo.selectedContactList.email_Address,
          "title": customerInfo.selectedContactList.title,
          "language": customerInfo.selectedContactList.language,
          "phone_Number": customerInfo.selectedContactList.phone_Number,
          "department": customerInfo.selectedContactList.department
        }
      ]
    }
    return body;
  }

  mapServicesListInfo(list) {
    let body = {
      offerId: list.service.offer_Id,
      projectId: list.project.project_Id,
      contactPerson: '',
      companyName: list.project.comapny_Name,
      customerEmail: '',
      customerPhoneNumber: list.project.customerDetails.phone_Number,
      customerAddress: `${list.project.customerDetails.street},${list.project.customerDetails.zipcode},${list.project.customerDetails.city}`,
      customerId: list.project.customerDetails.customer_Id,
      serviceType: list.service.service_Type,
      serviceLocation: list.service.service_Location,
      serviceStartDate: list.service.start_Date,
      serviceEndDate: list.service.end_Date,
      region: list.service.service_Location,
      serviceDescription: list.service.service_Description,
    };
    if (isNotEmptyArray(list.project.customerDetails.contacts)) {
      const contactInfo = list.project.customerDetails.contacts[0];
      body.contactPerson = contactInfo.display_Name;
      body.customerEmail = contactInfo.email_Address;
    }
    return body;
  }

  initialzeNewUsersToAdd(userLists) {
    let users = []
    if (isNotEmptyArray(userLists)) {
      userLists.forEach(_ul => {
        let body = {
          id: _ul.Id,
          first_Name: _ul.First_Name,
          last_Name: _ul.Last_Name,
          login_Name: _ul.Login_Name,
          email_Address: _ul.Email_Address
        }
        users.push(body);
      })
    }
    return users;
  }

  initalizeRoleAssignments(roleId, users) {
    let roleAssignmentsInfo = {
      roleId: '',
      users: []
    }
    if (roleId) roleAssignmentsInfo.roleId = roleId
    if (isNotEmptyArray(users)) {
      users.forEach(_us => {
        let body = {
          id: _us.Id,
          first_Name: _us.First_Name,
          last_Name: _us.Last_Name,
          login_Name: _us.Login_Name,
          email_Address: _us.Email_Address
        }
        if (_us.display_Name) body['display_Name'] = _us.Display_Name
        roleAssignmentsInfo.users.push(body);
      })
    }
    return roleAssignmentsInfo;
  }

  initializeGroupManagementInfoToAdd(groupName, users) {
    let groupListInfo = {
      group_id: '',
      group: {
        id: '',
        group_name: '',
        group_email_address: ''
      },
      users: []
    }
    if (groupName) groupListInfo.group.group_name = groupName;
    if (isNotEmptyArray(users)) {
      users.forEach(_us => {
        let body = {
          id: _us.Id,
          first_Name: _us.First_Name,
          last_Name: _us.Last_Name,
          display_Name: _us.Display_Name,
          login_Name: _us.Login_Name,
          email_Address: _us.Email_Address
        }
        groupListInfo.users.push(body);
      })
    }
    return groupListInfo;
  }

  constructLogActualHoursLists(machineListInfo) {
    let logActualHoursInfo = [];
    if (isNotEmptyArray(machineListInfo)) {
      machineListInfo.forEach(_ml => {
        let body = {
          machinename: _ml.machine_Name,
          machine_id: _ml.machine_Id,
          serialNo: _ml.serial_Number,
          assetNo: _ml.asset_Id,
          // accutalHours: _ml.
          calculatedHours: _ml.logActualHours ? _ml.logActualHours.calculatedHours : 0,
          comments: _ml.logActualHours ? _ml.logActualHours.comments : '',
          aggregateHours: _ml.logActualHours ? _ml.logActualHours.aggregatedHours : 0,
          serviceMachineId: _ml.serviceMachine_Id?.serviceMachineId ? _ml.serviceMachine_Id?.serviceMachineId : ''
        }
        logActualHoursInfo.push(body);
      });
    }
    return logActualHoursInfo;
  }

  initializeLogActualHours(logActualHoursLists) {
    let logActualHoursInfo = [];
    let user = this.userAuth.getUserInfo();
    if (isNotEmptyArray(logActualHoursLists) && user && user.userId) {
      logActualHoursLists.forEach(_lahl => {
        let body = {
          serviceMachine_Id: '',
          user_Id: user.userId,
          user_Name: '',
          actualHours: 0,
          comments: ''
        }
        if (_lahl.serviceMachineId) body.serviceMachine_Id = _lahl.serviceMachineId;
        if (_lahl.newActualHours) body.actualHours = +_lahl.newActualHours;
        if (_lahl.newComments) body.comments = _lahl.newComments;
        logActualHoursInfo.push(body);
      })
    }
    return logActualHoursInfo;
  }

  async showToast(toastTitle: string, toastMessage: string) {
    const toast = await this.toastController.create({
      header: toastTitle,
      message: toastMessage,
      cssClass: 'my-custom-toast',
      duration: 3000,
      position: 'top',
    });
    toast.present();
  }

  async showWarningToast(toastTitle: string, toastMessage: string) {
    const toast = await this.toastController.create({
      header: toastTitle,
      message: toastMessage,
      cssClass: 'my-custom-toast',
      duration: 3000,
      position: 'top',
    });
    toast.present();
  }
  async errorShowToast(toastTitle: string, toastMessage: string) {
    const toast = await this.toastController.create({
      header: toastTitle,
      message: toastMessage,
      cssClass: 'my-custom-error-toast',
      duration: 3000,
      position: 'top',
    });
    toast.present();
  }

  async closeBox() {
    let props = {
      isOfferCreation: true,
    };
    const msg = `Are You Sure You Want to Cancel?`;
    props['alertContent'] = msg;
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const {
      // data: { isOfferCreationConfirmClose },
    } = await modal.onWillDismiss();
    // if (isOfferCreationConfirmClose) this.goBack();
  }


}

