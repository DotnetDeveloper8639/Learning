import { Injectable } from '@angular/core';
import { OidcSecurityService } from 'angular-auth-oidc-client';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {

  constructor(private oidcSecurityService: OidcSecurityService,) { }

  getUserInfo() {
    let userInfo = {
      userId: '',
      email: '',
      auth_time: '',
      roles: []
    }
    const user = this.oidcSecurityService.getUserData();
    if (user) {
      userInfo.email = user.sub;
      userInfo.roles = user.role
      userInfo.auth_time = user.auth_time
      userInfo.userId = user.id
    }
    return userInfo;
  }

  getAccessToken() {
    return this.oidcSecurityService.getAccessToken();
  }

  getAuthenticationInfo() {
    return this.oidcSecurityService.getAuthenticationResult()
  }

  login() {
    this.oidcSecurityService.authorize();
  }

  logOut() {
    this.oidcSecurityService.logoff();
  }

}
