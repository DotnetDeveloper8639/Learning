import { TestBed } from '@angular/core/testing';

import { AuthCookieManagerService } from './auth-cookie-manager.service';

describe('AuthCookieManagerService', () => {
  let service: AuthCookieManagerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthCookieManagerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
