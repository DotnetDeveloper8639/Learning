import {
  Component,
  OnInit,
  Pipe,
  PipeTransform,
  QueryList,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import {
  isObjectEmpty,
} from 'src/app/utilities/utils';
import { NgForm } from '@angular/forms';
import { PopoverController, ToastController, ModalController } from '@ionic/angular';
import { StatusPopoverComponent } from 'src/app/components/status-popover/status-popover.component';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import * as moment from 'moment';
import { FilterMoodalComponent } from 'src/app/components/filter-moodal/filter-moodal.component';
import { NavigationExtras, Router } from '@angular/router';
import { AlertModalPage } from 'src/app/components/alert-modal/alert-modal.page';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.scss'],
})
export class ServicesComponent implements OnInit {
  @ViewChildren('serviceForm') allForms: QueryList<NgForm>;
  @ViewChild('serviceForm') form: NgForm;
  selectedSegment = 'serviceDetails';
  contactList = ['Test1', 'Test2', 'Test3'];
  regionList = ['Germany', 'Brazil', 'USA', 'Canada']
  errorDateMessage: boolean = false;
  defaultName = 'Natasha';
  servicesTypeList = [
    'Risk Assessment',
    'Risk Re-Assessment',
    'Retrofitting',
    'Training On-Site',
    'Training Off-Site',
    'Health Check',
  ];
  applyFilter: boolean = false
  public searchFilter: any = '';
  searchElement: any = ''
  showSearchBox: boolean = false;
  showTextarea: boolean = false;
  // checked: boolean = false
  deleteDisable: boolean = false;
  filterValues = { machine_type: '', manufacturer: ' ' };
  constructor(
    public popoverController: PopoverController,
    public sharedValue: ShareValuesService,
    public toastController: ToastController,
    private popController: PopoverController,
    public modalController: ModalController,
    public router: Router,
  ) { }

  ngOnInit(): void {
    this.sharedValue.customersInfo;
  }
  serviceType(each_service) {
    this.allForms.get(0);
    each_service.opened = !each_service.opened;
  }

  segmentChanged(ev, index) {
    console.log(ev, this.allForms?.get(index));
  }
  customerData(ev) { }
  async openAddMachinePopover(ev: any, type, each_service) {
    console.log('Sevice popover', type);
    let props = { type, each_service };
    const popover = await this.popoverController.create({
      component: StatusPopoverComponent,
      cssClass: 'my-custom-class',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      console.log(result);
      if (result.data == 'edit-service') {
        console.log(result.data);
        this.selectedSegment = 'serviceDetails';
      }
    });
  }
  editMachine(each_service) {
    let navigationExtras: NavigationExtras = {
      state: {
        each_service: each_service,
      },
    };
    this.router.navigate(['offer-management/edit-machines'], navigationExtras);
  }
  onSubmit(each_service, myForm: NgForm) {
    console.log(myForm.value);
    if (myForm.valid && !this.errorDateMessage) {
      if (this.sharedValue.listOfServices.length > 0) {
        for (let each of this.sharedValue.listOfServices) {
          if (each.id == each_service.id) {
            each['each_service'] = each['each_service'] || [];
            each['each_service'] = myForm.value;
            console.log(
              'checking service data',
              this.sharedValue.listOfServices
            );
            this.sharedValue.showToast('', 'Service Successfully Saved');
            break;
          }
        }
      }
      // each_service.opened = !each_service.opened;
    } else {
      this.sharedValue.showToast('', 'Please check the details.');
      myForm.form.markAllAsTouched();
    }
  }

  async openStatusPopover(ev, type, each_service) {
    console.log('viewOfferMore', type);
    let props = { type, each_service };
    const popover = await this.popoverController.create({
      component: StatusPopoverComponent,
      cssClass: 'my-custom-class',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      console.log(result);
      // if (result.data == 'edit-service') {
      //   console.log(result.data);
      //   // this.router.navigate['/offer-management'];
      // }
    });
  }

  changeCustPerson(ev, each_service) {
    each_service.custEmail = ev.email_Address;
    this.sharedValue.eachSelectedContactDetails = ev;
    console.log(ev, each_service.custEmail);
  }

  dateCheck() {
    console.log('sharedValue', this.sharedValue.listOfServices[0])
    if (!isObjectEmpty(this.sharedValue.listOfServices[0]) && this.sharedValue.listOfServices[0].serviceStartDate && this.sharedValue.listOfServices[0].serviceEndDate) {
      const { serviceStartDate, serviceEndDate } = this.sharedValue.listOfServices[0];
      let validValue = moment(serviceEndDate).isBefore(serviceStartDate);
      console.log('validValue', validValue)
      if (validValue) this.errorDateMessage = true;
      else this.errorDateMessage = false;
    }
  }

  deleteMachines(listOfServices) {
    console.log(this.sharedValue.listOfServices);
    for (let each of this.sharedValue.listOfServices) {
      each.machines = each.machines.filter((machine) => !machine.selectedMachinechecked);
      console.log(
        'checking service data',
        this.sharedValue.listOfServices,
      );
      this.sharedValue.showToast('', "Machines Deleted Succesfully")
    }
  }

  searchMachines() {
    this.showSearchBox = !this.showSearchBox
  }

  openTextArea(checked) {
    if (checked.currentTarget.checked == true) {
      console.log('e', checked.currentTarget.checked);
      this.showTextarea = true;
    } else {
      console.log('e', checked.currentTarget.checked);
      this.showTextarea = false
    }
  }

  async closeBox() {
    let props = {
      isOfferCreation: true,
    };
    const msg = `Are You Sure You Want to Cancel?`;
    props['alertContent'] = msg;
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const {
      data: { isOfferCreationConfirmClose },
    } = await modal.onWillDismiss();
    if (isOfferCreationConfirmClose) {
      this.sharedValue.listOfServices = [];
      this.sharedValue.machineList = [];
      this.sharedValue.machineList = [];
      this.sharedValue.offer_id;
      this.sharedValue.customers = {};
      this.sharedValue.customersInfoData = '';
      this.sharedValue.project_id = '';
      this.sharedValue.eachSelectedContactDetails = '';
      this.router.navigate(['offer-management'], { replaceUrl: true });
    }
  }


  async showFilterPopup(ev, each_service) {
    // this.applyFilter = false
    console.log("each_service", each_service, this.sharedValue.customersInfo);
    const popover = await this.popoverController.create({
      component: FilterMoodalComponent,
      cssClass: 'my-filtercustom-class',
      event: ev,
      componentProps: { each_service },
      translucent: true,
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      console.log(result.data.data);
      this.applyFilter = true
      this.filterValues.machine_type = result.data.data.machineType;
      this.filterValues.manufacturer = result.data.data.manufacturer;
      this.filterValues = { ...this.filterValues }
      console.log(this.applyFilter, this.filterValues, each_service.machines);

      // if (task && result.data !== undefined) {
      //   typeof result.data === 'string'
      //     ? (task.status = result.data)
      //     : (task.taskManagerUsers = result.data);
      // }
    });
    // const { role } = await popover.onDidDismiss();
    // console.log('onDidDismiss resolved with role', role);
  }
}
@Pipe({
  name: 'filterByTypes'
})
export class FilterPipe implements PipeTransform {
  transform(items: Array<any>, filter: { [key: string]: any }): Array<any> {
    return items.filter(item => {
      const notMatchingField = Object.keys(filter)
        .find(key => item[key] !== filter[key]);

      return !notMatchingField; // true if matches all fields
    });
  }
}

@Pipe({
  name: 'searchFilter'
})

export class SearchFilterPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (!value) return null;
    if (!args) return value;

    args = args.toLowerCase();
    console.log("search", value, args);

    return value.filter(function (data) {
      return JSON.stringify(data).toLowerCase().includes(args);
    });
  }

}
