import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  ViewChild,
} from '@angular/core';
import { NgForm } from '@angular/forms';
import { Observable, of, Subject } from 'rxjs';
import {
  catchError,
  debounceTime,
  distinctUntilChanged,
  finalize,
  switchMap,
} from 'rxjs/operators';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';

@Component({
  selector: 'app-offer-details',
  templateUrl: './offer-details.component.html',
  styleUrls: ['./offer-details.component.scss'],
})
export class OfferDetailsComponent implements OnInit {
  typeAheadSubject = new EventEmitter();
  contactList: Subject<string[]> = of([]) as Subject<string[]>;
  @Input() offerDetails: any = {};
  @ViewChild('offerDetailsForm') form: NgForm;
  quotationTemplateList = [
    'Standard Quotation Template',
    'Standard USA Quotation Template',
    'Standard Brazil Quotation Template',
    'Standard España Quotation Template',
  ];
  offer_id: any;
  project_ids = [];
  public contactInput$ = new Subject<string>();
  customertList = [];
  selectedCust: any;
  constructor(
    public backendService: BackendCallService,
    public sharedValue: ShareValuesService
  ) { }

  ngOnInit(): void {
    // this.getProjectId();
    this.contactList = this.contactInput$.pipe(
      debounceTime(600),
      distinctUntilChanged(),
      switchMap((inp: string) => {
        this.offerDetails.customerLoading = true;
        let obs: Observable<Object>;
        if (inp) {
          return this.backendService.searchServiceCustomerName(inp).pipe(
            catchError((err) => []),
            finalize(() => {
              this.offerDetails.customerLoading = false;
            })
          );
        } else {
          return of([]).pipe(
            finalize(() => {
              this.offerDetails.customerLoading = false;
            })
          );
        }
      })
    ) as Subject<string[]>;

    this.backendService.getOfferStatusService().subscribe(
      (data: any) => {
        console.log('createOffer API called', data);
        this.offer_id = data.value;
        this.sharedValue.offer_id = this.offer_id;
      },
      (err) => { }
    );
  }

  customerSearchByErpId(cust) {
    console.log(cust);
    this.selectedCust = cust;
    this.backendService
      .offerCustomerInfoSearchByErpId(cust.erp_Customer_Id)
      .subscribe(
        (data: any) => {
          this.sharedValue.customersInfo.next(data);
          this.sharedValue.customersInfoData = data;
          console.log(
            'customerSearchByErpId',
            this.sharedValue.customersInfoData
          );
        },
        (err) => { }
      );
  }

  getProjectId(customerName: string) {
    this.offerDetails.projectsLoading = true;
    this.backendService
      // .customerProjectIdByEmail('jryan@ainvector.com')
      .customerProjectIdByCustName(customerName)
      .subscribe(
        (data: any) => {
          console.log('getProjectId API called', data);
          this.project_ids = data.value;
          this.offerDetails.projectsLoading = false;
        },
        (err) => {
          this.offerDetails.projectsLoading = false;
        }
      );
  }
}
