import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreateOfferRoutingModule } from './create-offer-routing.module';
import { CreateOfferComponent } from './create-offer.component';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { componentModule } from 'src/app/components/components.module';
import { RoundProgressModule } from 'angular-svg-round-progressbar';
import { NgSelectModule } from '@ng-select/ng-select';
import { OfferDetailsComponent } from './offer-details/offer-details.component';
import { ClientContactComponent } from './client-contact/client-contact.component';
import { NotesComponent } from './notes/notes.component';
import { CostingComponent } from './costing/costing.component';
import { QuotationComponent } from './quotation/quotation.component';
import { FilterPipe, SearchFilterPipe, ServicesComponent } from './services/services.component';
import { NgPipesModule } from 'ngx-pipes';

@NgModule({
  declarations: [
    CreateOfferComponent,
    OfferDetailsComponent,
    ClientContactComponent,
    NotesComponent,
    CostingComponent,
    QuotationComponent,
    ServicesComponent,
    FilterPipe,
    SearchFilterPipe
  ],
  imports: [
    CommonModule,
    CreateOfferRoutingModule,
    FormsModule,
    IonicModule,
    componentModule,
    RoundProgressModule,
    NgSelectModule,
    NgPipesModule
  ],
})
export class CreateOfferModule {}
