import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-quotation',
  templateUrl: './quotation.component.html',
  styleUrls: ['./quotation.component.scss'],
})
export class QuotationComponent implements OnInit {
  @Input() qoutesDetails: any = {};
  @ViewChild('qoutesDetailsForm') form: NgForm;
  quotationTemplateList = [
    'Standard Quotation Template',
    'Standard USA Quotation Template',
    'Standard Brazil Quotation Template',
    'Standard España Quotation Template',
  ];
  constructor() {}

  ngOnInit(): void {}
}
