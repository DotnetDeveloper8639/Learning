import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { PopoverController, ToastController } from '@ionic/angular';
import { AlertModalPage } from 'src/app/components/alert-modal/alert-modal.page';
import { ModalController, NavController } from '@ionic/angular';
import { OfferDetailsComponent } from './offer-details/offer-details.component';
import { ClientContactComponent } from './client-contact/client-contact.component';
import { ServicesComponent } from './services/services.component';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';

@Component({
  selector: 'app-create-offer',
  templateUrl: './create-offer.component.html',
  styleUrls: ['./create-offer.component.scss'],
})
export class CreateOfferComponent implements OnInit {
  @ViewChild('offerDetailsRef')
  offerDetailsCmpnt: OfferDetailsComponent;
  @ViewChild('clientContactRef')
  clientContactCmpnt: ClientContactComponent;
  @ViewChild('servicesRef')
  servicesCmpnt: ServicesComponent;
  @ViewChild('notesRef')
  notesCmpnt: ServicesComponent;
  @ViewChild('quotationRef')
  quotationCmpnt: ServicesComponent;
  @ViewChild('costingRef')
  costingCmpnt: ServicesComponent;
  stepperType: string = 'od';
  stepperList = [
    {
      title: 'Offer Details',
      key: 'od',
      component: 'offerDetailsCmpnt',
    },
    {
      title: 'Client Contact',
      key: 'cc',
      component: 'clientContactCmpnt',
    },
    {
      title: 'Services',
      key: 'ss',
      component: 'servicesCmpnt',
    },
    {
      title: 'Launch Fiori',
      key: 'quot',
      component: 'quotationCmpnt',
    },
    // {
    //   title: 'Costing Info',
    //   key: 'cinfo',
    //   component: 'costingCmpnt',
    // },
    // {
    //   title: 'Quotation',
    //   key: 'quot',
    //   component: 'quotationCmpnt',
    // },
  ];

  stepperCompletedInputValue = {
    offerDetail: false,
    clientContact: false,
    services: false,
    notes: false,
    costingInfo: false,
    quotation: false,
  };
  costingInfoValid = false;

  constructor(
    public router: Router,
    public backendService: BackendCallService,
    public popoverController: PopoverController,
    public modalController: ModalController,
    public sharedValue: ShareValuesService,
    public toastController: ToastController,
    private navCtrl: NavController
  ) { }

  ngOnInit() {
    console.log('create offer constructor');
  }

  ionViewWillEnter() {
    // this.sharedValue.listOfServices = [];
    // this.sharedValue.machineList = [];
    // this.sharedValue.machineList = [];
    // this.sharedValue.offer_id;
    // this.sharedValue.customers = {};
    // this.sharedValue.customersInfoData = '';
    // this.sharedValue.project_id = '';
    // this.sharedValue.eachSelectedContactDetails = '';
  }

  navBack() {
    this.navCtrl.back();
  }

  requestCommercial() {
    this.sharedValue.showToast('', 'ERP Commercial Data Requested');
  }

  createService() {
    this.router.navigate(['create-service']);
  }

  changeStepper(type) {
    this.checkInputAndRedirect(type);
  }

  checkInputAndRedirect(type) {
    const stepperOrder = this.stepperList.map((each) => each.key);
    if (stepperOrder.indexOf(type) < stepperOrder.indexOf(this.stepperType)) {
      this.stepperType = type;
    } else {
      const previousStepper = this.stepperType;
      for (let each of this.stepperList) {
        if (previousStepper == each.key) {
          if (this[each.component].form.valid) {
            this.stepperType = type;
          } else {
            this[each.component].form.form.markAllAsTouched();
          }
        }
      }
      // if (previousStepper == 'od') {
      //   if (this.offerDetailsCmpnt.form.valid) {
      //     this.stepperType = type;
      //   } else {
      //     this.offerDetailsCmpnt.form.form.markAllAsTouched();
      //   }
      // } else if (previousStepper == 'cc') {
      //   if (this.clientContactCmpnt.form.valid) {
      //     this.stepperType = type;
      //   } else {
      //     this.clientContactCmpnt.form.form.markAllAsTouched();
      //   }
      // } else if (previousStepper == 'ss') {
      //   if (this.servicesCmpnt.form.valid) {
      //     this.stepperType = type;
      //   } else {
      //     this.servicesCmpnt.form.form.markAllAsTouched();
      //   }
      // } else if (previousStepper == 'notes') {
      //   if (this.notesCmpnt.form.valid) {
      //     this.stepperType = type;
      //   } else {
      //     this.notesCmpnt.form.form.markAllAsTouched();
      //   }
      // } else if (previousStepper == 'cinfo') {
      //   if (this.costingCmpnt.form.valid) {
      //     this.stepperType = type;
      //   } else {
      //     this.costingCmpnt.form.form.markAllAsTouched();
      //   }
      // } else if (previousStepper == 'quot') {
      //   if (this.quotationCmpnt.form.valid) {
      //     this.stepperType = type;
      //   } else {
      //     this.quotationCmpnt.form.form.markAllAsTouched();
      //   }
      // }
    }
  }

  nextStepper() {
    this.checkPreviousStepper(this.stepperType);
  }

  checkPreviousStepper(previousStepper) {
    this.costingInfoValid = false;
    if (previousStepper == 'od') {
      if (this.offerDetailsCmpnt.form.valid) {
        console.log(this.offerDetailsCmpnt.form.value);
        this.sharedValue.project_id =
          this.offerDetailsCmpnt.form.value.projectId;
        this.stepperType = 'cc';
      } else {
        this.offerDetailsCmpnt.form.form.markAllAsTouched();
      }
    } else if (previousStepper == 'cc') {
      if (this.clientContactCmpnt.form.valid) {
        console.log(this.clientContactCmpnt.form.value);
        this.stepperType = 'ss';
      } else {
        this.clientContactCmpnt.form.form.markAllAsTouched();
      }
    } else if (previousStepper == 'ss') {
      if (this.servicesCmpnt.form) {
        if (this.servicesCmpnt.form.valid) {
          console.log(this.servicesCmpnt.form.value);
          if (
            this.servicesCmpnt.form.value.serviceType !== 'Risk Assessment' ||
            this.servicesCmpnt.form.value.serviceType !== 'Risk Re-Assessment'
          ) {
            this.stepperType = 'quot';
          } else {
            for (let i = 0; i < this.sharedValue.listOfServices.length; i++) {
              if (this.sharedValue.listOfServices[i].machines.length == 0) {
                this.sharedValue.showToast('', 'Please add machine details');
              }
            }
          }
        } else {
          this.servicesCmpnt.form.form.markAllAsTouched();
        }
      } else if (this.sharedValue.listOfServices.length == 0) {
        this.sharedValue.showToast('', 'Please add service details');
      }
    }
    // else if (previousStepper == 'notes') {
    //   if (this.notesCmpnt.form.valid) {
    //     console.log(this.notesCmpnt.form.value);
    //     this.stepperType = 'cinfo';
    //   } else {
    //     this.notesCmpnt.form.form.markAllAsTouched();
    //   }
    // }
    //  else if (previousStepper == 'cinfo') {
    //   this.costingInfoValid = true;
    //   if (this.costingCmpnt.form.valid) {
    //     this.stepperType = 'quot';
    //   } else {
    //     this.costingCmpnt.form.form.markAllAsTouched();
    //   }
    //   this.stepperType = 'quot';
    // } 
    else if (previousStepper == 'quot') {
      this.createOffer();
      // this.stepperType = 'ss';
      // if (this.quotationCmpnt.form.valid) {
      //   this.createOffer();
      //   this.stepperType = 'cinfo';
      // } else {
      //   this.quotationCmpnt.form.form.markAllAsTouched();
      // }
    }
  }

  createOffer() {
    // var serviceArray = [];
    if (this.sharedValue.listOfServices.length > 0) {
      var services = [];
      for (let i = 0; i < this.sharedValue.listOfServices.length; i++) {
        var each_service = {
          id: '',
          erp_wbs_id: '',
          project_id: this.offerDetailsCmpnt.form.value.projectId,
          offer_id: this.sharedValue.offer_id,
          contact_id: this.sharedValue?.eachSelectedContactDetails?.contact_Id,
          service_type: this.sharedValue.listOfServices[i]!.serviceType,
          service_location:
            this.sharedValue!.listOfServices[i]!.serviceLocation,
          service_description: this.sharedValue!.listOfServices[i]!.serviceDesc,
          service_region: this.sharedValue!.listOfServices[i]!.region,
          start_date: this.sharedValue.listOfServices[i].serviceStartDate,
          end_date: this.sharedValue.listOfServices[i].serviceEndDate,
          actual_hours: 0,
          is_active: 'yes',
          created_at: new Date().toISOString(),
          created_by: ' ',
          modified_at: new Date().toISOString(),
          modified_by: ' ',
          machine: [],
        };
        console.log('each service', each_service);

        if (
          this.sharedValue.listOfServices[i].machines &&
          this.sharedValue.listOfServices[i].machines.length > 0
        ) {
          for (
            let j = 0;
            j < this.sharedValue.listOfServices[i].machines.length;
            j++
          ) {
            var machine;
            console.log(this.sharedValue.listOfServices[i].machines);
            machine = {
              id: '',
              machine_description: '',
              //this.sharedValue.listOfServices[i].machines[j].description,
              master_machine_id: '',
              machine_name:
                this.sharedValue.listOfServices[i].machines[j].machine_name,
              asset_id: this.sharedValue.listOfServices[i].machines[j].asset_id,
              serial_number: this.sharedValue.listOfServices[i].machines[j].serial_number,
              estimated_hours:
                this.sharedValue.listOfServices[i].machines[j].estimatedHours,
              created_at: new Date().toISOString(),
              created_by: ' ',
              modified_at: new Date().toISOString(),
              modified_by: ' ',
              machine_type:
                this.sharedValue.listOfServices[i].machines[j].machine_type,
              machine_location:
                this.sharedValue.listOfServices[i].machines[j].location,
              industry_type:
                this.sharedValue.listOfServices[i].machines[j].industryType,
            };
            each_service['machine'].push(machine);
          }
        }
        services.push(each_service);
        console.log('payload services', services);
      }
    }
    var data = {
      offer: {
        offer_id: this.sharedValue.offer_id,
        project_id: this.offerDetailsCmpnt.form.value.projectId,
        contact_id: this.sharedValue.offerDetailsContact_id,
        status: 'New',
        notes: "",
        quote_template_type: "",
        quote_type: this.offerDetailsCmpnt.form.value.selectedRadioGroupValue,
        service: services
        // created_at: new Date().toISOString(),
        // created_by: ' ',
        // modified_at: new Date().toISOString(),
        // modified_by: ' ',
      },
      customer: {
        id: '',
        customer_name: this.offerDetailsCmpnt?.form?.value?.customerName,
        erp_customer_id: this.sharedValue?.customersInfoData?.erp_Customer_Id,
        contact_id: this.sharedValue?.eachSelectedContactDetails?.contact_Id,
        project_id: this.offerDetailsCmpnt.form.value.projectId,
        customer_id: this.sharedValue?.customersInfoData?.customer_Id, //this.clientContactCmpnt?.form?.value?.customerId,
        country_code: this.sharedValue?.customersInfoData?.country_Code,
        city: this.sharedValue?.customersInfoData?.city,
        zipcode: this.sharedValue?.customersInfoData?.zipcode,
        street: this.sharedValue?.customersInfoData?.street,
        phone_number: this.clientContactCmpnt.form.value.customerContact,
        language:
          this.sharedValue?.customersInfoData?.language == null
            ? ' '
            : this.sharedValue?.customersInfoData?.language,
        created_at: new Date().toISOString(),
        created_by: ' ',
        modified_at: new Date().toISOString(),
        modified_by: ' ',
      },
      contact: {
        contact_id: this.sharedValue?.eachSelectedContactDetails?.contact_Id,
        display_name: this.offerDetailsCmpnt.form.value.customerName,
        email_address: this.clientContactCmpnt.form.value.customerEmail,
        phone_number: this.clientContactCmpnt.form.value.customerContact,
        created_at: new Date().toISOString(),
        created_by: ' ',
        modified_at: new Date().toISOString(),
        modified_by: ' ',
      },
      // service: services,
    };
    this.backendService.createOffer(data).subscribe(
      (data: any) => {
        console.log('createOffer API called', data);
        if (data.value) {
          this.sharedValue.showToast('', data.value);
          this.sharedValue.listOfServices = [];
          this.sharedValue.machineList = [];
          this.sharedValue.listOfServices = [];
          this.sharedValue.offer_id;
          this.sharedValue.customers = {};
          this.sharedValue.customersInfoData;
          this.sharedValue.project_id = '';
          this.sharedValue.eachSelectedContactDetails = '';
          this.router.navigate(['offer-management'], { replaceUrl: true });
        }
      },
      (err) => { }
    );
  }
  goBack() {
    this.sharedValue.listOfServices = [];
    this.sharedValue.machineList = [];
    this.sharedValue.offer_id;
    this.sharedValue.customers = {};
    this.sharedValue.customersInfoData = '';
    this.sharedValue.project_id = '';
    this.sharedValue.eachSelectedContactDetails = '';
    this.router.navigate(['offer-management'], { replaceUrl: true });
  }
  async closeBox() {
    let props = {
      isOfferCreation: true,
    };
    const msg = `Are You Sure You Want to Cancel?`;
    props['alertContent'] = msg;
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const {
      data: { isOfferCreationConfirmClose },
    } = await modal.onWillDismiss();
    if (isOfferCreationConfirmClose) {
      this.sharedValue.listOfServices = [];
      this.sharedValue.machineList = [];
      this.sharedValue.machineList = [];
      this.sharedValue.offer_id;
      this.sharedValue.customers = {};
      this.sharedValue.customersInfoData = '';
      this.sharedValue.project_id = '';
      this.sharedValue.eachSelectedContactDetails = '';
      this.router.navigate(['offer-management'], { replaceUrl: true });
    }
  }
}
