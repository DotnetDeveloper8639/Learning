import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.scss'],
})
export class NotesComponent implements OnInit {
  @Input() notesDetails: any = {};
  @ViewChild('notesDetailsForm') form: NgForm;
  constructor() {}

  ngOnInit(): void {}
}
