import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-costing',
  templateUrl: './costing.component.html',
  styleUrls: ['./costing.component.scss'],
})
export class CostingComponent implements OnInit {
  @Input() costingDetails: any = {};
  @ViewChild('costingDetails') form: NgForm;
  constructor() {}

  ngOnInit(): void {}
}
