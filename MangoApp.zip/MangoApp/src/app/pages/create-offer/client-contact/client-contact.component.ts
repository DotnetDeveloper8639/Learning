import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';

@Component({
  selector: 'app-client-contact',
  templateUrl: './client-contact.component.html',
  styleUrls: ['./client-contact.component.scss'],
})
export class ClientContactComponent implements OnInit {
  @Input() contactDetails: any = {};
  @ViewChild('contactDetailsForm') form: NgForm;
  constructor(public sharedValue: ShareValuesService) { }

  ngOnInit(): void {
    this.sharedValue.customersInfo;
  }

  ionViewWillEnter() { }
  changeCustPerson(ev) {
    this.sharedValue.offerDetailsContact_id = ev.contact_Id
    this.contactDetails.customerEmail = ev.email_Address;
    console.log('contactDetails', this.contactDetails);
  }
}
