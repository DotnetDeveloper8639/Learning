import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ProjectManagementPageRoutingModule } from './project-management-routing.module';

import { ProjectManagementPage } from './project-management.page';
import { componentModule } from '../../components/components.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { TranslateModule } from '@ngx-translate/core';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    componentModule,
    ProjectManagementPageRoutingModule,
    NgSelectModule,
    ReactiveFormsModule,
    TranslateModule
  ],
  declarations: [ProjectManagementPage],
})
export class ProjectManagementPageModule { }
