import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoadingController, ToastController, PopoverController } from '@ionic/angular';
import * as moment from 'moment';
import { Location } from '@angular/common';
import {
  doubleDecimal,
  isEmptyArray,
  isNotEmptyArray,
  isNotNullAndUndefined,
  toNumber,
  listData,
  isObjectEmpty,
  isNotBlank,
} from 'src/app/utilities/utils';
import { ModalController } from '@ionic/angular';
import { AlertModalPage } from 'src/app/components/alert-modal/alert-modal.page';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { LoaderService } from 'src/app/app.component';
import { StatusPopoverComponent } from 'src/app/components/status-popover/status-popover.component';
import { AddRemoveColumnSelectorComponent } from 'src/app/components/add-remove-column-selector/add-remove-column-selector.component';
import { LocalSettingsService } from 'src/app/services/local-settings/local-settings.service';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
@Component({
  selector: 'app-project-management',
  templateUrl: './project-management.page.html',
  styleUrls: ['./project-management.page.scss'],
})
export class ProjectManagementPage implements OnInit {
  selectedTabTitle: string = 'Project Management';
  projectLists = [];
  createProject: boolean = false;
  selectCustomer: boolean = false;
  selectedLeave: string = '';
  selectedOption: string = '';
  showItem: boolean = false;
  enterAdd: boolean = false;
  showCard: boolean = false;
  submitData: boolean = false;
  labelName: any;
  ionicForm: FormGroup;
  defaultDate = '1987-06-30';
  isSubmitted: boolean = false;
  isAddCust: boolean = false;
  selectItemValue: any;
  iseditCustomer: boolean = false;
  selectCustomerContactOptions = [];
  projectDetails: any;
  ProjectEndDate: any;
  customerData = {
    cust_Name: 'Jeld-Wen',
    cust_Id: 'JELD5466878',
    company_Code: '7786',
    controlling_Area: '1000',
    customer_Contact: '801-652-7921',
    company_Address: '0044 Deschutes Drive Stayton, OR 9783',
  };
  createProjectInput = {
    projectName: '',
    startDate: '',
    endDate: '',
    projectDesc: '',
  };
  selectContactInput = {
    contact: '',
  };
  contactDropdown = {
    dropdwnCnct: false,
  };
  modalController: any;
  effortMetricsData: any = {};
  enteredCustomerName: any;
  searchedCustomerData: any = [];
  bk_searchedCustomerData: any = [];
  isAnyRadioButtonSelected: boolean = false;
  errorDateMessage: boolean = false;
  selectedSearchedUserInfo: any = {};
  isNoSearchedCustomerFound: boolean = false;
  selectedContactPersonRadioValue: any;
  selectedCustomerRadioValue: any;
  isProjectCreatedSuccessfully: boolean = false;
  editAddLabel: any;
  isProjectStatusSearchbarExpand: boolean = false;
  private projectTrackerColumnSelectorPermission: any = {};
  private bk_projectLists: any;
  private editFlowEncryptProjectId: any;
  isEditProjectFlow: boolean = false;
  bk_selectedSearchedUserInfo: any;
  iseditFlowSelectCustomer: boolean;
  shouldDisableSearchButton: boolean = false
  editFlowProjectInfo: any;
  isSamePageProjectEditFlow: boolean;
  private editFlowProjectId: any;
  selectedCustomerContact = null;

  constructor(
    public router: Router,
    public backendService: BackendCallService,
    public modelCtrl: ModalController,
    public formBuilder: FormBuilder,
    public sharedValue: ShareValuesService,
    public loadingController: LoadingController,
    public toastController: ToastController,
    private loader: LoaderService,
    public popoverController: PopoverController,
    public localSettingsSrv: LocalSettingsService,
    private location: Location,
  ) { }

  ngOnInit() {
    // this.initializeProjectManagementData();
    // this.validateForm();
  }

  ionViewWillEnter() {
    this.editFlowEncryptProjectId = this.sharedValue.edit_flow_temp_Encrypted_project_id;
    if (isNotNullAndUndefined(this.editFlowEncryptProjectId) && isNotBlank(this.editFlowEncryptProjectId)) {
      this.makeEditFlowVisible(this.editFlowEncryptProjectId);
    } else {
      this.getDashBoard();
      this.initializeProjectManagementData();
      this.validateForm();
    }
  }

  makeEditFlowVisible(encrypted_project_id, isSamePage = false) {
    this.isEditProjectFlow = true
    this.shouldDisableSearchButton = true;
    if (this.iseditCustomer) this.iseditCustomer = false;
    !isSamePage && this.validateForm();
    this.getProjectInfo(encrypted_project_id);
  }

  getProjectInfo(id) {
    if (id) {
      return this.backendService
        .getprojectDetail(id)
        .then((res) => {
          if (!isObjectEmpty(res)) this.assignEditFlowData(res);
        })
        .catch((err) => {
          console.log('getting error for fetching projects detail:', err);
        });
    }
  }

  assignEditFlowData(res) {
    this.submitData = true;
    this.editFlowProjectInfo = res;
    this.editFlowProjectId = res.project_Id
    this.createProjectInput = {
      projectName: res.project_Name,
      startDate: this.convertDateFormat(res.start_Date),
      endDate: this.convertDateFormat(res.end_Date),
      projectDesc: res.description,
    };
    this.selectedSearchedUserInfo = {
      customer_Name: res.customer_Name,
      customer_Id: res.customerDetails.customer_Id,
      company_Code: res.company_Code,
      controlling_Area_Code: res.controlling_Area_Code,
      phone_Number: res.customerDetails.phone_Number,
      street: res.customerDetails.street,
      city: res.customerDetails.city,
      zipcode: res.customerDetails.zipcode,
      selectedContactList: res.customerDetails.contacts[0]
    }
    this.bk_selectedSearchedUserInfo = this.selectedSearchedUserInfo;
  }

  convertDateFormat(date) {
    if (date) {
      let spilitedDate = date.split('/');
      return `${spilitedDate[2]}-${spilitedDate[1]}-${spilitedDate[0]}`
    } else return date;
  }

  dateCheck() {
    if (!isObjectEmpty(this.createProjectInput) && this.createProjectInput.startDate && this.createProjectInput.endDate) {
      const { startDate, endDate } = this.createProjectInput;
      let validValue = moment(endDate).isBefore(startDate);
      if (validValue) this.errorDateMessage = true;
      else this.errorDateMessage = false;
    }
  }

  async initializeProjectManagementData() {
    await this.getProjectMetrics();
    this.getProjects();
  }

  getProjectMetrics() {
    const _self = this;
    return _self.backendService.getProjectEffortMetrics().then((data) => {
      if (!isObjectEmpty(data)) this.effortMetricsData = data;
    });
  }

  ionViewWillLeave() {
    if (this.isProjectStatusSearchbarExpand) {
      this.isProjectStatusSearchbarExpand = !this.isProjectStatusSearchbarExpand;
      this.projectLists = this.bk_projectLists;
    }
    if (this.isSamePageProjectEditFlow) this.isSamePageProjectEditFlow = false;
  }

  getProjects() {
    const _self = this;
    _self.backendService
      .getProjectLists()
      .then((data) => {
        if (isNotEmptyArray(data)) {
          this.bk_projectLists = JSON.parse(JSON.stringify(data));
          _self.projectLists = data;
          this.getColumnSelectorPermission(['projectStatus'])
          this.projectDetails = this.projectLists.forEach((element) => {
            this.ProjectEndDate = moment(element.end_Date).local().format();
          });
          // return (_self.projectLists = data);
          // moment(timestamp).toISOString(true)
        }

        // const { projects } = data;
        // if (isNotEmptyArray(projects)) {
        //   projects.forEach((_p) => {
        //     if (_p.Actual_Time_hours && _p.Planned_Time_Hours)
        //       _p.timeHoursInPer = doubleDecimal(
        //         toNumber(
        //           ((_p.Actual_Time_hours / _p.Planned_Time_Hours) * 100) / 10
        //         )
        //       );
        //   });
        //   return (_self.projectLists = projects);
        // }
      })
      .catch((err) => {
        console.log('getting error for fetching projects lists:', err);
      });
  }

  appearProjectStatusTrackerSearch() {
    this.isProjectStatusSearchbarExpand = !this.isProjectStatusSearchbarExpand;
    if (!this.isProjectStatusSearchbarExpand) this.projectLists = this.bk_projectLists;
  }

  projectStatusTrackerSearch(event) {
    const { value } = event.detail;
    if (value && isNotEmptyArray(this.bk_projectLists)) {
      this.projectLists = this.bk_projectLists.filter(_bkpl => {
        return (
          (_bkpl.project_Id.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.project_Name.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.customer_Name.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.customer_Id.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.contact_Name.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.customer_Address.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.region.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.project_Manager.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.progress.toString().toLowerCase().indexOf(value)) > -1 ||
          (_bkpl.hours_Progress.toString().toLowerCase().indexOf(value)) > -1 ||
          (_bkpl.end_Date.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.status.toLowerCase().indexOf(value.toLowerCase())) > -1
        );
      })
    } else this.projectLists = this.bk_projectLists;
  }

  openCreateProject() {
    this.createProject = true;
    this.selectCustomer = false;
    this.resetSearchedCustomerInfo();
    this.resetProjectUserInput();
  }

  resetProjectUserInput() {
    this.createProjectInput = {
      projectName: '',
      startDate: '',
      endDate: '',
      projectDesc: '',
    };
    this.isProjectCreatedSuccessfully = false;
    this.contactDropdown.dropdwnCnct = false;
    this.errorDateMessage = false;
  }

  openAddCustomer() {
    this.isSubmitted = true;
    if (!this.ionicForm.valid) {
      console.log('Please provide all the required values!');
      return false;
    } else {
      if (!this.errorDateMessage) this.selectCustomer = true;
    }
  }

  gotoProManback() {
    if (this.isEditProjectFlow) {
      this.editFlowGoBack();
    } else {
      this.resetSearchedCustomerInfo(!this.isEditProjectFlow);
      if (!this.selectCustomer) this.createProject = false;
      else this.selectCustomer = false;
      // if (!this.submitData) this.createProject = false;
      // else this.submitData = false;
      if (!this.createProject) this.selectCustomer = false;
      else this.createProject;
      if (!this.submitData) this.selectCustomer = false;
      else this.submitData = false;
      this.isSubmitted = false;
      if (this.iseditCustomer) this.iseditCustomer = false;
    }
  }

  resetSearchedCustomerInfo(shouldResetCustomerName = true) {
    this.isAnyRadioButtonSelected = false;
    this.searchedCustomerData = [];
    this.bk_searchedCustomerData = [];
    this.selectedCustomerRadioValue = null;
    this.enterAdd = false;
    this.selectCustomerContactOptions = [];
    if (shouldResetCustomerName) {
      this.enteredCustomerName = null;
      this.selectedSearchedUserInfo = {};
      this.selectedContactPersonRadioValue = null;
    }
  }

  openenterAddress() {
    if (this.enteredCustomerName && this.enteredCustomerName.trim() !== '') {
      this.resetSearchedCustomerInfo(false);
      this.getSearchedCustomerByName();
    } else {
      this.enterAdd = false;
      this.resetSearchedCustomerInfo(!this.isEditProjectFlow);
    }
  }

  getSearchedCustomerByName() {
    this.loader.showLoader();
    return this.backendService
      .getProjectSearchedCustomer(this.enteredCustomerName)
      .then((res) => {
        if (isNotEmptyArray(res)) {
          this.searchedCustomerData = res || [];
          this.bk_searchedCustomerData = JSON.parse(
            JSON.stringify(this.searchedCustomerData)
          );
          this.enterAdd = true;
        }
        this.loader.hideLoader();
        return this.searchedCustomerData
      })
      .catch((err) => {
        this.loader.hideLoader();
        console.log('gettig error from Searched Customer By Name :', err);
      });
  }

  saveAddress() {
    this.isSubmitted = true;
    this.selectCustCnct();
    if (!this.isEditProjectFlow && !this.ionicForm.valid) {
      console.log('Please provide all the required values!');
      return false;
    } else {
      if (
        isObjectEmpty(this.selectedSearchedUserInfo) ||
        !this.selectedContactPersonRadioValue
      )
        return false;
      else {
        this.submitData = true;
        if (this.iseditFlowSelectCustomer) this.iseditFlowSelectCustomer = false;
      }
    }
  }

  getDashBoard() {
    this.router.navigate(['project-management']);
  }

  validateForm() {
    this.ionicForm = this.formBuilder.group({
      name: ['', [Validators.maxLength(30),
      // Validators.pattern('[a-zA-Z ]*'),
      Validators.pattern('^[a-zA-Z0-9](.*[a-zA-Z0-9])?$'),
      Validators.required,]],
      date: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      textDescription: ['', [Validators.required]],
    });
  }

  // selectCustomerForm() {
  //   this.ionicForm = this.formBuilder.group({
  //     selectCustomer: ['', [Validators.required]],
  //   });
  // }

  selectCustCnct() {
    if (!this.selectContactInput.contact)
      this.contactDropdown.dropdwnCnct = true;
  }

  get errorControl() {
    return this.ionicForm.controls;
  }

  submitForm() {
    this.isSubmitted = true;
    //console.log('submitForm called ...')
    if (!this.ionicForm.valid) {
      console.log('Please provide all the required values!');
      return false;
    } else {
      //console.log(this.ionicForm.value)
    }
  }

  submitFinal() {
    console.log('Data is succesfully saved');
    // this.ionicForm.reset()
    // this.router.navigate(['project-management']);
    if (this.isEditProjectFlow && !this.errorDateMessage) this.storeEditProjectInfo();
    else if (this.ionicForm.valid && !this.errorDateMessage && !this.isEditProjectFlow) this.storeCreateProjectInfo();
  }

  storeEditProjectInfo() {
    const editProjectInfo = this.sharedValue.initializeEditProject(this.editFlowProjectId, this.createProjectInput, this.selectedSearchedUserInfo);
    this.backendService
      .editProject(editProjectInfo)
      .then((res) => {
        if (res && res == 'Project has been updated') {
          this.sharedValue.showToast('', 'Project Edited Successfully.')
          this.editFlowGoBack();
        }
      }).catch((err) => {
        console.log('getting issue in editing the   project:', err);
      });
  }

  storeCreateProjectInfo() {
    const createProjectInfo = this.sharedValue.initializeCreateProject(this.ionicForm.value, this.selectedSearchedUserInfo);
    this.backendService
      .createProject(createProjectInfo)
      .then((res) => {
        if (res && res == 'Project has been created') {
          this.createProject = false;
          this.enterAdd = false;
          this.submitData = false;
          this.iseditCustomer = false;
          this.isSubmitted = !this.isSubmitted;
          this.contactDropdown.dropdwnCnct =
            !this.contactDropdown.dropdwnCnct;
          this.isProjectCreatedSuccessfully = true;
        }
        this.sharedValue.showToast('', 'Project Created Successfully!');
        this.refreshProjectManagementDetails();
      })
      .catch((err) => {
        console.log('getting issue in creation of  project:', err);
      });
  }

  refreshProjectManagementDetails() {
    setTimeout(() => {
      this.initializeProjectManagementData();
    }, 3000);
  }

  editFlowGoBack() {
    if (this.selectCustomer && !this.submitData) {
      this.selectCustomer = false;
      this.submitData = true;
      this.iseditFlowSelectCustomer = false;
      if (!this.selectedSearchedUserInfo.selectedContactList) this.selectedSearchedUserInfo.selectedContactList = this.bk_selectedSearchedUserInfo.selectedContactList;
      if (this.selectedSearchedUserInfo.selectedContactList.contact_Id !== this.bk_selectedSearchedUserInfo.selectedContactList.contact_Id) {
        this.bk_selectedSearchedUserInfo.selectedContactList = this.selectedSearchedUserInfo.selectedContactList
      }
    } else if (this.submitData) {
      if (this.isSamePageProjectEditFlow) {
        this.refreshProjectManagementDetails();
        this.isEditProjectFlow = false;
        this.submitData = false;
      } else this.location.back();
    }
  }

  isReadonlyCustomerSearch() {
    if (this.isEditProjectFlow) return true;
    else return false;
  }

  async editCustomer() {
    //this.iseditCustomer = true;
    if (this.isEditProjectFlow) {
      if (this.contactDropdown.dropdwnCnct) this.contactDropdown.dropdwnCnct = false;
      this.selectCustomer = true;
      this.submitData = false;
      this.iseditFlowSelectCustomer = true;
      this.enteredCustomerName = this.selectedSearchedUserInfo.customer_Name;
      let searchedData = await this.getSearchedCustomerByName();
      if (isNotEmptyArray(searchedData)) {
        this.selectedCustomerRadioValue = searchedData[0].erp_Customer_Id;
        let body = { detail: { value: this.selectedCustomerRadioValue } }
        this.changeSelectedRadioValue(body);
      }
    } else this.iseditCustomer = !this.iseditCustomer;
  }

  async closeBox() {
    let props = {
      isProjectManagement: true,
    };
    const msg = `Are You Sure You Want to Cancel?`;
    props['alertContent'] = msg;
    const modal = await this.modelCtrl.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const {
      data: { isOfferCreationConfirmClose },
    } = await modal.onWillDismiss();
    if (isOfferCreationConfirmClose) this.clkCancel();
  }

  clkCancel() {
    if (this.isEditProjectFlow) {
      if (this.isSamePageProjectEditFlow) {
        this.isEditProjectFlow = false;
        this.submitData = false;
        this.isSamePageProjectEditFlow = false
      } else this.location.back();
    } else {
      this.createProject = false;
      this.selectCustomer = false;
      this.submitData = false;
    }
  }

  goToProjectDetail(project_Id) {
    if (project_Id) {
      let navigationExtras: NavigationExtras = {
        state: {
          projectId: project_Id,
        },
      };
      this.router.navigate(['project-detail'], navigationExtras);
    }
  }

  changeSelectedRadioValue(event) {
    this.selectedContactPersonRadioValue = '';
    this.selectedCustomerRadioValue = '';
    this.selectedCustomerContact = null;
    if (this.contactDropdown.dropdwnCnct) this.contactDropdown.dropdwnCnct = false;
    const selectedCustomer = this.selectedCustomerRadioValue = event.detail.value;
    let matchedInfo = this.searchedCustomerData.find(
      (_u) => _u.erp_Customer_Id == selectedCustomer
    );
    if (!isObjectEmpty(matchedInfo))
      this.fetchSpecificCustomerContatcInfo(matchedInfo.erp_Customer_Id);
  }

  fetchSpecificCustomerContatcInfo(erp_Customer_Id) {
    this.backendService
      .getProjecManagemetContactInfo(erp_Customer_Id)
      .then((res) => {
        if (!isObjectEmpty(res)) {
          this.isAnyRadioButtonSelected = true;
          if (isNotEmptyArray(this.selectCustomerContactOptions))
            this.selectCustomerContactOptions = [];
          this.selectCustomerContactOptions.push(res.phone_Number);
          this.selectedSearchedUserInfo = res;
          this.editAddLabel =
            this.selectedSearchedUserInfo.street +
            ',' +
            this.selectedSearchedUserInfo.city +
            ',' +
            this.selectedSearchedUserInfo.zipcode;
          if (this.isEditProjectFlow && isNotEmptyArray(this.editFlowProjectInfo.customerDetails.contacts)) this.getSelectedCustomerInfo(res);
        }
      })
      .catch((err) => {
        console.log('getting error in fetching user contact info :', err);
      });
  }

  getSelectedCustomerInfo(customerInfo) {
    const { contact_Id } = this.editFlowProjectInfo.customerDetails.contacts[0];
    if (isNotEmptyArray(customerInfo.contacts)) {
      let matchedContact = customerInfo.contacts.find(_cn => _cn.contact_Id == contact_Id);
      if (matchedContact) {
        this.selectedContactPersonRadioValue = matchedContact.contact_Id;
        let body = { detail: { value: this.selectedContactPersonRadioValue } }
        this.changeSelectedContactpersonRadio(body);
      }
    }
  }

  searchCustomer(event) {
    const sValue = event.detail.value;
    this.searchedCustomerData = this.bk_searchedCustomerData.filter((_sCus) => {
      return (
        _sCus.customer_Name.toLowerCase().indexOf(sValue.toLowerCase()) > -1
      );
    });
    if (isEmptyArray(this.searchedCustomerData))
      this.isNoSearchedCustomerFound = true;
    else this.isNoSearchedCustomerFound = false;
  }

  changeSelectedContactpersonRadio(event) {
    if (this.contactDropdown.dropdwnCnct) this.contactDropdown.dropdwnCnct = false;
    this.selectedContactPersonRadioValue = event.detail.value;
    let selectedContact = this.selectedSearchedUserInfo.contacts.find(
      (_sc) => _sc.contact_Id == event.detail.value
    );
    this.selectedSearchedUserInfo['selectedContactList'] = selectedContact;
  }

  onKeydown(event) {
    if (event.key == 'Tab') event.preventDefault();
  }

  async openStatusPopover(ev: any, type, task?, projectId?) {
    let props = { type };
    const popover = await this.popoverController.create({
      component: StatusPopoverComponent,
      cssClass: 'my-custom-class',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      const { data } = result;
      if (task && result.data !== undefined) {
        typeof result.data === 'string'
          ? (task.status = result.data)
          : (task.taskManagerUsers = result.data);
      } else if (data == 'editProj') this.navigateToEditProject(projectId);
    });
  }

  navigateToEditProject(encrypted_project_id) {
    this.isSamePageProjectEditFlow = true;
    this.makeEditFlowVisible(encrypted_project_id, true);
  }

  addOrRemoveColumnSelectorWidgets(type) {
    this.openAddOrRemoveColumnSelectorAlertModal(type);
  }

  async openAddOrRemoveColumnSelectorAlertModal(type) {
    let props = { columnSelectorFor: type };
    const modal = await this.modelCtrl.create({
      component: AddRemoveColumnSelectorComponent,
      cssClass: 'add-remove-widget-class',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const {
      data: {
        columnSelectorSelectedValue: {
          isDataChangedForColumnSelector,
          columnSelectorWidgetFor,
        },
      },
    } = await modal.onWillDismiss();
    if (isDataChangedForColumnSelector && columnSelectorWidgetFor) this.getColumnSelectorPermission([columnSelectorWidgetFor]);
  }

  getColumnSelectorPermission(types = []) {
    const _self = this;
    if (types.includes('projectStatus')) {
      const data = _self.localSettingsSrv.getProjectStatusColumnSelectorWidgetStorageValue();
      if (isNotEmptyArray(data)) _self.checkProjectTrackerColumnSelectorPermission(data);
    }
  }

  checkProjectTrackerColumnSelectorPermission(value) {
    const _self = this;
    value.forEach((_v) => {
      if (_v.val === 'pid')
        _self.projectTrackerColumnSelectorPermission['projectId'] =
          _v.isChecked;
      if (_v.val === 'pname')
        _self.projectTrackerColumnSelectorPermission['projectName'] =
          _v.isChecked;
      if (_v.val === 'cname')
        _self.projectTrackerColumnSelectorPermission['customerName'] =
          _v.isChecked;
      if (_v.val === 'custId')
        _self.projectTrackerColumnSelectorPermission['customerId'] =
          _v.isChecked;
      if (_v.val === 'contactName')
        _self.projectTrackerColumnSelectorPermission['contactName'] =
          _v.isChecked;
      if (_v.val === 'custAddress')
        _self.projectTrackerColumnSelectorPermission['customerAddress'] =
          _v.isChecked;
      if (_v.val === 'rgns')
        _self.projectTrackerColumnSelectorPermission['regions'] = _v.isChecked;
      if (_v.val === 'pmname')
        _self.projectTrackerColumnSelectorPermission['projectManName'] =
          _v.isChecked;
      if (_v.val === 'prg')
        _self.projectTrackerColumnSelectorPermission['projectProgress'] =
          _v.isChecked;
      if (_v.val === 'hrPrg')
        _self.projectTrackerColumnSelectorPermission['projectHourProgress'] =
          _v.isChecked;
      if (_v.val === 'etd')
        _self.projectTrackerColumnSelectorPermission['endDate'] = _v.isChecked;
      if (_v.val === 'status')
        _self.projectTrackerColumnSelectorPermission['status'] = _v.isChecked;
    });
  }

  // Export ProjectData to Excel Sheet
  exportProjectdata() {
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('ProjectStatusTracker');
    worksheet.columns = [
      { header: 'Project Id', key: 'project_Id', width: 12, },
      { header: 'Project Name', key: 'project_Name', width: 30 },
      { header: 'Customer Name', key: 'customer_Name', width: 30 },
      { header: 'Customer Id', key: 'customer_Id', width: 20 },
      { header: 'Contact Person', key: 'contact_Name', width: 20 },
      { header: 'Region', key: 'region', width: 10 },
      { header: 'Project Manager', key: 'project_Manager', width: 25 },
      { header: 'Progress', key: 'progress', width: 15 },
      { header: 'Hours Progress', key: 'hours_Progress', width: 15 },
      { header: 'End Date', key: 'end_Date', width: 15 },
      { header: 'Status', key: 'status', width: 15 },
      // { header: 'Contact Person', key: 'price', width: 10, style: { font: { name: 'Arial Black', size: 10 } } },
    ];
    worksheet.addRows(this.projectLists, "n");
    // worksheet.addRow({ ProjectId: e.project_Id, ProjectName: e.project_Name, CustomerName: e.customer_Name, CustomerId: e.customer_Id, ContactPerson: e.contact_Name, Region: e.region, ProjectManager: e.project_Manager, Progress: e.progress, HoursProgress: e.hours_Progress, EndDate: e.end_Date, Status: e.status }, "n");
    workbook.xlsx.writeBuffer().then((projectLists) => {
      let blob = new Blob([projectLists], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      fs.saveAs(blob, 'ProjectStatusTracker.xlsx');
    })
  }
}
