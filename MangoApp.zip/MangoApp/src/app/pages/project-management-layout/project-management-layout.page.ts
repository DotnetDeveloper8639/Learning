import { Component, EventEmitter, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BehaviorSubject, forkJoin, merge } from 'rxjs';
import { filter, switchMap, takeUntil } from 'rxjs/operators';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';


@Component({
  selector: 'app-project-management-layout',
  templateUrl: './project-management-layout.page.html',
  styleUrls: ['./project-management-layout.page.scss'],
})
export class ProjectManagementLayoutPage implements OnInit,OnDestroy {
  static projectDetails: BehaviorSubject<any> = new BehaviorSubject({});
  static projectServiceDetails: BehaviorSubject<any> = new BehaviorSubject({});
  static searchServiceData: BehaviorSubject<{
    projectListInfo: any,
    machineListInfo: any,
    bucketListInfo: any
  }> = new BehaviorSubject({
    projectListInfo: {},
    machineListInfo: {},
    bucketListInfo: {}
  });
  private projectData = null;
  private apiWaitObserver = new EventEmitter();
  private destroyEvents = new EventEmitter();
  constructor(
    private route: ActivatedRoute,
    public backendService: BackendCallService,
  ) { }


  ngOnInit() {
    this.searchService();
    this.getProjectDetails();
    this.route.params.pipe(takeUntil(this.destroyEvents)).subscribe((params)=>{
      const lastVal = ProjectManagementLayoutPage.projectDetails.getValue();
      if(lastVal?.encrypted_Project_Id && lastVal.encrypted_Project_Id != params.id){
        this.clearAllValues();
      }
      
    })
  }
  clearAllValues(){
    ProjectManagementLayoutPage.projectDetails.next({});
    ProjectManagementLayoutPage.projectServiceDetails.next({});
    ProjectManagementLayoutPage.searchServiceData.next({
      projectListInfo: {},
      machineListInfo: {},
      bucketListInfo: {}
    });
    this.projectData = null;
    
  }
  ngOnDestroy(): void {
   this.destroyEvents.emit(true);
   this.destroyEvents.unsubscribe();
  }

  private searchService() {
    
    merge(this.apiWaitObserver,this.route.queryParams)
    .pipe(filter((params) => params.orderId && params.serviceType && params.projectId && this.projectData), switchMap((params) => {
      console.log('query parsm listner');
      
      const { orderId, serviceType, projectId } = params;
      const projectListInfo = this.backendService
        .getProjectDetailServiceListsInfo(orderId, serviceType, projectId);
      const machineListInfo = this.backendService
        .getProjectDetailMachineListsInfo(orderId, serviceType, projectId);
      const bucketListInfo = this.backendService.getBucketLists(projectId, orderId, serviceType);
      return forkJoin([projectListInfo, machineListInfo, bucketListInfo]);
    }),takeUntil(this.destroyEvents)).subscribe((res) => {
      const [projectListInfo, machineListInfo, bucketListInfo] = res;
      ProjectManagementLayoutPage.searchServiceData.next({ projectListInfo, machineListInfo, bucketListInfo });
    });
  }

  private getProjectDetails() {
    const id = this.route.snapshot.params.id;
    return this.backendService
      .getprojectDetail(id)
      .then((res) => {
        if(res?.project_Id){

        }
        ProjectManagementLayoutPage.projectDetails.next(res);
        this.getProjectServiceDetails(res);
      })
      .catch((err) => {
        console.log('getting error for fetching projects detail:', err);
      });
  }

  private getProjectServiceDetails(res: any) {
    if (res?.project_Id) {
      this.backendService
        .getProjecDetailOrderService(res.project_Id)
        .then((res) => {
          ProjectManagementLayoutPage.projectServiceDetails.next(res);
          const params = this.route.snapshot.queryParams;
          if(!this.projectData && params.orderId && params.serviceType && params.projectId){
            setTimeout(() => {
              this.apiWaitObserver.emit(params);
            }, 100);
          }
          this.projectData = res;
        })
        .catch((err) => {
          console.log(
            'getting error for fetching projects service information:',
            err
          );
        });
    }
  }
}
