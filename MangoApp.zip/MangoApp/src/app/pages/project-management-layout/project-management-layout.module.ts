import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ProjectManagementLayoutPageRoutingModule } from './project-management-layout-routing.module';

import { ProjectManagementLayoutPage } from './project-management-layout.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ProjectManagementLayoutPageRoutingModule
  ],
  declarations: [ProjectManagementLayoutPage]
})
export class ProjectManagementLayoutPageModule {}
