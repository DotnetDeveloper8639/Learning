import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ProjectManagementLayoutPage } from './project-management-layout.page';

const routes: Routes = [
  {
    path: '',
    component: ProjectManagementLayoutPage,
    children:[
      {
        path: '',
        loadChildren: () =>
          import('../project-detail/project-detail.module').then(
            (m) => m.ProjectDetailPageModule
          ),
      },
      {
        path: 'machine-details/:id',
        loadChildren: () => import('../machine-details/machine-details.module').then(m => m.MachineDetailsPageModule),
      },
      {
        path: 'machine-details/:id/risk-assessment-sections',
        loadChildren: () => import('../risk-assessment-sections/risk-assessment-sections.module').then( m => m.RiskAssessmentSectionsPageModule)
      },
      {
        path: 'machine-details/:id/risk-assessment-sections/add-hazard-details',
        loadChildren: () => import('../add-hazard-details/add-hazard-details.module').then( m => m.AddHazardDetailsPageModule)
      },
      {// {project-management/project-detail/:id/machine-details/risk-assessment
        path: 'machine-details/:id/risk-assessment',
        loadChildren: () => import('../risk-assessment/risk-assessment.module').then(m => m.RiskAssessmentPageModule)
      },
      {
        path: 'four-eye-quality',
        loadChildren: () => import('../four-eye-quality/four-eye-quality.module').then(m => m.FourEyeQualityPageModule)
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProjectManagementLayoutPageRoutingModule {}
