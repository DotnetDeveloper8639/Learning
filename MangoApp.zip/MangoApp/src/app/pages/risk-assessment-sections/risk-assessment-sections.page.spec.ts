import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { RiskAssessmentSectionsPage } from './risk-assessment-sections.page';

describe('RiskAssessmentSectionsPage', () => {
  let component: RiskAssessmentSectionsPage;
  let fixture: ComponentFixture<RiskAssessmentSectionsPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ RiskAssessmentSectionsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(RiskAssessmentSectionsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
