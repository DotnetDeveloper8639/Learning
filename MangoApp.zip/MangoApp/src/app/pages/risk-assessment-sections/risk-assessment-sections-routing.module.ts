import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RiskAssessmentSectionsPage } from './risk-assessment-sections.page';

const routes: Routes = [
  {
    path: '',
    component: RiskAssessmentSectionsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RiskAssessmentSectionsPageRoutingModule {}
