export interface ISection {
    roadMapMasterId: string
    sectionName: string
    subSections: SubSection[]
    // subsections: SubSection[]
  }
  
  export interface SubSection {
    roadMapSectionId: string
    subSectionName: string
    steps: Step[]
  }
  
  export interface Step {
    stepBody: string
    stepNote: string
    compliant: string
    notApplicable: string
    hazard: string
    compliance: string
    isListItemOpened: boolean
    hazardDetails: HazardDetails
  }
  
  export interface HazardDetails {
    formData: FormData
    files: any[]
  }
  
  export interface FormData {
    hazardTypesData: HazardTypesData
    hazardName: string
    chrnTable: ChrnTable
    pickInitialHazard: string
    pickControlMeasure: string
    ihrnTable: IhrnTable
    determinePlrValue:string
  }
  
  export interface HazardTypesData {
      [key: string]: N0
  }
  
  export interface N0 {
    hazardType: HazardType
    source: Source[]
    consequences: Consequence[]
  }
  
  export interface HazardType {
    id: string
    type: string
  }
  
  export interface Source {
    id: string
    source: string
  }
  
  export interface Consequence {
    id: string
    consequence: string
  }
  
  export interface ChrnTable {
    "Probility of Occurences(PO)": ProbilityOfOccurencesPo
    "Degree of Severity(SD)": DegreeOfSeveritySd
    "Frequency of Exposition(FE)": FrequencyOfExpositionFe
    "Number of Persons Exposed(NP)": NumberOfPersonsExposedNp
  }
  
  export interface ProbilityOfOccurencesPo {
    Normal: Normal
  }
  
  export interface Normal {
    label: string
    value: string
  }
  
  export interface DegreeOfSeveritySd {
    Normal: Normal2
  }
  
  export interface Normal2 {
    label: string
    value: string
  }
  
  export interface FrequencyOfExpositionFe {
    Normal: Normal3
  }
  
  export interface Normal3 {
    label: string
    value: string
  }
  
  export interface NumberOfPersonsExposedNp {
    Normal: Normal4
  }
  
  export interface Normal4 {
    label: string
    value: string
  }
  
  export interface IhrnTable {
    "Probility of Occurences(PO)": ProbilityOfOccurencesPo2
    "Degree of Severity(SD)": DegreeOfSeveritySd2
    "Frequency of Exposition(FE)": FrequencyOfExpositionFe2
    "Number of Persons Exposed(NP)": NumberOfPersonsExposedNp2
  }
  
  export interface ProbilityOfOccurencesPo2 {
    Normal: Normal5
  }
  
  export interface Normal5 {
    label: string
    value: string
  }
  
  export interface DegreeOfSeveritySd2 {
    Normal: Normal6
  }
  
  export interface Normal6 {
    label: string
    value: string
  }
  
  export interface FrequencyOfExpositionFe2 {
    Normal: Normal7
  }
  
  export interface Normal7 {
    label: string
    value: string
  }
  
  export interface NumberOfPersonsExposedNp2 {
    Normal: Normal8
  }
  
  export interface Normal8 {
    label: string
    value: string
  }
  