import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { setgroups } from 'process';
import { AddCustomSectionsComponent } from 'src/app/components/add-custom-sections/add-custom-sections.component';
import { AlertModalPage } from 'src/app/components/alert-modal/alert-modal.page';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { isNotEmptyArray } from 'src/app/utilities/utils';
import { ISection, HazardDetails } from './roadmap-interface';

@Component({
  selector: 'app-risk-assessment-sections',
  templateUrl: './risk-assessment-sections.page.html',
  styleUrls: ['./risk-assessment-sections.page.scss'],
})
export class RiskAssessmentSectionsPage implements OnInit {
  customRoadmap: boolean;
  stepperType: string
  roadmapsSteps = [];
  maskAsComplete: boolean;
  project_id: any;
  roadmapDetails: any;
  customSectionList: ISection[] = [];
  customSubSectionList = [];
  eachHazardDetails: any;
  sectionData: any;
  disableMarkAsCmplt: boolean;
  constructor(
    public backendService: BackendCallService,
    public sharedValue: ShareValuesService,
    private router: Router,
    private route: ActivatedRoute,
    public modalController: ModalController,
  ) {
    this.route.queryParams.subscribe((params) => {
      this.roadmapDetails = params;
      this.customRoadmap = JSON.parse(this.roadmapDetails.isCustom)
    });
  }

  ionViewWillEnter() {
    this.route.params.subscribe((params) => {
      if (this.router.getCurrentNavigation()?.extras.state) {
        this.eachHazardDetails =
          this.router.getCurrentNavigation().extras.state.hazardDetails;
        this.sectionData = this.router.getCurrentNavigation().extras.state.sectionData
        if (this.customRoadmap) {
          for (let each of this.customSectionList) {
            if (each.sectionName == this.sectionData.sectionName) {
              console.log(each);
              for (let subSection of each.subSections) {
                if (subSection.subSectionName == this.sectionData.subSectionName) {
                  subSection.steps[this.sectionData.index].hazardDetails = this.eachHazardDetails;
                  console.log(subSection.steps[this.sectionData.index], JSON.stringify(each));
                }
              }
            }
          }
        } else {
          for (let each of this.roadmapsSteps) {
            if (each.sectionName == this.sectionData.sectionName) {
              for (let subSection of each.subSections) {
                if (subSection.subsectionName == this.sectionData.subSectionName) {
                  subSection.steps[this.sectionData.index].hazardDetails = this.eachHazardDetails;
                  console.log(subSection.steps[this.sectionData.index], JSON.stringify(each));
                  //   var myData = Object.keys(this.eachHazardDetails.subsections[0].steps[0].hazardDetails.hazardTypesData).map(key => {
                  //     return this.eachHazardDetails.subsections[0].steps[0].hazardDetails.hazardTypesData[key];
                  // })
                  // console.log(myData);
                }
              }
            }
          }
        }
      }
    });
  }

  ngOnInit() {
    this.sharedValue.extendedRoadMapPayload.isCustom = false;
    // this.customRoadmap?this.sharedValue.extendedRoadMapPayload.isCustom = true:this.sharedValue.extendedRoadMapPayload.isCustom = false;
    // if (!this.customRoadmap) {
    this.getRoadmapSteps()
    // }
  }

  markAsCompleteMethod() {
    this.disableMarkAsCmplt = this.maskAsComplete
  }

  changeRoadMapStatus(status) {
    let lists = this.sharedValue.getRoadMapStatusLists();
    if (isNotEmptyArray(lists)) {
      let matchedLists = lists.find(_li => _li.roadMapId == this.roadmapDetails.id);
      if (matchedLists) {
        matchedLists.status = status
      } else {
        let body = {
          roadMapId: this.roadmapDetails.id,
          status: status
        }
        lists.push(body)
        this.sharedValue.setRoadMapStatusLists(lists)
      }
    } else {
      let body = {
        roadMapId: this.roadmapDetails.id,
        status: status
      }
      this.sharedValue.setRoadMapStatusLists([body])
    }
  }

  extendRoadmap(isCustom: boolean) {
    const payload = {
      roadmapId: this.sharedValue.extendedRoadMapPayload.isCustom ? null : this.roadmapDetails?.id,
      roadmapName: this.roadmapDetails.roadmapName,
      serviceMachineId: this.sharedValue.extendedRoadMapPayload.serviceMachineId,
      userId: "7892B01E-5EE1-4702-81C1-DE9D35EA2FA9",
      isCustom: this.sharedValue.extendedRoadMapPayload.isCustom ? true : this.customRoadmap
    };
    // const sections = isCustom ? this.customSectionList : this.roadmapsSteps.map((each) => {
    let sections;
    if (isCustom) {
      sections = this.customExtendRoadMap(sections);
    } else {
      sections = this.nonCustomExtendRoadMap(sections, isCustom);
    }
    payload['sections'] = sections
    console.log("extendRoadmap Paylaod", JSON.stringify(payload), "sections", sections);
    setTimeout(() => {
      this.extendedRoadMapApiCall(payload, sections)
    }, 200);
  }
  private nonCustomExtendRoadMap(sections: any, isCustom: boolean) {
    sections = this.roadmapsSteps?.map((each) => {
      return {
        sectionName: each.sectionName,
        subsections: (each?.subSections || []).map((subSection) => {
          return {
            subsectionName: subSection.subsectionName,
            steps: (subSection?.steps || []).map((step) => {
              return {
                stepId: isCustom ? "" : step.id,
                stepBody: step.stepBody,
                stepNote: step.stepNote,
                compliant: step.compliance === 'yesCompliant',
                notApplicable: step.compliance === 'notApplicable',
                hazard: step.compliance === 'hazard',
                hazardDetails: step.compliance === 'hazard' ? {
                  hazards: Object.keys(step.hazardDetails?.formData?.hazardTypesData || {}).map((hazardKey) => {
                    const hazardTypesData = step.hazardDetails?.formData?.hazardTypesData[hazardKey];
                    return {
                      hazardTypes: [
                        {
                          type: hazardTypesData.hazardType.type,
                          sources: hazardTypesData.source.map((each) => ({ source: each.source })),
                          consequences: hazardTypesData.consequences.map((eachCon) => ({ source: eachCon.consequence })),
                        }
                      ],
                      hazardRatingNumber: {
                        machineModes: JSON.parse(localStorage.getItem('machineModeList')).map((mode) => ({ mode: mode })),
                        // machineModes: [ // need to work local storage
                        //   {
                        //     mode: JSON.parse(localStorage.getItem('machineModeList'))
                        //   }
                        // ],
                        hrNs: [
                          {
                            hrnType: "Current",
                            version: "string",
                            value: Object.keys(step.hazardDetails.formData?.chrnTable || {}).map((occ) => {
                              return {
                                name: occ,
                                rating: '12',
                                modes: Object.keys(step.hazardDetails.formData?.chrnTable[occ] || {}).map((iMode) => {
                                  return {
                                    modes: iMode,
                                    value: step.hazardDetails.formData?.chrnTable[occ][iMode].value,
                                  };
                                })
                              };
                            }, [])
                          },
                          {
                            hrnType: "Indicative",
                            version: "string",
                            value: Object.keys(step.hazardDetails.formData?.ihrnTable || {}).map((occ) => {
                              return {
                                name: occ,
                                rating: '12',
                                modes: Object.keys(step.hazardDetails.formData?.ihrnTable[occ] || {}).map((iMode) => {
                                  return {
                                    modes: iMode,
                                    value: step.hazardDetails.formData?.ihrnTable[occ][iMode].value
                                  };
                                })
                              };
                            }, [])
                          }
                        ]
                      },
                      hazardName: step.hazardDetails.formData?.hazardName,
                      initialHazard: step.hazardDetails.formData?.pickInitialHazard,
                      countermeasure: step.hazardDetails.formData?.pickControlMeasure,
                      determinedPLR: step.hazardDetails.formData?.determinePlrValue,
                      category: "test",
                      files: [
                        {
                          fileName: "Front View.png",
                          contentType: "image/png",
                          url: "https://google.com"
                        }
                      ]
                    };

                  })
                } : "",
                complaintMedia: step.compliance === 'yesCompliant' ? [
                  {
                    fileName: "Front View.png",
                    contentType: "image/png",
                    url: "https://google.com"
                  }
                ] : ''
              };
            })
          };
        })
      };
    });
    let roadMapStatus = 'In Progress';
    if (this.maskAsComplete)
      roadMapStatus = 'Completed';
    this.changeRoadMapStatus(roadMapStatus);
    return sections;
  }

  private customExtendRoadMap(sections: any) {
    sections = this.customSectionList?.map((each) => {
      return {
        sectionName: each.sectionName,
        subSections: (each?.subSections || []).map((subSection) => {
          return {
            subsectionName: subSection.subSectionName,
            steps: (subSection?.steps || []).map((step) => {
              return {
                stepId: "",
                stepBody: step.stepBody,
                stepNote: step.stepNote,
                compliant: step.compliance === 'yesCompliant',
                notApplicable: step.compliance === 'notApplicable',
                hazard: step.compliance === 'hazard',
                hazardDetails: step.compliance === 'hazard' ? {
                  hazards: Object.keys(step.hazardDetails.formData.hazardTypesData).map((hazardKey) => {
                    const hazardTypesData = step.hazardDetails.formData.hazardTypesData[hazardKey];
                    console.log(hazardKey, hazardTypesData);
                    return {
                      hazardTypes: [
                        {
                          type: hazardTypesData.hazardType.type,
                          sources: hazardTypesData.source.map((each) => ({ source: each.source })),
                          consequences: hazardTypesData.consequences.map((eachCon) => ({ source: eachCon.consequence })),
                        }
                      ],
                      hazardRatingNumber: {
                        machineModes: JSON.parse(localStorage.getItem('machineModeList')).map((mode) => ({ mode: mode })),
                        // machineModes: [ // need to work local storage
                        //   {
                        //     mode: JSON.parse(localStorage.getItem('machineModeList'))
                        //   }
                        // ],
                        hrNs: [
                          {
                            hrnType: "Current",
                            version: "string",
                            value: Object.keys(step.hazardDetails.formData.chrnTable).map((occ) => {
                              return {
                                name: occ,
                                rating: '12',
                                modes: Object.keys(step.hazardDetails.formData.chrnTable[occ]).map((iMode) => {
                                  return {
                                    modes: iMode,
                                    value: step.hazardDetails.formData.chrnTable[occ][iMode].value,
                                  };
                                })
                              };
                            }, [])
                          },
                          {
                            hrnType: "Indicative",
                            version: "string",
                            value: Object.keys(step.hazardDetails.formData.ihrnTable).map((occ) => {
                              return {
                                name: occ,
                                rating: '12',
                                modes: Object.keys(step.hazardDetails.formData.ihrnTable[occ]).map((iMode) => {
                                  return {
                                    modes: iMode,
                                    value: step.hazardDetails.formData.ihrnTable[occ][iMode].value
                                  };
                                })
                              };
                            }, [])
                          }
                        ]
                      },
                      hazardName: step.hazardDetails.formData.hazardName,
                      initialHazard: step.hazardDetails.formData.pickInitialHazard,
                      countermeasure: step.hazardDetails.formData.pickControlMeasure,
                      determinedPLR: step.hazardDetails.formData?.determinePlrValue,
                      category: "test",
                      files: [
                        {
                          fileName: "Front View.png",
                          contentType: "image/png",
                          url: "https://google.com"
                        }
                      ]
                    };

                  })
                } : '', complaintMedia: step.compliance === 'yesCompliant' ? [
                  {
                    fileName: "Front View.png",
                    contentType: "image/png",
                    url: "https://google.com"
                  }
                ] : ''
              };
            })
          };
        })
      };
    });
    return sections;
  }

  extendedRoadMapApiCall(payload, sections) {
    this.backendService.extendRoadmap(payload).subscribe(
      (data: any) => {
        console.log('extendRoadmap API called', data);
        if (data) {
          this.sharedValue.showToast('', data);
          this.router.navigate(window.location.pathname.split('/').slice(0, 6), { queryParamsHandling: 'preserve', replaceUrl: true })
        }
      },
      (err) => { }
    );
  }

  async addSection() {
    const props = { type: "Section", roadmapId: this.roadmapDetails?.id, isExtended: false };
    const modal = await this.modalController.create({
      component: AddCustomSectionsComponent,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      componentProps: props,
      showBackdrop: false,
    });
    await modal.present();
    await modal.onDidDismiss().then((result) => {
      const sections = result.data
      for (let each of sections) {
        this.customSectionList.push(each)
        this.stepperType = this.customSectionList[0].sectionName
        // this.getRoadmapSteps()
      }
      console.log(result.data, this.customSectionList);
    });
  }

  async addSubSection(section, isExtended?, eachStep?) {
    let props;
    if (!isExtended) {
      props = { type: "Sub Section", roadmapId: this.roadmapDetails?.id, roadMapSectionId: section.section_Id, isExtended: false };
    } else {
      props = section
    }
    console.log(props);
    const modal = await this.modalController.create({
      component: AddCustomSectionsComponent,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      componentProps: props,
      showBackdrop: false,
    });
    await modal.present();
    await modal.onDidDismiss().then((result) => {
      const resultData = result.data;
      console.log(result, resultData);
      if (resultData.type == "Change Roadmap Name") {
        this.router.navigate([window.location.pathname], { queryParams: { roadmapName: resultData.name.roadmap }, replaceUrl: true, queryParamsHandling: 'merge' });
        this.sharedValue.extendedRoadMapPayload.isCustom = true;
        eachStep.steps.push({ stepBody: '', stepNote: '', compliant: '', notApplicable: '', hazard: '', compliance: '' })
        console.log("sdffs", resultData.name.roadmap, this.sharedValue.extendedRoadMapPayload.isCustom);

      } else {
        const sections = result.data;
        section.subSections = section.subSections || [];
        section.subSections.push(...sections);
        console.log("result", result.data, section);
      }
    });
  }
  goBack() {
    this.router.navigate(window.location.pathname.split('/').slice(0, 6), { queryParamsHandling: 'preserve', replaceUrl: true })
  }

  addStep(eachStep, isExtended?) {
    eachStep.steps = eachStep.steps || [];
    console.log(isExtended, this.sharedValue.extendedRoadMapPayload.isCustom, eachStep.steps);
    if (isExtended && !this.sharedValue.extendedRoadMapPayload.isCustom) {
      const props = { type: "Change Roadmap Name", isExtended: true };
      this.addSubSection(props, isExtended, eachStep)

    } else {
      eachStep.steps.push({ stepBody: '', stepNote: '', compliant: '', notApplicable: '', hazard: '', compliance: '' })
    }

  }

  getRoadmapSteps() {
    console.log("getRoadmapSteps", this.roadmapDetails?.id, this.customRoadmap);//this.roadmapDetails?.id//"89136879-ab0d-435d-b164-37a8e8641269"
    this.backendService.getRoadmapSteps(this.roadmapDetails?.id, "7892B01E-5EE1-4702-81C1-DE9D35EA2FA9", this.sharedValue.extendedRoadMapPayload.serviceMachineId).subscribe(
      (data: any) => {
        // if (data.value) {
        if (this.customRoadmap == true) {
          console.log("customRoadmap customSectionList");
          this.customSectionList = data.section;
          this.stepperType = this.customSectionList[0]?.sectionName
        } else if (this.customRoadmap == false) {
          console.log("customRoadmap roadmapsSteps");
          this.roadmapsSteps = data.section;
          this.stepperType = this.roadmapsSteps[0]?.sectionName
        }
        // }
      },
      (err) => { }
    );
  }

  nextStepper(list: any[], index) {
    console.log("nextStepper", this.roadmapsSteps);
    this.stepperType = list[index + 1].sectionName;
  }

  checkPreviousStepper(previousStepper) {

  }

  prevoiusStepper(list: any[], index) {
    this.stepperType = list[index - 1].sectionName;
  }

  changeStepper(type, list: any[]) {
    console.log("changeStepper");
    this.checkInputAndRedirect(type, list);
  }

  checkInputAndRedirect(type, list: any[]) {
    console.log("checkInputAndRedirect", type);
    this.stepperType = type;
  }

  async closeBox() {
    let props = {
      isOfferCreation: true,
    };
    const msg = `Are You Sure You Want to Cancel?`;
    props['alertContent'] = msg;
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const {
      data: { isOfferCreationConfirmClose },
    } = await modal.onWillDismiss();
    if (isOfferCreationConfirmClose) {
      console.log(isOfferCreationConfirmClose);
      this.router.navigate(window.location.pathname.split('/').slice(0, 6), { queryParamsHandling: 'preserve', replaceUrl: true })
    }
  }
}

