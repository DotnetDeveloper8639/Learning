import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { ShareValuesService } from '../../../services/sharedValues/share-values.service';
@Component({
  selector: 'app-machine-limits',
  templateUrl: './machine-limits.component.html',
  styleUrls: ['./machine-limits.component.scss'],
})
export class MachineLimitsComponent implements OnInit {
  @Input() machineLimits: any = {};
  @ViewChild('machineLimitsForm') form: NgForm;
  files = [];
  machineModeList = []//['Normal Mode', 'Set-up Mode', 'Maintanance Mode', 'Other Mode'];
  lifeCyclePhaseList = []//['Transport','Assembly','Installation','Put into Service', 'Use', 'Disassmebly',"Take out of service", 'Waste disposal','Others']
  getMachineModesLoading: boolean;
  getLifeCyclePhasesLoading: boolean;
  imageSrc: string | ArrayBuffer;
  constructor(public backendService: BackendCallService,public sharedValue:ShareValuesService) { }

  ngOnInit() { }

  uploadFile(fileChangeEvent) {
    // this.files.push(fileChangeEvent.target.files[0].name);
    // console.log("fileChangeEvent",fileChangeEvent,fileChangeEvent.target.files[0].name,this.files);
    const self = this;
    if (fileChangeEvent.target.files && fileChangeEvent.target.files[0]) {
      const file = fileChangeEvent.target.files[0];
      const reader = new FileReader();
      reader.onload = e => {
        self.imageSrc = reader.result
        self.files.push(self.imageSrc);
      };
      console.log(self.imageSrc, reader.result);
      reader.readAsDataURL(file);
    }
    console.log("fileChangeEvent", fileChangeEvent, fileChangeEvent.target.files[0].name, this.files);
  }

  getMachineModesList() {
    this.getMachineModesLoading = true;
    this.backendService.getMachineModesList()
      .subscribe(
        (data: any) => {
          this.machineModeList = data;
          this.getMachineModesLoading = false;
          console.log('getProjectId API called', data);
        },
        (err) => {
          this.getMachineModesLoading = false;
        }
      );
  }

  getLifeCyclePhasesList() {
    this.getLifeCyclePhasesLoading = true;
    this.backendService.getLifeCyclePhasesList()
      .subscribe(
        (data: any) => {
          this.lifeCyclePhaseList = data;
          this.getLifeCyclePhasesLoading = false;
          console.log('getProjectId API called', data);
        },
        (err) => {
          this.getLifeCyclePhasesLoading = false;
        }
      );
  }

}
