import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RiskAssessmentPageRoutingModule } from './risk-assessment-routing.module';

import { RiskAssessmentPage } from './risk-assessment.page';
import { componentModule } from 'src/app/components/components.module';
import { MachineLimitsComponent } from './machine-limits/machine-limits.component';
import { RoadmapComponent } from './roadmap/roadmap.component';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
  imports: [
    CommonModule,
    componentModule,
    FormsModule,
    // MachineLimitsComponent,
    // RoadmapComponent,
    IonicModule,
    NgSelectModule,
    RiskAssessmentPageRoutingModule
  ],
  declarations: [RiskAssessmentPage,RoadmapComponent,MachineLimitsComponent]
})
export class RiskAssessmentPageModule {}
