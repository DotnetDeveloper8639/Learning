import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import {
  ModalController
} from '@ionic/angular';
import { AddCustomRoadmapsComponent } from 'src/app/components/add-custom-roadmaps/add-custom-roadmaps.component';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
@Component({
  selector: 'app-roadmap',
  templateUrl: './roadmap.component.html',
  styleUrls: ['./roadmap.component.scss'],
})
export class RoadmapComponent implements OnInit {
  @Input() roadmapCmpnt: any = {};
  @ViewChild('roadmapDetailsForm') form: NgForm;
  roadMapList = [{}];
  getRoadMapListLoading: boolean;
  constructor(public modalController: ModalController,public backendService: BackendCallService) { }

  ngOnInit() {}

  async openCustomRoadmaps(){
    // let props = { type };
    const modal = await this.modalController.create({
      component: AddCustomRoadmapsComponent,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      // componentProps: props,
      showBackdrop: false,
    });
    await modal.present();
    await modal.onDidDismiss().then((result) => {
      console.log(result.data);
      
    });
}

getRoadmapList() {
  this.getRoadMapListLoading = true;
  this.backendService.getRoadmapList()
    .subscribe(
      (data: any) => {
        this.roadMapList = data;
        // this.roadMapList.forEach((obj, i) => obj['isCustomRoadMap'] = false);
        this.getRoadMapListLoading = false;
        console.log('getProjectId API called', data);
      },
      (err) => {
        this.getRoadMapListLoading = false;
      }
    );
}
}
