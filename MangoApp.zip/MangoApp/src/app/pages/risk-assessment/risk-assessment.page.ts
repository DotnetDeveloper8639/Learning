import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { MachineLimitsComponent } from './machine-limits/machine-limits.component';
import { RoadmapComponent } from './roadmap/roadmap.component';
import { Location } from '@angular/common';
import { ModalController, PopoverController } from '@ionic/angular';
import { AlertModalPage } from 'src/app/components/alert-modal/alert-modal.page';
@Component({
  selector: 'app-risk-assessment',
  templateUrl: './risk-assessment.page.html',
  styleUrls: ['./risk-assessment.page.scss'],
})
export class RiskAssessmentPage implements OnInit {
  stepperType: string = 'ml';
  stepperList = [
    {
      title: 'Machine Limits',
      key: 'ml',
      component: 'machineLimitCmpnt',
    },
    {
      title: 'RoadMaps',
      key: 'rm',
      component: 'roadMapCmpnt',
    }
  ];
  @ViewChild('machineLimitsRef')
  machineLimitCmpnt: MachineLimitsComponent;

  @ViewChild('roadmapCmpntRef')
  roadmapCmpnt: RoadmapComponent;

  machine_details:any

  stepperCompletedInputValue = {
    machineLimitsDetails: false,
    roadmapDetails: false,
  };
  project_id: any;
  constructor(public backendService: BackendCallService,public location: Location, public sharedValue: ShareValuesService, private router: Router, private route: ActivatedRoute,public popoverController: PopoverController,
    public modalController: ModalController) {
    this.route.queryParams.subscribe((params) => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.project_id = this.router.getCurrentNavigation().extras.state.project_id;
        this.machine_details = this.router.getCurrentNavigation().extras.state.machine_details;
        console.log('each roadmapDetails', this.project_id,this.machine_details);
      }
    });
  }

  ngOnInit() {
  }
  changeStepper(type) {
    this.checkInputAndRedirect(type);
  }
  checkInputAndRedirect(type) {
    const stepperOrder = this.stepperList.map((each) => each.key);
    if (stepperOrder.indexOf(type) < stepperOrder.indexOf(this.stepperType)) {
      this.stepperType = type;
    } else {
      const previousStepper = this.stepperType;
      for (let each of this.stepperList) {
        if (previousStepper == each.key) {
          if (this[each.component].form.valid) {
            this.stepperType = type;
          } else {
            this[each.component].form.form.markAllAsTouched();
          }
        }
      }
    }
  }
  nextStepper() {
    this.checkPreviousStepper(this.stepperType);
  }

  checkPreviousStepper(previousStepper) {
    if (previousStepper == 'ml') {
      if (this.machineLimitCmpnt.form.valid) {
        console.log(this.machineLimitCmpnt.form.value);
        this.stepperType = 'rm';
      } else {
        this.machineLimitCmpnt.form.form.markAllAsTouched();
      }
    }
    else if (previousStepper == 'rm') {
      if (this.roadmapCmpnt.form.valid) {
        console.log(this.roadmapCmpnt.form.valid, this.roadmapCmpnt.form.value.roadmap);
        this.sharedValue.selectedRoadmapsList = this.roadmapCmpnt.form.value.roadmap;
        // let navigationExtras: NavigationExtras = {
        //   state: {
        //     project_id: this.project_id
        //   },
        // };
        this.machineLimits()
        // this.configureRoadmap()
      } else {
        this.roadmapCmpnt.form.form.markAllAsTouched();
      }
    }
  }
  configureRoadmap() {
    const payload = {
      serviceMachineId: this.machine_details?.serviceMachine_Id[0]?.serviceMachineId,
      roadmaps: this.sharedValue.selectedRoadmapsList
    }
    this.backendService
      .configureRoadmap(payload)
      .subscribe(
        (data: any) => {
          console.log('configureRoadmap API called', data);
          this.sharedValue.showToast('', data);
          // this.router.navigateByUrl(`/project-management/project-detail/${this.project_id}/machine-details`)
          this.location.back()
        },
        (err) => {
        }
      );
  }
  machineLimits() {
    this.sharedValue.machineModeList=this.machineLimitCmpnt.form.value.machineMode
    localStorage.setItem('machineModeList',JSON.stringify(this.machineLimitCmpnt.form.value.machineMode));
    console.log("machineLimits API",JSON.parse(localStorage.getItem('machineModeList')));
    const payload = { 
      machineMode: this.machineLimitCmpnt.form.value.machineMode,
      machineLifeCyclePhase: this.machineLimitCmpnt.form.value.specifyLifeCycle,
      machineLimitations: this.machineLimitCmpnt.form.value.limitationOfMachine,
      dimensions: this.machineLimitCmpnt.form.value.dimensions,
      additionalLimis: this.machineLimitCmpnt.form.value.additionalLimitation,
      serviceMachineId: this.machine_details?.serviceMachine_Id[0]?.serviceMachineId,
      files: [
        {
          fileName: "",
          contentType: "",
          url: ""
        }
      ]
    }
    this.backendService
      .machineLimits(payload)
      .subscribe(
        (data: any) => {
          console.log('machineLimits API called', data);
          this.configureRoadmap()
        },
        (err) => {
        }
      );
  }

  previous(){
    this.stepperType="ml"
  }

  async closeBox() {
    let props = {
      isOfferCreation: true,
    };
    const msg = `Are You Sure You Want to Cancel?`;
    props['alertContent'] = msg;
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const {
      data: { isOfferCreationConfirmClose },
    } = await modal.onWillDismiss();
    if (isOfferCreationConfirmClose) {
      console.log(isOfferCreationConfirmClose);
      // this.router.navigate(['../'], { replaceUrl: true ,queryParamsHandling:'preserve'});
      this.location.back()
    }
  }

}
