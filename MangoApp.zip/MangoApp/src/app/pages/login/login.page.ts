import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MsalService } from '@azure/msal-angular';
import { TranslateService } from "@ngx-translate/core";
import { TranslateModule } from '@ngx-translate/core';
import { LanguageSupportService } from 'src/app/services/language-support.service';
import { UserAuthService } from 'src/app/services/user-auth/user-auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  formData = { email: '', password: '' };
  loginDisplay = false;
  userData: any;
  selectedLanguage: any;
  language: string = this.translateService.currentLang;
  constructor(public userAuthService: UserAuthService, private router: Router,
    private authService: MsalService, private translateService: TranslateService, private tModule: TranslateModule,
    private serviceMulti: LanguageSupportService) {
    this.selectedLanguage = this.serviceMulti.getDefaultLanguage();
  }

  ngOnInit() { }

  login() {
    //this.router.navigate(['/dashboard']);
    // this.userAuthService.login();
  }

  loginWithSSO() {
    this.userAuthService.login();
    // this.authService.loginPopup().subscribe({
    //   next: (result) => {
    //     console.log(result, JSON.stringify(result));
    //     this.userData = result.account;
    //     this.setLoginDisplay();
    //   },
    //   error: (error) => console.log(error),
    // });
  }

  setLoginDisplay() {
    this.loginDisplay = this.authService.instance.getAllAccounts().length > 0;
    console.log('setLoginDisplay', this.loginDisplay, this.userData.name);
    let silentRequest = {
      scopes: ['Mail.Read'],
      account: this.userData.username,
      forceRefresh: false,
    };
    console.log('silentRequest', silentRequest);
    this.router.navigate(['/dashboard']);
    // this.router.navigate(['/dashboard'], {
    //   queryParams: { userName: this.userData.name }
    // });
  }

  languageChange() {
    this.serviceMulti.setLanguage(this.selectedLanguage);  // add this
  }
}
