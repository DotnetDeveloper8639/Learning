import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import {
  ModalController,
  NavController,
  PopoverController,
} from '@ionic/angular';
import { AlertModalPage } from 'src/app/components/alert-modal/alert-modal.page';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { addUniqueEntry, isNotEmptyArray, isNotNullAndUndefined, isObjectEmpty } from 'src/app/utilities/utils';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { AddMachineToBucketComponent } from 'src/app/components/add-machine-to-bucket/add-machine-to-bucket.component';
import { StatusPopoverComponent } from 'src/app/components/status-popover/status-popover.component';
import { FilterMoodalComponent } from 'src/app/components/filter-moodal/filter-moodal.component';
import { SearchModalComponent } from 'src/app/components/search-modal/search-modal.component';
import * as moment from 'moment';
import { ProjectManagementLayoutPage } from '../project-management-layout/project-management-layout.page';
import { Location } from '@angular/common';
import { UserAuthService } from 'src/app/services/user-auth/user-auth.service';


@Component({
  selector: 'app-project-detail',
  templateUrl: './project-detail.page.html',
  styleUrls: ['./project-detail.page.scss'],
})
export class ProjectDetailPage implements OnInit {
  projectList: any;
  selectedSegment = 'projectInformation_segment';
  selectData = 'service_Details';
  selectServiceOrderOptions = [];
  service = ['Risk Assessment', 'Risk Re-Assessment', 'Training On-Site', 'Training Off-Site', 'Retrofitting']
  serviceType = [];
  prodetailsData: any = {
    selectOrder: null,
    serviceType: null,
  };
  show: boolean = false;
  IsEmptyCard: boolean = false;
  selectElement: any;
  disDropDown: any;
  disableDropdwn: boolean = false;
  shouldShowMachineAndOverviewService: boolean = false;
  serviceOrderLists: any = [];
  serviceTabData: any;
  machineListInfo: any;
  isAllMachineSelected = false;
  isMyMachinesTabAllSelected = false;
  isAnyMachineListSelected: boolean = false;
  machineListViewType = 'grid-view';
  machineSegmentType = 'all-machine';
  myMachineLists: any = [];
  allMachineListsInfo = [];
  private project_id: any;
  enddatelocal: any;
  private encrypted_project_id: any;
  isAllMachineCheckboxSelected: boolean = false;
  allBucketLists = [];
  logActualHoursInfo = [];
  islogActualHoursEditing: boolean = false
  logActualHoursListsToEdit = [];
  statusStepperData: any[];

  constructor(
    private route: ActivatedRoute,
    public navCtrl: NavController,
    public modalController: ModalController,
    public backendService: BackendCallService,
    public popController: PopoverController,
    public sharedService: ShareValuesService,
    private router: Router,
    private location: Location,
    public popoverController: PopoverController,
    public userAuth: UserAuthService,
  ) { }

  ngOnInit() {
    // document.addEventListener('newMachine',(ev:CustomEvent)=> {
    //   console.log(ev.detail);
    //   this.machineListInfo.push(...ev.detail);
    // });
    localStorage.removeItem(('machineModeList'))
    this.encrypted_project_id = this.route.snapshot.params.id;
    const queryParams = this.route.snapshot.queryParams;
    console.log('queryParams is :', queryParams);
    if (queryParams.serviceType) {
      this.prodetailsData.serviceType = queryParams.serviceType
    }
    if (queryParams.orderId) {
      this.prodetailsData.selectOrder = queryParams.orderId;
    }
    this.encrypted_project_id && this.initializeProjectDetailScreen();
    ProjectManagementLayoutPage.searchServiceData.subscribe((res) => {
      this.getServiceListInfo(res.projectListInfo);
      this.getMachineListsInfo(res.machineListInfo);
      this.getBucketListInfo(res.bucketListInfo);
    })
  }

  ionViewWillEnter() {
    //console.log("ion view enter");
  }

  goBack() {
    // this.location.back();
    this.router.navigate([this.route.snapshot.data.previousPage], { replaceUrl: true });

  }

  async openAddMachinePopover(ev: any, type,) {
    let each_service = { serviceType: "", page: "projectDetails" };
    each_service.serviceType = this.prodetailsData.serviceType;
    console.log('Sevice popover', this.prodetailsData.serviceType);
    const props = { type, each_service };
    const popover = await this.popoverController.create({
      component: StatusPopoverComponent,
      cssClass: 'my-custom-class',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      console.log(result);
      if (result.data == 'edit-service') {
        console.log(result.data);
        this.selectedSegment = 'serviceDetails';
      }
    });
  }

  async initializeProjectDetailScreen() {
    this.getProjectDetail();
    this.getProjectServiceOrder();
  }

  getProjectDetail() {
    ProjectManagementLayoutPage.projectDetails.subscribe((res) => {
      if (!isObjectEmpty(res)) {
        this.projectList = res;
        this.enddatelocal = moment(this.projectList.end_Date).format('MM/DD/YYYY HH:mm:ss');
        // moment(from, 'YYYY-MM-DDTHH:mm:ssZ').format()
        // tz(res.event_summary.event.timezone).format('MM/DD/YYYY HH:mm:ss'))
        if (this.projectList && this.projectList.project_Id) this.project_id = this.projectList.project_Id
        if (!isObjectEmpty(this.projectList.customerDetails))
          this.projectList.customerDetails.address =
            this.combineFullAddress(this.projectList.customerDetails);
      }
    })
  }

  getProjectServiceOrder() {
    ProjectManagementLayoutPage.projectServiceDetails.subscribe((res) => {
      if (isNotEmptyArray(res)) {
        let tmpServiceOrder = [];
        this.serviceOrderLists = res;
        res.forEach((_r) => {
          if (isNotEmptyArray(_r.order_Details)) {
            _r.order_Details.forEach((_od) => { if (_od.id) tmpServiceOrder.push(_od.id); });
          }
        });
        this.selectServiceOrderOptions = [...tmpServiceOrder];
      }
    })
  }

  // goBack() {
  //   this.navCtrl.pop();
  // }

  openDashboardCustomization(isDashboardCustomize) {
    const msg = `Are You Sure You Want to Reset to default widgets?`;
    this.openAlertModal(msg, isDashboardCustomize);
  }



  async openAlertModal(msg, isDashboardCustomize = false) {
    let props = { isDashboardCustomize };
    props['alertContent'] = msg;
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-dashboard-customization-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
  }

  combineFullAddress(address) {
    let fullAddress = null;
    if (!isObjectEmpty(address)) {
      const { street, city, zipcode } = address;
      fullAddress = `${street},${city}, ${zipcode}`;
    }
    return fullAddress;
  }

  selectevent(ev: any) {
    this.prodetailsData.serviceType = ev;
    this.selectElement = this.prodetailsData.serviceType;
    if ((this.selectElement = '')) {
      this.IsEmptyCard = false;
      console.log(this.IsEmptyCard);
    } else {
      if (
        !isObjectEmpty(this.prodetailsData) &&
        this.prodetailsData.selectOrder &&
        this.prodetailsData.serviceType
      ) {
        this.getServiceAndMachineListInfo(
          this.prodetailsData.selectOrder,
          this.prodetailsData.serviceType,
          this.projectList.project_Id
        );
      }
    }
  }

  async getServiceAndMachineListInfo(orderId, serviceType, projectId) {
    this.router.navigate([window.location.pathname], { queryParams: { orderId, serviceType, projectId }, replaceUrl: true });
  }
  // async getServiceAndMachineListInfo(orderId, serviceType, projectId) {
  //   await this.getServiceListInfo(orderId, serviceType, projectId);
  //   await this.getMachineListsInfo(orderId, serviceType, projectId);
  //   this.getBucketListInfo(projectId, orderId, serviceType);
  // }


  getServiceListInfo(res) {
    if (!isObjectEmpty(res)) {
      this.serviceTabData = this.sharedService.mapServicesListInfo(res);
      if (!isObjectEmpty(this.serviceTabData)) {
        if (
          this.prodetailsData.serviceType !==
          'Training On-Site' &&
          this.prodetailsData.serviceType !==
          'Training Off-Site'
        )
          this.shouldShowMachineAndOverviewService = true;
        else this.shouldShowMachineAndOverviewService = false;
        this.IsEmptyCard = true;
      }
    }
  }

  refreshMachineListsInfo(orderId, serviceType, projectId) {
    this.backendService.getProjectDetailMachineListsInfo(orderId, serviceType, projectId).then(res => {
      if (isNotEmptyArray(res)) {
        this.machineListInfo = [...res];
        this.constructLogActualHoursData();
      }
    }).catch((err) => {
      console.log('getting error for fetching project detail machine info:', err)
    });
  }

  getMachineListsInfo(res: any[]) {
    if (isNotEmptyArray(res)) {
      this.machineListInfo = [...res];
      this.constructLogActualHoursData();
      this.statusStepperData = this.sharedService.fedExStatusStepperData;
    }
  }
  // getServiceListInfo(orderId, serviceType, projectId) {
  //   if (orderId && serviceType && projectId) {
  //     return this.backendService
  //       .getProjectDetailServiceListsInfo(orderId, serviceType, projectId)
  //       .then((res) => {
  //         if (!isObjectEmpty(res)) {
  //           this.serviceTabData = this.sharedService.mapServicesListInfo(res);
  //           if (!isObjectEmpty(this.serviceTabData)) {
  //             if (
  //               this.prodetailsData.serviceType !==
  //               'Training On-Site' &&
  //               this.prodetailsData.serviceType !==
  //               'Training Off-Site'
  //             )
  //               this.shouldShowMachineAndOverviewService = true;
  //             else this.shouldShowMachineAndOverviewService = false;
  //             this.IsEmptyCard = true;
  //           }
  //         }
  //       })
  //       .catch((err) => {
  //         console.log(
  //           'getting error for fetching order detail service info:',
  //           err
  //         );
  //         if (err && err.error == 'No Services Found') {
  //           this.IsEmptyCard = false;
  //           this.serviceTabData = {};
  //         }
  //       });
  //   }
  // }

  // getMachineListsInfo(orderId, serviceType, projectId) {
  //   if (orderId && serviceType && projectId) {
  //     return this.backendService
  //       .getProjectDetailMachineListsInfo(orderId, serviceType, projectId)
  //       .then((res) => {
  //         if (isNotEmptyArray(res)) {
  //           this.machineListInfo = res;
  //           this.constructLogActualHoursData();
  //           this.statusStepperData = this.sharedService.fedExStatusStepperData;
  //         }
  //       })
  //       .catch((err) => {
  //         console.log(
  //           'getting error for fetching project detail machine info:',
  //           err
  //         );
  //       });
  //   }
  // }

  constructLogActualHoursData() {
    if (isNotEmptyArray(this.machineListInfo)) {
      this.logActualHoursInfo = this.sharedService.constructLogActualHoursLists(this.machineListInfo);
    }
  }

  openDrowDown(ev: any) {
    this.prodetailsData.selectOrder = ev;
    this.disDropDown = this.prodetailsData.selectOrder;
    if ((this.disDropDown = '')) {
      this.disableDropdwn = false;
      console.log(this.disableDropdwn);
    } else {
      if (isNotEmptyArray(this.serviceOrderLists)) {
        this.serviceOrderLists.forEach((_so) => {
          if (isNotEmptyArray(_so.service_Details)) {
            let tempServiceOrderLists = [];
            _so.service_Details.forEach((_sd) => {
              // let body = {
              //   serviceType: _sd.service_Type,
              // };
              if (_sd.service_Type) tempServiceOrderLists.push(_sd.service_Type)
            });
            this.serviceType = [...tempServiceOrderLists];
          } else this.serviceType = this.service;
        });
      } else this.serviceType = this.service;
      this.disableDropdwn = true;
    }
  }

  changeMachineSegment(type) {
    if (type == 'my-machine') this.machineSegmentType = type
    else if (type == 'team-machine') this.machineSegmentType = type
    else this.machineSegmentType = type
  }

  changeMachineListView(type) {
    if (type == 'layout') this.machineListViewType = 'layout-view'
    else this.machineListViewType = 'grid-view'
  }

  changeAllSelectedMachineValue() {
    if (this.machineSegmentType == 'all-machine') {
      this.allMachineListsInfo.forEach(_almi => _almi.isChecked = this.isAllMachineSelected);
    } else if (this.machineSegmentType == 'my-machine') {
      this.myMachineLists.forEach(_ml => {
        _ml.isChecked = this.isMyMachinesTabAllSelected;
        this.changeMachineTypeCheckedValue(_ml);
      })
    }
  }

  checkMyMachieAllCheckboxSelectedOrnot(mymachineInfo) {
    if (this.machineSegmentType == 'all-machine') {
      let matchedM = this.allMachineListsInfo.find(_mml => _mml.bucketId == mymachineInfo.bucketId);
      if (matchedM && isNotEmptyArray(matchedM.machineInfo)) {
        let eCh = matchedM.machineInfo.every(_mmi => _mmi.isChecked);
        if (eCh) matchedM.isChecked = eCh;
        let eUc = matchedM.machineInfo.every(_mmi => !_mmi.isChecked);
        if (eUc) matchedM.isChecked = eCh;
        let anyMachineSelected = false;
        this.allMachineListsInfo.forEach(_amli => {
          let anySelected = _amli.machineInfo.some(_mi => _mi.isChecked)
          if (anySelected) anyMachineSelected = true
        })
        this.isAnyMachineListSelected = anyMachineSelected
        let al = this.allMachineListsInfo.some(_amlif => _amlif.isChecked);
        if (!al) this.isAllMachineSelected = al;
      }
    } else if (this.machineSegmentType == 'my-machine') {
      let matchedM = this.myMachineLists.find(_mml => _mml.machineType == mymachineInfo.machineType);
      if (matchedM && isNotEmptyArray(matchedM.machineInfo)) {
        let eCh = matchedM.machineInfo.every(_mmi => _mmi.isChecked);
        if (eCh) matchedM.isChecked = eCh;
        let eUc = matchedM.machineInfo.every(_mmi => !_mmi.isChecked);
        if (eUc) matchedM.isChecked = eCh;
      }
    }
  }

  changeMachineTypeCheckedValue(mymachine) {
    if (this.machineSegmentType == 'all-machine') {
      if (mymachine && mymachine.machineType) {
        let matchedMyMachine = this.allMachineListsInfo.find(_mml => _mml.bucketId === mymachine.bucketId);
        if (matchedMyMachine && matchedMyMachine.bucketId && isNotEmptyArray(matchedMyMachine.machineInfo)) {
          matchedMyMachine.machineInfo.forEach(_mmminfo => _mmminfo.isChecked = matchedMyMachine.isChecked)
        }
      }
    } else if (this.machineSegmentType == 'my-machine') {
      if (mymachine && mymachine.machineType) {
        let matchedMyMachine = this.myMachineLists.find(_mml => _mml.machineType === mymachine.machineType);
        if (matchedMyMachine && matchedMyMachine.machineType && isNotEmptyArray(matchedMyMachine.machineInfo)) {
          matchedMyMachine.machineInfo.forEach(_mmminfo => _mmminfo.isChecked = matchedMyMachine.isChecked)
        }
      }
    }
  }

  changeAllSelectedCheckboxValue() {
    this.machineListInfo.forEach(_mli => _mli.isChecked = this.isAllMachineCheckboxSelected)
    if (this.machineListViewType == 'layout-view') this.changeMachineCheckboxSelection()
  }

  changeMachineCheckboxSelection(machineList?) {
    this.isAnyMachineListSelected = this.machineListInfo.some(_mli => _mli.isChecked);
    if (!this.isAnyMachineListSelected) this.isAllMachineCheckboxSelected = this.isAnyMachineListSelected;
  }

  getBucketListInfo(bucketListInfo: any[]) {
    if (isNotEmptyArray(bucketListInfo)) {
      const buckets = bucketListInfo.filter(_bli => isNotEmptyArray(_bli.machines))
      this.allBucketLists = buckets
    } else this.allBucketLists = []
  }
  // async getBucketListInfo(projectId, orderId, serviceType) {
  //   let bucketListInfo = await this.getBucketInfo(projectId, orderId, serviceType);
  //   if (isNotEmptyArray(bucketListInfo)) {
  //     const buckets = bucketListInfo.filter(_bli => isNotEmptyArray(_bli.machines))
  //     this.allBucketLists = buckets
  //   } else this.allBucketLists = []
  // }

  async addToBucket(shouldCreateOnlyNewBucket = false, shouldEditBucket = false) {
    let bucketInfo = [];
    const { selectOrder, serviceType } = this.prodetailsData;
    if (!shouldCreateOnlyNewBucket) bucketInfo = await this.getBucketInfo(this.project_id, selectOrder, serviceType);
    let props = { bucketLists: bucketInfo, shouldCreateOnlyNewBucket, shouldEditBucket };
    const modal = await this.modalController.create({
      component: AddMachineToBucketComponent,
      cssClass: 'add-machine-to-bucket-class',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const { data: { bucketName, bucketId, shouldAddToBucket, shouldConstructAndAddToBucket, isBucketUpdated, updatedBucketLists, deletedBucketLists } } = await modal.onWillDismiss();
    //for adding some machine to bucket by creating new bucket and also to create new bucket only
    if (bucketName && (shouldAddToBucket || shouldConstructAndAddToBucket)) await this.addBucketNameOrAddMachineToBucket(bucketName, !shouldAddToBucket)
    //if (bucketName && !shouldAddToBucket) this.constructMyMachineSegmentData(bucketName)

    //adding machine to already existing bucket
    if (bucketId && (!shouldAddToBucket && !shouldConstructAndAddToBucket)) this.addMachineToExistingBucket(bucketId)
    if (isBucketUpdated && isNotEmptyArray(updatedBucketLists)) await this.editBucketLists(updatedBucketLists)
    if (isBucketUpdated && isNotEmptyArray(deletedBucketLists)) this.deleteBucketLists(deletedBucketLists)
  }

  getBucketInfo(projectId, orderId, serviceType) {
    let bucketList = [];
    return this.backendService.getBucketLists(projectId, orderId, serviceType)
      .then(res => {
        if (isNotEmptyArray(res)) bucketList = res;
        return bucketList
      }).catch(err => {
        console.log('error in getting bucket info :', err);
        return bucketList;
      })
  }

  // constructAllMachinesSegmentData(bucketname?) {
  //   const allMachineInfo = JSON.parse(JSON.stringify(this.machineListInfo));
  //   if (isNotEmptyArray(allMachineInfo)) {
  //     allMachineInfo.forEach(_ami => {
  //       let body = {
  //         machineType: _ami.bucketName.bucket_Name,
  //         bucketId: _ami.bucketName.bucket_Id,
  //         machineInfo: []
  //       }
  //       if (isNotEmptyArray(this.allMachineListsInfo)) {
  //         let matchedMyMachineList = this.allMachineListsInfo.find(_aml => _aml.machineType == body.machineType);
  //         if (matchedMyMachineList) matchedMyMachineList.machineInfo.push(_ami)
  //         else {
  //           body.machineInfo.push(_ami)
  //           this.allMachineListsInfo.push(body);
  //         }
  //       } else {
  //         body.machineInfo.push(_ami)
  //         this.allMachineListsInfo.push(body);
  //       }
  //     });
  //   }
  // }

  // constructMyMachineSegmentData(bucketname) {
  //   const allMachineInfo = JSON.parse(JSON.stringify(this.allMachineListsInfo));
  //   if (isNotEmptyArray(allMachineInfo)) {
  //     allMachineInfo.forEach(_ami => {
  //       if (isNotEmptyArray(_ami.machineInfo)) {
  //         _ami.machineInfo.forEach(_ml => {
  //           if (_ml.isChecked) {
  //             let body = {
  //               machineType: bucketname,
  //               machineInfo: [],
  //               bucketId: _ami.bucketId
  //             }
  //             if (isNotEmptyArray(this.myMachineLists)) {
  //               let matchedMyMachineList = this.myMachineLists.find(_mml => _mml.machineType == bucketname);
  //               if (matchedMyMachineList) matchedMyMachineList.machineInfo.push(_ml)
  //               else {
  //                 body.machineInfo.push(_ml)
  //                 this.myMachineLists.push(body);
  //               }
  //             } else {
  //               body.machineInfo.push(_ml)
  //               this.myMachineLists.push(body);
  //             }
  //           }
  //         });
  //       }
  //     })
  //     if (isNotEmptyArray(this.myMachineLists)) this.machineSegmentType = 'my-machine';
  //     this.myMachineLists.forEach(_ml => {
  //       if (isNotEmptyArray(_ml.machineInfo)) {
  //         _ml.machineInfo.forEach(_minfo => _minfo.isChecked = false)
  //       }
  //     })
  //   }
  // }

  addMachineToExistingBucket(bucketId) {
    let selectedMachineIds = [];
    if (bucketId && isNotEmptyArray(this.machineListInfo)) {
      const allMachineInfo = JSON.parse(JSON.stringify(this.machineListInfo));
      allMachineInfo.forEach(_am => { if (_am.isChecked) addUniqueEntry(selectedMachineIds, _am.machine_Id) });
      this.createBucketOnlyOrCreateBucketAndAddMachineOrAddMachineToExistingBucket('', bucketId, selectedMachineIds, false, true);
    }
  }

  addBucketNameOrAddMachineToBucket(bucketName, shouldCreateNewBucketAndAddMachine = false) {
    if (bucketName) {
      let selectedMachineIds = []
      //when creating new bucket and adding machine into it
      if (shouldCreateNewBucketAndAddMachine) {
        const allMachineInfo = JSON.parse(JSON.stringify(this.machineListInfo));
        allMachineInfo.forEach(_am => { if (_am.isChecked) addUniqueEntry(selectedMachineIds, _am.machine_Id) })
      }
      this.createBucketOnlyOrCreateBucketAndAddMachineOrAddMachineToExistingBucket(bucketName, '', selectedMachineIds, shouldCreateNewBucketAndAddMachine);
    }
  }

  createBucketOnlyOrCreateBucketAndAddMachineOrAddMachineToExistingBucket(bucketName, bucketId, machineIds = [],
    shouldCreateNewBucketAndAddMachine = false, isAddidngToExistingBucket = false) {
    const { selectOrder, serviceType } = this.prodetailsData;
    const bucketListInfo = this.sharedService.initializaCreateBucketList(bucketName, bucketId, this.project_id, selectOrder, machineIds);
    if (isAddidngToExistingBucket) { delete (bucketListInfo.project_Id); delete (bucketListInfo.order_Id) }
    return this.backendService.createNewBucket(bucketListInfo).then(res => {
      if (res && res == 'Bucket has been created') {
        let msg = '';
        if (isAddidngToExistingBucket) msg = `Machines added Successfully.`;
        else {
          if (shouldCreateNewBucketAndAddMachine) msg = `${bucketName} Bucket Created and Machines added Successfully.`;
          else msg = `${bucketName} Bucket Created Successfully.`;
        }
        msg && this.sharedService.showToast('', msg);
        if (shouldCreateNewBucketAndAddMachine || isAddidngToExistingBucket) this.makeAvailableMachineListToInitialStateAndFetchLatestBucket(this.project_id, selectOrder, serviceType);
      }
    }).catch(err => {
      console.log('getting issue on creating the bucket :', err);
    })
  }

  makeAvailableMachineListToInitialStateAndFetchLatestBucket(projectId, orderId, serviceType, shouldNotUpdateAvailableMachine = false) {
    setTimeout(async () => {
      this.getServiceAndMachineListInfo(orderId, serviceType, projectId);
      let bucketLists = await this.getBucketInfo(projectId, orderId, serviceType);
      this.getBucketListInfo(bucketLists);
      !shouldNotUpdateAvailableMachine && this.machineListInfo.forEach(_mli => { if (_mli.isChecked) _mli.isChecked = false })
    }, 3 * 1000)
  }

  async editBucketLists(bucketData) {
    if (isNotEmptyArray(bucketData)) {
      let bucketBody = await this.sharedService.initialiizeEditBucketInfo(bucketData);
      if (isNotEmptyArray(bucketBody)) {
        this.backendService.editBuckets(bucketBody).then(res => {
          if (res) {
            const { selectOrder, serviceType } = this.prodetailsData;
            this.sharedService.showToast('', `Bucket Edited Successfully.`);
            this.makeAvailableMachineListToInitialStateAndFetchLatestBucket(this.project_id, selectOrder, serviceType, true);
          }
        }).catch(err => {
          console.log('getting issue in edit bucket :', err);
        })
      }
    }
    return true;
  }

  async deleteBucketLists(bucketData) {
    if (isNotEmptyArray(bucketData)) {
      let bucketBody = await this.sharedService.initializeDeleteBucketInfo(bucketData);
      if (isNotEmptyArray(bucketBody)) {
        this.backendService.deleteBuckets(bucketBody).then(res => {
          if (res) {
            const { selectOrder, serviceType } = this.prodetailsData;
            this.sharedService.showToast('', `Bucket Deleted Successfully.`);
            this.makeAvailableMachineListToInitialStateAndFetchLatestBucket(this.project_id, selectOrder, serviceType, true);
          }
        }).catch(err => {
          console.log('getting issue in deleting the bucket :', err);
        })
      }
    }
  }

  myMachineAddBucket(event, type) {
    this.openStatusPopover(event, type)
  }


  async openStatusPopover(ev: any, type, projectStatus?, machineList?) {
    let props = { type };
    if (projectStatus) props['projectStatus'] = projectStatus
    if (machineList) {
      let isFourEyeRequested = false
      if (!machineList.isFourEyeRequested) isFourEyeRequested = true
      props['isFourEyeRequested'] = isFourEyeRequested
    }
    const popover = await this.popController.create({
      component: StatusPopoverComponent,
      cssClass: (type == '4_eyeQualityCheck' || type == 'machine-specific-kebab-elipse' || (type == 'bucket-machine-specific-kebab-elipse'))
        ? 'my-4-eye-custom-css' : 'my-custom-class',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      const { data } = result;
      if (data == 'request-4-eye-quality-check') this.requestFourEyeQualityCheck(machineList)
      else if (data == 'perform-4-eye-quality-check') this.performFourEyeQualityCheck(machineList)
      else if (data == 'create' || data == 'edit') this.createOrEditBucket(data);
      else if (data == 'editProj') this.navigateToEditProject();
      else if (data == 'deleteProj') { console.log('delete project') }
      else if (data == 'blockProj') { console.log('block project') }
      else if (data == 'closeProj') { console.log('close project') }
    });
  }

  navigateToEditProject() {
    this.sharedService.edit_flow_temp_Encrypted_project_id = this.encrypted_project_id;
    this.router.navigateByUrl('/project-management');
    setTimeout(() => {
      this.sharedService.edit_flow_temp_Encrypted_project_id = '';
    }, 1000)
  }

  requestFourEyeQualityCheck(machineList) {
    this.openAddUserModal('assign-4-eye-quality-check-user', machineList);
  }

  performFourEyeQualityCheck(machineList) {
    const { machine_Id, machine_Name, serviceMachine_Id: { serviceMachineId } } = machineList
    let currentUrl = this.router.url;
    let spilitedUrlData = currentUrl.split('/');
    let encrypted_id = '';
    let encrpId = spilitedUrlData[3];
    if (encrpId.includes('?')) encrypted_id = encrpId.substring(0, encrpId.indexOf('?'));
    else encrypted_id = spilitedUrlData[3]
    let url = `${spilitedUrlData[1]}/${spilitedUrlData[2]}/${encrypted_id}/four-eye-quality/${machine_Id}/${serviceMachineId}/${machine_Name}`;
    this.router.navigateByUrl(`/${url}`);
    // let navigationExtras: NavigationExtras = {
    //   queryParamsHandling: 'preserve',
    // };
    // this.router.navigate([window.location.pathname, 'four-eye-quality'], navigationExtras)
  }

  goToMachineDetails(event, machine) {
    console.log("goToMachineDetails", machine);
    this.sharedService.selectedRoadmapsList = []
    event.stopPropagation();
    let navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      state: {
        machine: machine,
        project_id: this.project_id
      },
    };
    this.router.navigate([window.location.pathname, 'machine-details', machine.machine_Id], navigationExtras)
  }

  goToConflictResolutionPage() {
    this.router.navigateByUrl('/conflict-resolution');
  }

  async openAddUserModal(type, machineList?) {
    let props = { type };
    const modal = await this.modalController.create({
      component: SearchModalComponent,
      cssClass: 'my-custom-class',
      backdropDismiss: false,
      componentProps: props,
      showBackdrop: false,
    });
    await modal.present();
    await modal.onDidDismiss().then((result) => {
      const { data: { groupName, newRole, roleToAssign, modeType, selectedUsers } } = result;
      if (modeType == 'assign-4-eye-quality-check-user' && isNotEmptyArray(selectedUsers)) {
        if (!machineList.isFourEyeRequested) machineList.isFourEyeRequested = true;
        this.sharedService.isFourEyeQualityCheckRequested = true;
        this.sharedService.showToast('', 'Requested 4 Eyes Quality Check');
      }
    });
  }

  createOrEditBucket(mode) {
    if (mode && mode == 'create') this.addToBucket(true);
    else if (mode && mode == 'edit') this.addToBucket(false, true);
  }

  machineMoreIcons(event, type, machineList) {
    this.openStatusPopover(event, type, '', machineList);
  }

  async showFilter(ev, type) {
    let each_service = {
      bucketTypes: [
        { bucketType: 'My Buckets' },
        { bucketType: 'Team Buckets' }
      ],
      assignee: [],
      assetNumber: [],
      machineManufacturer: [],
      machineType: [],
      serialNumber: [],
    }
    const popover = await this.popController.create({
      component: FilterMoodalComponent,
      cssClass: 'my-filtercustom-class',
      event: ev,
      componentProps: { filterFor: type, each_service },
      translucent: true,
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      if (!isObjectEmpty(result) && isNotNullAndUndefined(result.data)) {
        const { data: { data: { bucketList, machineAssignee, assetNumber, manufacturer, machineType, serialNumber } } } = result;
      }
    });
  }

  changeServiceTypeSelection(bucketInfo) {
    this.allBucketLists.forEach(_aml => { if (_aml.bucket_Id != bucketInfo.bucket_Id) _aml.opened = false });
    bucketInfo.opened = !bucketInfo.opened
  }

  changeLogActualHoursEditingValue() {
    this.islogActualHoursEditing = !this.islogActualHoursEditing
    if (isNotEmptyArray(this.logActualHoursListsToEdit)) this.logActualHoursListsToEdit = []
    this.logActualHoursInfo.forEach(_lahi => { if (_lahi.isActualHourExceedError) delete _lahi.isActualHourExceedError })
  }

  editLogActualHoursValues(event, logActulaList, mode) {
    if (event.detail.value) {
      let localLogHoursLists = JSON.parse(JSON.stringify(logActulaList));
      //let isSameName = (localLogHoursLists.accutalHours.trim() == event.detail.value.trim());
      let matechLogInfo = this.logActualHoursInfo.find(_lahi => _lahi.machine_id === localLogHoursLists.machine_id);
      if (mode == 'edit-actual' && event.detail.value > matechLogInfo.calculatedHours) {
        logActulaList.isActualHourExceedError = true
        //return this.sharedService.errorShowToast('', 'Actual hours exceeding calculated hours');
        this.sharedService.errorShowToast('', 'Actual hours exceeding calculated hours');
      } else if (mode == 'edit-actual' && logActulaList.isActualHourExceedError) delete logActulaList.isActualHourExceedError
      if (matechLogInfo) {
        if (mode == 'edit-actual') localLogHoursLists.newActualHours = event.detail.value
        else if (mode == 'edit-comment') localLogHoursLists.newComments = event.detail.value
        if (isNotEmptyArray(this.logActualHoursListsToEdit)) {
          let matchedLogListToEdit = this.logActualHoursListsToEdit.find(_lahle => _lahle.machine_id == logActulaList.machine_id)
          if (matchedLogListToEdit) {
            if (mode == 'edit-actual') matchedLogListToEdit.newActualHours = event.detail.value
            if (mode == 'edit-comment') matchedLogListToEdit.newComments = event.detail.value
          }
          else this.logActualHoursListsToEdit.push(localLogHoursLists);
        } else this.logActualHoursListsToEdit.push(localLogHoursLists);
      }
    } else {
      if (isNotEmptyArray(this.logActualHoursListsToEdit)) {
        let matchedEditInfo = this.logActualHoursListsToEdit.find(_lahi => _lahi.machine_id === logActulaList.machine_id);
        if (matchedEditInfo && (mode == 'edit-actual' && !matchedEditInfo.newComments) || (mode == 'edit-comment' && !matchedEditInfo.newActualHours)) {
          let index = this.logActualHoursListsToEdit.findIndex(_lahi => _lahi.machine_id === logActulaList.machine_id);
          this.logActualHoursListsToEdit.splice(index, 1)
        } else {
          if (matchedEditInfo) {
            if (mode == 'edit-actual') matchedEditInfo.newActualHours = event.detail.value
            else if (mode == 'edit-comment') matchedEditInfo.newComments = event.detail.value
          }
        }
      }
    }
  }

  saveLogActualHours() {
    // let isAnyLogActualError = this.logActualHoursInfo.some(_lahi => _lahi.isActualHourExceedError)
    // if (!isAnyLogActualError) { }
    if (isNotEmptyArray(this.logActualHoursListsToEdit)) {
      this.logActualHoursInfo.forEach(_lahi => {
        if (_lahi.isActualHourExceedError) delete _lahi.isActualHourExceedError
      });
      this.saveEditedLogActualHours();
    }
    this.islogActualHoursEditing = false;
  }

  saveEditedLogActualHours() {
    if (isNotEmptyArray(this.logActualHoursListsToEdit)) {
      let logActualHours = this.sharedService.initializeLogActualHours(this.logActualHoursListsToEdit);
      if (isNotEmptyArray(logActualHours)) {
        this.backendService.updateLogActualHoursInfo(logActualHours).then(res => {
          if (res && res == 'Actual Hours Added') {
            this.sharedService.showToast('', 'Log Actual Hours Edited Successfully.');
            setTimeout(() => {
              const { selectOrder, serviceType } = this.prodetailsData;
              this.refreshMachineListsInfo(selectOrder, serviceType, this.projectList?.project_Id);
            }, 3000)
          }
        }).catch(err => {
          console.log('getting issue in updating log actual hours :', err);
        })
      }
    }
  }

  async openProjectAction(ev: any, type, task?) {
    let props = { type };
    const popover = await this.popController.create({
      component: StatusPopoverComponent,
      cssClass: 'popProAction',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      if (task && result.data !== undefined) {
        typeof result.data === 'string'
          ? (task.status = result.data)
          : (task.taskManagerUsers = result.data);
      }
    });
  }

  async openProjReport(ev: any, type, task?) {
    let props = { type };
    const popover = await this.popController.create({
      component: StatusPopoverComponent,
      cssClass: 'popProReport',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      if (task && result.data !== undefined) {
        typeof result.data === 'string'
          ? (task.status = result.data)
          : (task.taskManagerUsers = result.data);
      }
    });
  }

  async cancelModal() {
    const msg = `Are You Sure You Want to Cancel?`;
    let props = { alertContent: msg }
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const { data: { isConfirmed } } = await modal.onWillDismiss();
    isConfirmed && this.changeLogActualHoursEditingValue()
  }

}
