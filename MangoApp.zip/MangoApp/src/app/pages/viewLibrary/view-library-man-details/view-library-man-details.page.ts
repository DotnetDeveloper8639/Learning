import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { ModalController, PopoverController } from '@ionic/angular';
import { UploadMachineDocComponent } from 'src/app/components/upload-machine-doc/upload-machine-doc.component';
import { StatusPopoverComponent } from 'src/app/components/status-popover/status-popover.component';
// import { machineDetails, standardDetails, legislationsDocuments, roadmapDocument, raProcessLibrary, hazardCatalog, reportTemplate } from '../../../modals/libraryManagementdata';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { isNotEmptyArray } from 'src/app/utilities/utils';

@Component({
  selector: 'app-view-library-man-details',
  templateUrl: './view-library-man-details.page.html',
  styleUrls: ['./view-library-man-details.page.scss'],
})
export class ViewLibraryManDetailsPage implements OnInit {
  machineDetails: any;
  standardDetails: any;
  legislationsDocuments: any;
  roadmapDocument: any;
  raProcessLibrary: any;
  hazardCatalog: any;
  reportTemplate: any;
  openSearch: boolean = false;
  filterTerm: any;
  macLibrary: any;
  machineData: any;
  machineTitle: any;
  machineType: any;
  libraryManagementUserInfo = [];
  roadMapDocumentInfo = [];
  roadMapData: any;
  roadMapSectionName: any;
  isBookmark: boolean = false
  id: any;

  constructor(private route: ActivatedRoute, public backendService: BackendCallService, public router: Router, public modalController: ModalController, public popoverController: PopoverController, public sharedValue: ShareValuesService) { }
  title: any;
  libviewDetails: any;

  ionViewWillEnter() {
    this.isSessionClose();
  }

  ngOnInit() {
    this.title = this.route.snapshot.params.title;
    if (this.title == 'Machine Library') {
      this.getMachineLibraryData();
    }
    else if (this.title == 'RoadMap Library') {
      this.getRoadMapLibraryData();
    }
    else if (this.title == 'Standards Documents') {
      // this.libviewDetails = this.sharedValue.legislationsDocuments;
    }
    else if (this.title == 'Legislations Documents') {
      // this.libviewDetails = this.sharedValue.legislationsDocuments;
    }

    else if (this.title == ' RA Process Library') {
      // this.libviewDetails = this.sharedValue.raProcessLibrary;
    }
    else if (this.title == 'Hazard Catalog') {
      // this.libviewDetails = this.sharedValue.hazardCatalog;
    }
    else if (this.title == 'Report Template') {
      // this.libviewDetails = this.sharedValue.reportTemplate;
    }
    else if (this.title == 'Control Measures') {
      this.getConsoleMeasurelibraryData();
    }
    else if (this.title == 'Initial Hazards') {
      this.getInitialMeasurelibraryData();
    }
  }

  async openAlertModal(msg, type, isUploadMachineFile = false) {
    console.log('data', type);
    let props = { type };
    console.log('name', props)
    const modal = await this.modalController.create({
      component: UploadMachineDocComponent,
      cssClass: isUploadMachineFile
        ? 'mango-dashboard-customization-modal'
        : 'mango-upload-customization-modal ',
      backdropDismiss: false,
      componentProps: props,
      showBackdrop: false,
    });
    await modal.present();
    const { data } = await modal.onWillDismiss();
    console.log(data);
    if (data.MachinefileUpload) {
      this.getMachineLibraryData();
    } else if (data.RoadFileUpload) {
      this.getRoadMapLibraryData();
    } else if (data.intialUpload) {
      this.getInitialMeasurelibraryData();
    } else if (data.controlMeasure) {
      this.getConsoleMeasurelibraryData();
    }
  }

  async openStatusPopover(ev: any, type, task?) {
    let props = { type };
    const popover = await this.popoverController.create({
      component: StatusPopoverComponent,
      cssClass: 'popcontentFilter',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
    });
  }

  isSearchOpen() {
    console.log('ev', this.openSearch);
    this.openSearch = !this.openSearch;
  }

  isSessionClose() {
    this.openSearch = false
  }

  getMachineLibraryData() {
    const _self = this;
    _self.backendService.getMasterLibrary().subscribe(res => {
      _self.macLibrary = res;
      this.libraryManagementUserInfo = [];
      this.macLibrary.value.forEach((element) => {
        this.libraryManagementUserInfo.push({
          machineId: element.id,
          machineTitle: element.machine_name,
          machineType: element.machine_type,
          machineManufacture: element.manufacturer
        })
      });
    }, error => {
      (err) => { }
    });
  }

  getRoadMapLibraryData() {
    if (isNotEmptyArray(this.libraryManagementUserInfo)) this.libraryManagementUserInfo = []
    const _self = this;
    this.libraryManagementUserInfo = [];
    _self.backendService.getRoadMapDetails().subscribe(res => {
      _self.roadMapData = res;
      this.roadMapData.value.forEach((element) => {
        this.libraryManagementUserInfo.push({
          machineId: element.id,
          machineTitle: element.roadMapName,
          machineType: element.roadMapVersion,
          machineManufacture: element.sectionName,
          //roadMapSectionName: element.sectionName,
        })
      });
    }, error => {
      (err) => { }
    });
  }

  getConsoleMeasurelibraryData() {
    if (isNotEmptyArray(this.libraryManagementUserInfo)) this.libraryManagementUserInfo = [];
    const userId = "7892B01E-5EE1-4702-81C1-DE9D35EA2FA9";
    this.backendService.getConsoleLibrary(userId).subscribe(res => {
      this.roadMapData = res;
      this.roadMapData.value.forEach((element) => {
        this.libraryManagementUserInfo.push({
          machineId: element.id,
          machineTitle: element.value,
        })
      });
    }, error => {
      (err) => { }
    });
  }

  getInitialMeasurelibraryData() {
    if (isNotEmptyArray(this.libraryManagementUserInfo)) this.libraryManagementUserInfo = [];
    const userId = "7892B01E-5EE1-4702-81C1-DE9D35EA2FA9";
    this.backendService.getInitialMeasure(userId).subscribe(res => {
      this.roadMapData = res;
      this.roadMapData.value.forEach((element) => {
        this.libraryManagementUserInfo.push({
          machineId: element.id,
          machineTitle: element.value,
        })
      });
    }, error => {
      (err) => { }
    });
  }

  isShownbookmark(libraryManagementUserInfo, item) {
    let matchedInfo = this.libraryManagementUserInfo.find(_lvd => _lvd.machineTitle == libraryManagementUserInfo.machineTitle);
    console.log('matchedInfo is :', matchedInfo);
    if (matchedInfo) matchedInfo.isBookmark = !matchedInfo.isBookmark;
    console.log('selected', matchedInfo.isBookmark)
    const userId = 101010
    let data = [{
      libraryId: "",
      name: libraryManagementUserInfo.machineTitle,
      type: libraryManagementUserInfo.machineType,
      url: "",
      version: libraryManagementUserInfo.machineManufacture,
      contentType: "",
      previewImageUrl: "https://schmappstracc.z13.web.core.windows.net/assets/images/Machine%20Library.svg",
    }]
    console.log('Data', JSON.stringify(data))
    this.backendService.createBookmark(userId, data).then(
      (response: any) => {
        console.log('response', response)
        if (response.value === "Bookmark added successfully") {
          // this.isBookmark = true;
          this.sharedValue.showToast('', 'Added to Bookmarks');
          this.isBookmark = true;
        }
        else
          this.sharedValue.showToast('', 'This Library is already Added')

      },
      (err) => { err }
    )

  }
}


