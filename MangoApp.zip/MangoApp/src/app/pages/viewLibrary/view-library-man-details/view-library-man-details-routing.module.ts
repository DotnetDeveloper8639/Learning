import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ViewLibraryManDetailsPage } from './view-library-man-details.page';

const routes: Routes = [
  {
    path: '',
    component: ViewLibraryManDetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ViewLibraryManDetailsPageRoutingModule {}
