import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ViewLibraryManDetailsPageRoutingModule } from './view-library-man-details-routing.module';

import { ViewLibraryManDetailsPage } from './view-library-man-details.page';
import { componentModule } from '../../../components/components.module'
import { Ng2SearchPipeModule } from 'ng2-search-filter'

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    componentModule,
    ViewLibraryManDetailsPageRoutingModule,
    Ng2SearchPipeModule
  ],
  declarations: [ViewLibraryManDetailsPage]
})
export class ViewLibraryManDetailsPageModule { }
