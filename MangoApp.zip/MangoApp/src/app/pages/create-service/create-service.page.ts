import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Location } from '@angular/common';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import * as moment from 'moment';
import { isObjectEmpty } from 'src/app/utilities/utils';
@Component({
  selector: 'app-create-service',
  templateUrl: './create-service.page.html',
  styleUrls: ['./create-service.page.scss'],
})
export class CreateServicePage implements OnInit {
  data: any;
  showServiceList: boolean = false;
  formData: any;
  errorDateMessage: boolean = false;
  servicesTypeList = [
    'Risk Assessment',
    'Risk Re-Assessment',
    'Retrofitting',
    'Training On-Site',
    'Training Off-Site',
    'Health Check',
  ];
  regions = ['Germany', 'Brazil', 'USA', 'Canada'];
  constructor(
    private _location: Location,
    public sharedValue: ShareValuesService
  ) {
    this.data = {
      serviceType: null,
      serviceDesc: '',
      serviceStartDate: '',
      serviceEndDate: '',
      region: null,
      serviceLocation: '',
    };
  }

  ngOnInit() {}

  onSubmit(myForm: NgForm) {
    if (myForm.invalid && !this.errorDateMessage) {
      myForm.form.markAllAsTouched();
      return;
    } else {
      this.formData = myForm.value;
      this.formData['id'] = this.sharedValue.listOfServices.length + 1;
      this.formData['opened'] = false;
      this.formData['selectedSegment'] = 'serviceDetails';
      this.sharedValue.listOfServices.push(this.formData);
      console.log(myForm.value, this.sharedValue.listOfServices);
      this.sharedValue.showToast('', 'Service Successfully Created');
      this._location.back();
    }
  }

  noSubmit(e) {
    e.preventDefault();
  }

  serviceType() {
    this.showServiceList = !this.showServiceList;
    console.log('test', this.showServiceList);
  }

  goBack() {
    this._location.back();
  }

  dateChecking() {
    if (
      !isObjectEmpty(this.data) &&
      this.data.serviceStartDate &&
      this.data.serviceEndDate
    ) {
      const { serviceStartDate, serviceEndDate } = this.data;
      let validValue = moment(serviceEndDate).isBefore(serviceStartDate);
      if (validValue) this.errorDateMessage = true;
      else this.errorDateMessage = false;
    }
  }
}
