import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreateServicePageRoutingModule } from './create-service-routing.module';

import { CreateServicePage } from './create-service.page';
import { componentModule } from '../../components/components.module';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
  imports: [
    CommonModule,
    componentModule,
    FormsModule,
    NgSelectModule,
    IonicModule,
    CreateServicePageRoutingModule,
  ],
  declarations: [CreateServicePage],
})
export class CreateServicePageModule {}
