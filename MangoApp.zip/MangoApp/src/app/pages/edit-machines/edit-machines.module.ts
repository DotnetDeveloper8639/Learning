import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EditMachinesPageRoutingModule } from './edit-machines-routing.module';

import { EditMachinesPage } from './edit-machines.page';
import { TotalHrsPipe } from '../add-machine/add-machine.page';
import { componentModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    componentModule,
    EditMachinesPageRoutingModule
  ],
  declarations: [EditMachinesPage,TotalHrsPipe]
})
export class EditMachinesPageModule {}
