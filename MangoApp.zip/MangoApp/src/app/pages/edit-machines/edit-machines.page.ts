import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { Location } from '@angular/common';
import { ModalController } from '@ionic/angular';
import { AlertModalPage } from 'src/app/components/alert-modal/alert-modal.page';
@Component({
  selector: 'app-edit-machines',
  templateUrl: './edit-machines.page.html',
  styleUrls: ['./edit-machines.page.scss'],
})
export class EditMachinesPage implements OnInit {
  each_service: any;
  machinesList: {
    name: string;
    industryType: string;
    description: string;
    disable: boolean;
    estimatedHours: number;
    machineType: string;
    location: string;
    asset_id: any;
    serial_number: any;
  }[] = [];
  constructor(
    private _location: Location,
    private router: Router,
    private route: ActivatedRoute,
    public sharedValue: ShareValuesService,
    public modalController: ModalController
  ) {

  }
  ionViewWillEnter() {

  }
  goBack() {
    this._location.back();
  }
  onSubmit() { }

  submit() {
    this.sharedValue.showToast('', "Machines Edited Succesfully")
    this._location.back();
  }

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.each_service =
          this.router.getCurrentNavigation().extras.state.each_service;
        console.log('each service', this.each_service);
      }
    });
  }

  async cancelConfirmation() {
    const msg = `Are You Sure You Want to Cancel?`;
    let props = { alertContent: msg }
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const { data: { isConfirmed } } = await modal.onWillDismiss();
    if (isConfirmed) this.goBack()
  }

}
