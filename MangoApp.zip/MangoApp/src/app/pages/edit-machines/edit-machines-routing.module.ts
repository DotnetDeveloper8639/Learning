import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EditMachinesPage } from './edit-machines.page';

const routes: Routes = [
  {
    path: '',
    component: EditMachinesPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EditMachinesPageRoutingModule {}
