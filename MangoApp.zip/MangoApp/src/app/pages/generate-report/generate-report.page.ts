import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { isNotBlank, isNotEmptyArray, isNotNullAndUndefined } from 'src/app/utilities/utils';

@Component({
  selector: 'app-generate-report',
  templateUrl: './generate-report.page.html',
  styleUrls: ['./generate-report.page.scss'],
})
export class GenerateReportPage implements OnInit {
  stepperData: any;
  selectedStepper: any = 'sm';
  isSearchbarExpand: boolean = false;
  machineListInfo = [];
  bk_machineListInfo = [];
  machinesSearchedText: any;
  isAllMachineCheckboxSelected: boolean = false
  isAnyMachineListSelected: boolean;
  isAllRoadmapSelected: boolean = true;
  isAllStepsSelected: boolean = true;
  isAllHazardSelected: boolean = true
  otherMeasure = 'iH'
  selectedMachineLists = [];
  enteredReportName: any;
  selectedTemplate: any;
  availableTemplates = [
    { title: 'All', val: 'all' },
    { title: 'Projects', val: 'projects' },
    { title: 'Machines', val: 'machines' },
    { title: 'Team Members', val: 'team_member' },
    { title: 'File Name', val: 'file_name' },
  ]

  availableRoadMap = [
    { title: 'AB1 - General Provisions', id: 'rd101', isRoadmapChecked: true },
    { title: 'BB3 - Embargo and Prohibity', id: 'rd102', isRoadmapChecked: true }
  ]

  availableSteps = [
    { title: '1.1 Has the company established  an energy control', subtitle: 'MRO Lock Out / Tag Out', id: 'qs101', isStepChecked: true },
    { title: '1.2 Does the energy control procedure clearly and ', subtitle: 'MRO Lock Out / Tag Out', id: 'qs102', isStepChecked: true }
  ]

  availableHazards = [
    { title: 'Right side safety key', assessor: 'Paul Travis', id: 'hz101', hazValue: 13500, accpetmessage: 'Unacceptable', ishazardChecked: true },
    { title: 'Left side entry door', assessor: 'Clark Simon', id: 'hz102', hazValue: 320, accpetmessage: 'High', ishazardChecked: true },
    { title: 'Left side entry door', assessor: 'Paul Travis', id: 'hz103', hazValue: 320, accpetmessage: 'Very High', ishazardChecked: true },
  ]

  availableInitialHazards = [
    { id: 'ih101', title: 'Drawings were not provided and therefore the control category of the safety circuit cannot be determined', date: '22/01/2021', isInitialHazardChecked: true },
    { id: 'ih102', title: 'We did not locate any protective material or hardware required to isolate machines from stored energy', date: '22/01/2021', isInitialHazardChecked: true }
  ]

  availableControlMeasures = [
    { id: 'cm101', title: 'We did not locate any protective material or hardware required to isolate machines from stored energy', date: '22/01/2021', isControlMeasureChecked: true, determinePlr: 'd', category: 3 }
  ]

  availableImages = [
    { name: '../../../assets/images/machine-list.png', id: 'im101', isImageChecked: true },
    { name: '../../../assets/images/machine-list.png', id: 'im102', isImageChecked: true },
    { name: '../../../assets/images/machine-list.png', id: 'im103', isImageChecked: true }
  ]

  constructor(public location: Location, public sharedService: ShareValuesService) { }

  ngOnInit() {
    this.stepperData = [
      { name: 'Select Machines', val: 'sm', isdone: false, isSelected: true, },
      { name: 'Machine Operations', val: 'mo', isdone: false, isSelected: false },
      { name: 'Select Template', val: 'st', isdone: false, isSelected: false },
    ]
    this.bk_machineListInfo = JSON.parse(JSON.stringify(this.machineListInfo));
  }

  goBack() {
    this.location.back();
  }

  changeStepper(step) {
    this.selectedStepper = step.val
    this.stepperData.forEach(_sd => _sd.isSelected = false);
    let matchedStepper = this.stepperData.find(_sd => _sd.val == step.val)
    if (matchedStepper) matchedStepper.isSelected = true;
    if (this.selectedStepper == 'mo' && this.selectedMachineLists.length) this.checkMachineOperationsCompleted();
  }

  goNextOrPrevStepper(type) {
    if (type == 'prev') {
      if (this.selectedStepper == 'mo') this.selectedStepper = 'sm'
      else if (this.selectedStepper == 'st') this.selectedStepper = 'mo'
    } else {
      if (this.selectedStepper == 'sm') this.selectedStepper = 'mo'
      else if (this.selectedStepper == 'mo') this.selectedStepper = 'st'
    }
    this.changeStepper({ val: this.selectedStepper })
  }

  appearSearchBar() {
    this.isSearchbarExpand = !this.isSearchbarExpand;
    if (!this.isSearchbarExpand) { this.machineListInfo = this.bk_machineListInfo; this.machinesSearchedText = '' }
  }

  searchAvailableMachines(event) {
    const { value } = event.detail;
    if (value && isNotEmptyArray(this.bk_machineListInfo)) {
      this.machineListInfo = this.bk_machineListInfo.filter(_bkmli => {
        return (
          (_bkmli.machine_Name.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkmli.serial_Number.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkmli.asset_Id.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkmli.masterMachine?.machine_Type.toLowerCase().indexOf(value.toLowerCase())) > -1
        );
      })
    } else this.machineListInfo = this.bk_machineListInfo;
  }

  changeAllSelectedCheckboxValue() {
    this.machineListInfo.forEach(_mli => _mli.isChecked = this.isAllMachineCheckboxSelected)
  }

  changeMachineCheckboxSelection() {
    const isAnyMachineListSelected = this.machineListInfo.some(_mli => _mli.isChecked);
    if (!isAnyMachineListSelected) this.isAllMachineCheckboxSelected = isAnyMachineListSelected;
    let matchedStepper = this.stepperData.find(_sd => _sd.val == this.selectedStepper)
    if (matchedStepper) matchedStepper.isdone = isAnyMachineListSelected
    this.selectedMachineLists = JSON.parse(JSON.stringify(this.machineListInfo.filter(_mli => _mli.isChecked)))
    this.selectedMachineLists.forEach(_sl => { if (_sl.isChecked) delete _sl.isChecked })
  }

  checkSelectTemplateStepperCompleted() {
    let matchedStepper = this.stepperData.find(_sd => _sd.val == this.selectedStepper)
    if (this.selectedStepper == 'st' && matchedStepper && isNotBlank(this.enteredReportName) && isNotNullAndUndefined(this.enteredReportName) &&
      isNotBlank(this.selectedTemplate) && isNotNullAndUndefined(this.selectedTemplate)) matchedStepper.isdone = true;
    else if (matchedStepper) matchedStepper.isdone = false
  }

  selectedMachinesList(machine) {
    this.selectedMachineLists.forEach(_sl => {
      if (_sl.machine_Id == machine.machine_Id) {
        if (_sl.isMachineSelected) delete _sl.isMachineSelected
        else _sl.isMachineSelected = true
      }
    })
    this.checkMachineOperationsCompleted();
  }

  changeAllSelectedRoadmap() {
    this.availableRoadMap.forEach(_mli => _mli.isRoadmapChecked = this.isAllRoadmapSelected)
  }

  changeRoadMapCheckboxSelection() {
    const isAnyRoadMapSelected = this.availableRoadMap.some(_mli => _mli.isRoadmapChecked);
    if (!isAnyRoadMapSelected) this.isAllRoadmapSelected = isAnyRoadMapSelected;
    this.checkMachineOperationsCompleted();
  }

  changeAllSelectedSteps() {
    this.availableSteps.forEach(_mli => _mli.isStepChecked = this.isAllStepsSelected)
  }

  changeStepCheckboxSelection() {
    const isAnyStepSelected = this.availableSteps.some(_mli => _mli.isStepChecked);
    if (!isAnyStepSelected) this.isAllStepsSelected = isAnyStepSelected;
    this.checkMachineOperationsCompleted();
  }

  changeAllSelectedHazard() {
    this.availableHazards.forEach(_mli => _mli.ishazardChecked = this.isAllHazardSelected)
  }

  changeHazardCheckboxSelection() {
    const isAnyHazardSelected = this.availableHazards.some(_mli => _mli.ishazardChecked);
    if (!isAnyHazardSelected) this.isAllHazardSelected = isAnyHazardSelected;
    this.checkMachineOperationsCompleted();
  }

  changeOtherMeasureSegment(type) {
    if (type) this.otherMeasure = type
  }

  checkOtherMeasureControl() {
    this.checkMachineOperationsCompleted();
  }

  checkMachineOperationsCompleted() {
    if (this.selectedStepper == 'mo') {
      let matchedStepper = this.stepperData.find(_sd => _sd.val == this.selectedStepper)
      if (matchedStepper && this.checkAllMachineOperationsCompleted()) matchedStepper.isdone = true;
      else if (matchedStepper) matchedStepper.isdone = false
    }
  }

  checkAllMachineOperationsCompleted() {
    let isAllDone = false;
    if (this.selectedStepper == 'mo') {
      let anyMachineSelected = this.selectedMachineLists.some(_sml => _sml.isMachineSelected);
      let anyRoadmapSelected = this.availableRoadMap.some(_arm => _arm.isRoadmapChecked);
      let anyQuestionsSelected = this.availableSteps.some(_aq => _aq.isStepChecked);
      let anyHazardSelected = this.availableHazards.some(_ah => _ah.ishazardChecked);
      let anyInitialHazardSelected = this.availableInitialHazards.some(_aih => _aih.isInitialHazardChecked);
      let anyControlMeasureSelected = this.availableControlMeasures.some(_acm => _acm.isControlMeasureChecked);
      let anyImageSelected = this.availableImages.some(_aim => _aim.isImageChecked);
      let matchedStepper = this.stepperData.find(_sd => _sd.val == this.selectedStepper)
      if (matchedStepper && anyMachineSelected && anyRoadmapSelected && anyQuestionsSelected && anyHazardSelected
        && anyInitialHazardSelected && anyControlMeasureSelected && anyImageSelected) return isAllDone = true
      else isAllDone = false
    }
    return isAllDone
  }

  generateReport() {

  }

}
