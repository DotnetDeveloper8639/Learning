import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { OfferManagementPageRoutingModule } from './offer-management-routing.module';

import { OfferManagementPage } from './offer-management.page';
import { componentModule } from '../../components/components.module';
import { RoundProgressModule } from 'angular-svg-round-progressbar';
import { NgSelectModule } from '@ng-select/ng-select';
// import { HeaderComponent } from 'src/app/components/header/header.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ViewOpportunitiesComponent } from 'src/app/components/view-opportunities/view-opportunities.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    componentModule,
    OfferManagementPageRoutingModule,
    RoundProgressModule,
    NgSelectModule,
    NgxChartsModule,
  ],
  declarations: [OfferManagementPage],
})
export class OfferManagementPageModule { }
