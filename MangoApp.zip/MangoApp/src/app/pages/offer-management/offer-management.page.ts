import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import {
  doubleDecimal,
  isNotEmptyArray,
  isNotNullAndUndefined,
  toNumber,
} from 'src/app/utilities/utils';
import { NgForm } from '@angular/forms';
import { StatusPopoverComponent } from 'src/app/components/status-popover/status-popover.component';
import { PopoverController } from '@ionic/angular';
import { AlertModalPage } from 'src/app/components/alert-modal/alert-modal.page';
import { ModalController } from '@ionic/angular';
import { AddRemoveColumnSelectorComponent } from 'src/app/components/add-remove-column-selector/add-remove-column-selector.component';
import { LocalSettingsService } from 'src/app/services/local-settings/local-settings.service';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
import { ViewOpportunitiesComponent } from 'src/app/components/view-opportunities/view-opportunities.component';

@Component({
  selector: 'app-offer-management',
  templateUrl: './offer-management.page.html',
  styleUrls: ['./offer-management.page.scss'],
})
export class OfferManagementPage implements OnInit {
  selectedTabTitle: string = 'Project Management';
  sideNav: string = 'pm';
  offerManagementList = [];
  createOffer: boolean = false;
  radius: number = 125;
  current: number = 55;
  color = 'blue';
  gradientclr: boolean = true;
  stepperType: string = 'od';
  openServiceType: boolean = false;
  selectItemValue = [{ name: 'test0' }, { name: 'test1' }, { name: 'test2' }];
  listName: any;
  selectedSegment: any = 'serviceDetails';
  contactList = ['Test1', 'Test2', 'Test3'];
  isSubmitted: boolean;
  formData: any;
  isOfferDetailUseExternalRaChecked: boolean = false;
  offerDetailsStepperInputData: any = {
    companyName: null,
    projectId: null,
    externalRaNotes: null,
    selectedRadioGroupValue: 'lineItemQuote',

  };
  offerDetailsStepperErrorData = {
    cname: false,
    pid: false,
  };
  isOfferDetailsStepperCompanyNameSearched = false;
  clientContactStepperInputData: any = {
    clientContactPerson: null,
    clientCustomerName: null,
    clientCustomerAddress: null,
    clientCustomerContact: null,
    clientCustomerEmail: null,
    clientCustomerId: null,
  };
  clientContactStepperErrorData = {
    cperson: false,
    cname: false,
    caddress: false,
    ccontact: false,
    cid: false,
  };
  isClientContactStepperCustomerNameSearched: boolean = false;
  stepperCompletedInputValue = {
    offerDetail: false,
    clientContact: false,
    services: false,
    notes: false,
    costingInfo: false,
    quotation: false,
  };

  notesStepperInputData: any = {
    additionalNotes: null,
  };
  isAnyQuotationSelected: boolean = false;
  quotationTemplateList = [
    'General Tecnicum Quote Template',
    'Quote Template Internal',
    'Quote Template Internal 2',
  ];
  quotationStepperInputData: any = {
    templateType: null,
  };

  //Charts
  multi = [
    {
      name: "Apr'21",
      series: [
        {
          name: '2010',
          value: 7300000,
        },
        {
          name: '2011',
          value: 8940000,
        },
      ],
    },

    {
      name: "May'21",
      series: [
        {
          name: '2010',
          value: 7870000,
        },
        {
          name: '2011',
          value: 8270000,
        },
      ],
    },

    {
      name: "June'21",
      series: [
        {
          name: '2010',
          value: 5000002,
        },
        {
          name: '2011',
          value: 5800000,
        },
      ],
    },
  ];
  // options
  showXAxis: boolean = true;
  showYAxis: boolean = false;
  gradient: boolean = true;
  showLegend: boolean = false;
  showXAxisLabel: boolean = true;
  // xAxisLabel: string = '';
  showYAxisLabel: boolean = false;
  // yAxisLabel: string = 'Population';
  animations: boolean = true;
  colorScheme: any = {
    domain: ['#28C790', '#CCCCCC', '#898989'],
  };
  offerMetrics: any;
  isOfferManagementSearchbarExpand: boolean = false;
  private bk_offerManagementList: any;
  offerManagementColumnSelectorPermission: any = {};

  constructor(
    public router: Router,
    public backendService: BackendCallService,
    public popoverController: PopoverController,
    public modalController: ModalController,
    public localSettingsSrv: LocalSettingsService,
  ) {
    console.log('offer contructor');
  }
  ngOnInit() { }

  ionViewWillEnter() {
    this.getOfferManagementDetails();
    this.offerEffortmetrics();
  }

  ionViewWillLeave() {
    if (this.isOfferManagementSearchbarExpand) {
      this.isOfferManagementSearchbarExpand = !this.isOfferManagementSearchbarExpand;
      this.offerManagementList = this.bk_offerManagementList;
    }
  }

  offerEffortmetrics() {
    this.backendService.offerEffortmetrics().subscribe(
      (data: any) => {
        return (this.offerMetrics = data.value);
      },
      (err) => { }
    );
  }

  onStackedChartSelect(event) {
    console.log('onStackedChartSelect', event);
  }

  appearOfferManagementSearch() {
    this.isOfferManagementSearchbarExpand = !this.isOfferManagementSearchbarExpand;
    if (!this.isOfferManagementSearchbarExpand) this.offerManagementList = this.bk_offerManagementList;
  }

  offerManagementTrackerSearch(event) {
    const { value } = event.detail;
    if (value && isNotEmptyArray(this.bk_offerManagementList)) {
      this.offerManagementList = this.bk_offerManagementList.filter(_bkoml => {
        return (
          (isNotNullAndUndefined(_bkoml.offer_id) ? (_bkoml.offer_id.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.project_id) ? (_bkoml.project_id.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.service_id) ? (_bkoml.service_id.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.service_type) ? (_bkoml.service_type.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.service_description) ? (_bkoml.service_description.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.service_region) ? (_bkoml.service_region.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.contact_name) ? (_bkoml.contact_name.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.customer_name) ? (_bkoml.customer_name.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.hours_progress) ? (_bkoml.hours_progress.toString().toLowerCase().indexOf(value)) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.start_Date) ? (_bkoml.start_Date.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.end_Date) ? (_bkoml.end_Date.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.assigned_to) ? (_bkoml.assigned_to.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.roadmap_progress) ? (_bkoml.roadmap_progress.toString().toLowerCase().indexOf(value)) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.status) ? (_bkoml.status.toLowerCase().indexOf(value.toLowerCase())) > -1 : false)
        );
      })
    } else this.offerManagementList = this.bk_offerManagementList;
  }

  getOfferManagementDetails() {
    this.backendService.getOfferManagementDetails().subscribe(
      (data: any) => {
        if (isNotEmptyArray(data.value)) {
          this.bk_offerManagementList = JSON.parse(JSON.stringify(data.value));
          this.getColumnSelectorPermission(['offerWidgetColumnSelector']);
          return (this.offerManagementList = data.value);
        }
        console.log(
          'getOfferManagementDetails API called',
          this.offerManagementList
        );
      },
      (err) => { }
    );
  }

  async openAddOrRemoveColumnSelectorAlertModal(type) {
    let props = { columnSelectorFor: type };
    const modal = await this.modalController.create({
      component: AddRemoveColumnSelectorComponent,
      cssClass: 'add-remove-widget-class',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const {
      data: {
        columnSelectorSelectedValue: {
          isDataChangedForColumnSelector,
          columnSelectorWidgetFor,
        },
      },
    } = await modal.onWillDismiss();
    if (isDataChangedForColumnSelector && columnSelectorWidgetFor) this.getColumnSelectorPermission([columnSelectorWidgetFor]);
  }

  getColumnSelectorPermission(types = []) {
    const _self = this;
    if (types.includes('offerWidgetColumnSelector')) {
      const data = _self.localSettingsSrv.getOfferManagementColumnSelectorWidgetStorageValue();
      if (isNotEmptyArray(data)) _self.checkOfferManagementColumnSelectorPermission(data);
    }
  }

  checkOfferManagementColumnSelectorPermission(value) {
    const _self = this;
    value.forEach((_v) => {
      if (_v.val === 'offerId') _self.offerManagementColumnSelectorPermission['offerId'] = _v.isChecked;
      if (_v.val === 'oPrjId') _self.offerManagementColumnSelectorPermission['projectId'] = _v.isChecked;
      if (_v.val === 'oSId') _self.offerManagementColumnSelectorPermission['serviceId'] = _v.isChecked;
      if (_v.val === 'oServiceType') _self.offerManagementColumnSelectorPermission['serviceType'] = _v.isChecked;
      if (_v.val === 'oDescrp') _self.offerManagementColumnSelectorPermission['description'] = _v.isChecked;
      if (_v.val === 'oRegion') _self.offerManagementColumnSelectorPermission['region'] = _v.isChecked;
      if (_v.val === 'oContactPerson') _self.offerManagementColumnSelectorPermission['contatctPerson'] = _v.isChecked;
      if (_v.val === 'oCustName') _self.offerManagementColumnSelectorPermission['customerName'] = _v.isChecked;
      if (_v.val === 'oHourPrg') _self.offerManagementColumnSelectorPermission['hourProgress'] = _v.isChecked;
      if (_v.val === 'oStartDate') _self.offerManagementColumnSelectorPermission['startDate'] = _v.isChecked;
      if (_v.val === 'oEndDate') _self.offerManagementColumnSelectorPermission['endDate'] = _v.isChecked;
      if (_v.val === 'oAssignedTo') _self.offerManagementColumnSelectorPermission['assignedTo'] = _v.isChecked;
      if (_v.val === 'oRoadmapPrg') _self.offerManagementColumnSelectorPermission['roadmapProgress'] = _v.isChecked;
      if (_v.val === 'oStatus') _self.offerManagementColumnSelectorPermission['status'] = _v.isChecked;
    });
  }

  opencreateOffer() {
    this.createOffer = true;
  }

  goBack() {
    this.createOffer = false;
    this.resetToDefaultValue();
  }

  resetToDefaultValue() {
    this.stepperType = 'od';
    this.isOfferDetailUseExternalRaChecked =
      !this.isOfferDetailUseExternalRaChecked;
    this.stepperCompletedInputValue = {
      offerDetail: false,
      clientContact: false,
      services: false,
      notes: false,
      costingInfo: false,
      quotation: false,
    };
    this.offerDetailsStepperErrorData = {
      cname: false,
      pid: false,
    };
    this.clientContactStepperErrorData = {
      cperson: false,
      cname: false,
      caddress: false,
      ccontact: false,
      cid: false,
    };
  }

  changeStepper(type) {
    this.checkInputAndRedirect(type);
  }

  checkInputAndRedirect(type) {
    if (this.stepperType == 'od') this.checkPreviousStepper(this.stepperType);
    else if (this.stepperType == 'cc') {
      if (type == 'od') this.stepperType = 'od';
      else this.checkPreviousStepper(this.stepperType);
    } else if (this.stepperType == 'ss') {
      if (type == 'cc') this.stepperType = 'cc';
      else this.checkPreviousStepper(this.stepperType);
    } else if (this.stepperType == 'notes') {
      if (type == 'ss') this.stepperType = 'ss';
      else this.nextStepper();
    } else if (this.stepperType == 'cinfo') {
      if (type == 'notes') this.stepperType = 'notes';
      else this.nextStepper();
    } else if (this.stepperType == 'quot' && type == 'cinfo')
      this.stepperType = 'cinfo';
  }

  serviceType() {
    console.log('method serviceType', this.openServiceType);
    this.openServiceType = !this.openServiceType;
    console.log('method serviceType 2', this.openServiceType);
  }

  segmentChanged(ev: any) {
    console.log('Segment changed', ev);
  }

  async openStatusPopover(ev: any, type, offerDetail) {
    console.log('offer management', type);
    let props = { type, offerDetail };
    const popover = await this.popoverController.create({
      component: StatusPopoverComponent,
      cssClass: 'my-custom-class',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      console.log(result);
      this.getOfferManagementDetails();
    });
  }

  onSubmit(myForm: NgForm) {
    if (myForm.valid) {
      this.isSubmitted = true;
      this.openServiceType = !this.openServiceType;
      console.log(myForm.value);
      this.formData = myForm.value;
    } else {
      myForm.form.markAllAsTouched();
    }
  }

  noSubmit(e) {
    e.preventDefault();
  }
  nextStepper() {
    this.checkPreviousStepper(this.stepperType);
  }

  checkPreviousStepper(previousStepper) {
    if (previousStepper == 'od')
      this.checErrorForOfferDetailStepperAndMoveNext();
    else if (previousStepper == 'cc')
      this.checErrorForClientContactStepperAndMoveNext();
    else if (previousStepper == 'ss') this.stepperType = 'notes';
    else if (previousStepper == 'notes')
      this.checErrorForNotesStepperAndMoveNext();
    else if (previousStepper == 'cinfo') this.stepperType = 'quot';
  }

  checErrorForOfferDetailStepperAndMoveNext() {
    if (!this.offerDetailsStepperInputData.projectId)
      this.offerDetailsStepperErrorData.pid = true;
    if (!this.offerDetailsStepperInputData.companyName)
      this.offerDetailsStepperErrorData.cname = true;
    if (
      this.offerDetailsStepperInputData.projectId &&
      this.offerDetailsStepperInputData.companyName
    ) {
      this.stepperCompletedInputValue.offerDetail = true;
      this.stepperType = 'cc';
    } else this.stepperCompletedInputValue.offerDetail = false;
  }

  checErrorForClientContactStepperAndMoveNext() {
    if (!this.clientContactStepperInputData.clientContactPerson)
      this.clientContactStepperErrorData.cperson = true;
    if (!this.clientContactStepperInputData.clientCustomerName)
      this.clientContactStepperErrorData.cname = true;
    if (!this.clientContactStepperInputData.clientCustomerAddress)
      this.clientContactStepperErrorData.caddress = true;
    if (!this.clientContactStepperInputData.clientCustomerContact)
      this.clientContactStepperErrorData.ccontact = true;
    if (!this.clientContactStepperInputData.clientCustomerId)
      this.clientContactStepperErrorData.cid = true;

    if (
      this.clientContactStepperInputData.clientContactPerson &&
      this.clientContactStepperInputData.clientCustomerName &&
      this.clientContactStepperInputData.clientCustomerAddress &&
      this.clientContactStepperInputData.clientCustomerContact &&
      this.clientContactStepperInputData.clientCustomerId
    ) {
      this.stepperCompletedInputValue.clientContact = true;
      this.stepperType = 'ss';
    } else this.stepperCompletedInputValue.clientContact = false;
  }

  checErrorForNotesStepperAndMoveNext() {
    if (this.notesStepperInputData.additionalNotes)
      this.stepperCompletedInputValue.notes = true;
    else this.stepperCompletedInputValue.notes = false;
    this.stepperType = 'cinfo';
  }

  getSearchedData(ev: any, type) {
    const val = ev.target.value;
    if (val && val.trim() !== '') {
      if (type == 'od') this.isOfferDetailsStepperCompanyNameSearched = true;
      else if (type == 'cc')
        this.isClientContactStepperCustomerNameSearched = true;
    } else {
      this.isOfferDetailsStepperCompanyNameSearched = false;
      this.isClientContactStepperCustomerNameSearched = false;
      if (this.offerDetailsStepperInputData.companyName)
        this.offerDetailsStepperInputData.companyName = null;
      if (this.clientContactStepperInputData.clientCustomerName)
        this.clientContactStepperInputData.clientCustomerName = null;
    }
  }

  insertSearchedValue(type, value) {
    if (type == 'od') {
      this.offerDetailsStepperInputData.companyName = value;
      this.isOfferDetailsStepperCompanyNameSearched = false;
      if (this.offerDetailsStepperErrorData.cname)
        this.offerDetailsStepperErrorData.cname = false;
    } else if (type == 'cc') {
      this.clientContactStepperInputData.clientCustomerName = value;
      this.isClientContactStepperCustomerNameSearched = false;
      if (this.clientContactStepperErrorData.cname)
        this.clientContactStepperErrorData.cname = false;
    }
    this.resetToDefaultSatusOfSearchedValue(type);
  }

  resetToDefaultSatusOfSearchedValue(type) {
    setTimeout(() => {
      if (type == 'od') this.isOfferDetailsStepperCompanyNameSearched = false;
      else if (type == 'cc')
        this.isClientContactStepperCustomerNameSearched = false;
    }, 501);
  }

  inputErrorHandle(type, value) {
    if (
      type == 'od' &&
      value == 'pid' &&
      this.offerDetailsStepperInputData.projectId
    )
      this.offerDetailsStepperErrorData.pid = false;
    else if (
      type == 'cc' &&
      value == 'ccp' &&
      this.clientContactStepperInputData.clientContactPerson
    )
      this.clientContactStepperErrorData.cperson = false;
    else if (
      type == 'cc' &&
      value == 'ccadd' &&
      this.clientContactStepperInputData.clientCustomerAddress
    )
      this.clientContactStepperErrorData.caddress = false;
    else if (
      type == 'cc' &&
      value == 'cccontact' &&
      this.clientContactStepperInputData.clientCustomerContact
    )
      this.clientContactStepperErrorData.ccontact = false;
    else if (
      type == 'cc' &&
      value == 'ccid' &&
      this.clientContactStepperInputData.clientCustomerId
    )
      this.clientContactStepperErrorData.cid = false;
  }

  async closeBox() {
    let props = {
      isOfferCreation: true,
    };
    const msg = `Are You Sure You Want to Cancel?`;
    props['alertContent'] = msg;
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const {
      data: { isOfferCreationConfirmClose },
    } = await modal.onWillDismiss();
    if (isOfferCreationConfirmClose) this.goBack();
  }

  exportOfferManagement() {
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('Offer Management Tracker');
    worksheet.columns = [
      { header: 'Offer Id', key: 'offer_id', width: 12, },
      { header: 'Project Id', key: 'project_id', width: 30 },
      { header: 'Service Id', key: 'service_id', width: 30 },
      { header: 'Service Type', key: 'service_type', width: 20 },
      { header: 'Description', key: 'service_description', width: 20 },
      { header: 'Region', key: 'service_region', width: 10 },
      { header: 'Contact Person', key: 'contact_name', width: 25 },
      { header: 'Customer Name', key: 'customer_name', width: 15 },
      { header: 'Hours Progress', key: 'hours_progress', width: 15 },
      { header: 'Start Date', key: 'start_Date', width: 15 },
      { header: 'End Date', key: 'end_Date', width: 15 },
      { header: 'Assigned To', key: 'assigned_to', width: 15 },
      { header: 'Roadmap Progress', key: 'roadmap_progress', width: 15 },
      { header: 'Assigned To', key: 'offer.status', width: 15 },
      // { header: 'Contact Person', key: 'price', width: 10, style: { font: { name: 'Arial Black', size: 10 } } },
    ];
    worksheet.addRows(this.offerManagementList, "n");
    // worksheet.addRow({ ProjectId: e.project_Id, ProjectName: e.project_Name, CustomerName: e.customer_Name, CustomerId: e.customer_Id, ContactPerson: e.contact_Name, Region: e.region, ProjectManager: e.project_Manager, Progress: e.progress, HoursProgress: e.hours_Progress, EndDate: e.end_Date, Status: e.status }, "n");
    workbook.xlsx.writeBuffer().then((offerManagementList) => {
      let blob = new Blob([offerManagementList], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      fs.saveAs(blob, 'OfferManagement.xlsx');
    })
  }

  openViewOpport(isViewOpportunity) {
    this.openAlertModel(isViewOpportunity);
  }

  async openAlertModel(msg, isViewOpportunity = false) {
    const modal = await this.modalController.create({
      component: ViewOpportunitiesComponent,
      cssClass: isViewOpportunity
        ? 'mango-dashboard-customization-modal'
        : 'mango-upload-customization-modal',
      backdropDismiss: false,
      showBackdrop: false,
    });
    await modal.present();
  }

}
