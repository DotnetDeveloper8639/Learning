import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OfferManagementPage } from './offer-management.page';

const routes: Routes = [
  {
    path: '',
    component: OfferManagementPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OfferManagementPageRoutingModule {}
