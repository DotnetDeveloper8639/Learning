import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provisional-quote',
  templateUrl: './provisional-quote.page.html',
  styleUrls: ['./provisional-quote.page.scss'],
})
export class ProvisionalQuotePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
