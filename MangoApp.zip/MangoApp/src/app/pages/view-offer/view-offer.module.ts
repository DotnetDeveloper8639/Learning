import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ViewOfferPageRoutingModule } from './view-offer-routing.module';

import { ViewOfferPage } from './view-offer.page';
import { componentModule } from '../../components/components.module';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    componentModule,
    ViewOfferPageRoutingModule,
    NgSelectModule
  ],
  declarations: [ViewOfferPage],
})
export class ViewOfferPageModule { }
