import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NavController, PopoverController } from '@ionic/angular';
import { ModalController } from '@ionic/angular';
import { StatusPopoverComponent } from 'src/app/components/status-popover/status-popover.component';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-view-offer',
  templateUrl: './view-offer.page.html',
  styleUrls: ['./view-offer.page.scss'],
})
export class ViewOfferPage implements OnInit {
  @Input() qoutesDetails: any = {};
  openServiceType = false;
  isEnableButton: boolean = false;
  ViewOfferselectedSegment = 'offerDetails';
  serviceSelectedSegment = 'serviceDetails';
  viewServiceDetails: any = [];
  quotationTemplateList = [
    'General Tecnicum Quote Template',
    'Quote Template Internal',
    'Quote Template Internal 2',
  ];
  listOfSegments = [
    { title: 'Offer Details', value: 'offerDetails' },
    { title: 'Services', value: 'serviceDetails' },
    // { title: 'Notes', value: 'notes' },
    // { title: 'Costing Info', value: 'cInfo' },
    { title: 'Quotation', value: 'quot' },
  ];
  services = [
    {
      serviceType: 'Risk Assessment',
      opened: false,
    },
    {
      serviceType: 'Risk Re-Assessment',
      opened: false,
    },
    {
      serviceType: 'Training On-Site',
      opened: false,
    },
    {
      serviceType: 'Training Off-Site',
      opened: false,
    },
    {
      serviceType: 'Retrofitting',
      opened: false,
    },
  ];
  each_offer: any;
  offerDetails: any;
  viewMachineDetails = [];
  constructor(
    public popoverController: PopoverController,
    public modalController: ModalController,
    private route: ActivatedRoute,
    private router: Router,
    public navCtrl: NavController,
    public backendService: BackendCallService,
    public _location: Location
  ) { }

  ngOnInit() {
    const [project_id, offer_id] = this.route.snapshot.params.id.split(',');
    this.viewOfferDetailsById(project_id, offer_id);
  }

  goBack() {
    this._location.back();
  }

  segmentChanged(ev) {
    console.log('segement changed', ev);
    if (!this.viewServiceDetails && ev.detail.value == 'serviceDetails') {
    }
  }

  getOfferserviceDetails(serviceType) {
    this.viewServiceDetails = '';
    this.viewMachineDetails = [];
    serviceType.opened = !serviceType.opened;
    this.backendService
      .viewOfferServiceDetails(
        this.offerDetails.project_id,
        this.offerDetails.offer_id,
        serviceType.serviceType
      )
      .subscribe(
        (data: any) => {
          console.log('viewOfferServiceDetails API called', data.value);
          if (data.value) {
            this.getOfferMachineDetails(data.value.service_id);
            return (this.viewServiceDetails = data.value);
          }
        },
        (err) => { }
      );
  }

  getOfferMachineDetails(service_id) {
    this.backendService
      .getOfferMachineDetails(
        this.offerDetails.project_id,
        this.offerDetails.offer_id,
        service_id
      )
      .subscribe(
        (data: any) => {
          console.log('viewOfferServiceDetails API called', data.value);
          if (data.value) {
            return (this.viewMachineDetails = data.value);
          }
        },
        (err) => { }
      );
  }

  viewOfferDetailsById(project_id, offer_id) {
    this.backendService.viewOfferDetailsById(project_id, offer_id).subscribe(
      (data: any) => {
        console.log('viewOfferDetailsById API called', data.value);
        if (data.value) {
          this.offerDetails = data.value[0];
          // this.getOfferserviceDetails(data.value.service_type);
          return this.offerDetails;
        }
        console.log('getOfferDetailsById API called', this.offerDetails);
      },
      (err) => { }
    );
  }

  async openStatusPopover(ev: any, type, offer_id) {
    console.log('viewOfferMore', type);
    let props = { type, offer_id };
    const popover = await this.popoverController.create({
      component: StatusPopoverComponent,
      cssClass: 'my-custom-class',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      console.log(result);
      // if (result.data == 'edit-service') {
      //   console.log(result.data);
      //   // this.router.navigate['/offer-management'];
      // }
    });
  }

  async servicePopover(ev: any, type, viewServiceDetails) {
    console.log('viewOfferMore', type);
    let props = { type, viewServiceDetails };
    const popover = await this.popoverController.create({
      component: StatusPopoverComponent,
      cssClass: 'my-custom-class',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      console.log(result.data.service_type);
      this.getOfferserviceDetails(result.data.service_type);
    });
  }

  isSelectTemplate() {
    this.isEnableButton = true;
  }

  generateQuote() {
    this.router.navigate(['/provisional-quote']);
  }
}
