import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MachineDetailFourEyeQualityPage } from './machine-detail-four-eye-quality.page';

describe('MachineDetailFourEyeQualityPage', () => {
  let component: MachineDetailFourEyeQualityPage;
  let fixture: ComponentFixture<MachineDetailFourEyeQualityPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MachineDetailFourEyeQualityPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MachineDetailFourEyeQualityPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
