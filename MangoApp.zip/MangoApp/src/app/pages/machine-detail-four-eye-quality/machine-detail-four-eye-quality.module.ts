import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MachineDetailFourEyeQualityPageRoutingModule } from './machine-detail-four-eye-quality-routing.module';

import { MachineDetailFourEyeQualityPage } from './machine-detail-four-eye-quality.page';
import { componentModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MachineDetailFourEyeQualityPageRoutingModule,
    componentModule
  ],
  declarations: [MachineDetailFourEyeQualityPage]
})
export class MachineDetailFourEyeQualityPageModule { }
