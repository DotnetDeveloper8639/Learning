import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { isNotEmptyArray } from 'src/app/utilities/utils';
import { Location } from '@angular/common';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';

@Component({
  selector: 'app-machine-detail-four-eye-quality',
  templateUrl: './machine-detail-four-eye-quality.page.html',
  styleUrls: ['./machine-detail-four-eye-quality.page.scss'],
})
export class MachineDetailFourEyeQualityPage implements OnInit {
  fourEyeMachineCheckLists: any;
  isMarkAsCompleteChecked: boolean = false;
  bk_fourEyeMachineCheckLists: any;
  machineName: any;
  serviceMachineId: any;
  machinetype: any;

  constructor(private route: ActivatedRoute, private location: Location, public backendService: BackendCallService) { }

  ngOnInit() {
  }

  goBack() {
    this.location.back();
  }

  ionViewWillEnter() {
    this.machineName = this.route.snapshot.params.machinename;
    this.serviceMachineId = this.route.snapshot.params.servicemachineid;
    this.machinetype = this.route.snapshot.params.machinetype;
    this.serviceMachineId && this.constructRoadMapLists();
  }

  constructRoadMapLists() {
    this.backendService.getFourEyeQualityRoadMapLists(this.serviceMachineId).then(res => {
      if (isNotEmptyArray(res)) {
        this.fourEyeMachineCheckLists = res;
        this.checkStatusAvailableInRoadmapHazards();
      }
    }).catch(err => {
      console.log('getting issue in fetching four eye quality roadmaps info :', err);
    })
  }

  checkStatusAvailableInRoadmapHazards() {
    if (isNotEmptyArray(this.fourEyeMachineCheckLists)) {
      this.fourEyeMachineCheckLists.forEach(_femc => {
        if (isNotEmptyArray(_femc.hazards)) {
          _femc.hazards.forEach(_hz => {
            if (!_hz.revieweStatus) _hz.revieweStatus = 'Not Started'
          })
        }
      })
      this.bk_fourEyeMachineCheckLists = JSON.parse(JSON.stringify(this.fourEyeMachineCheckLists));
    }
  }

  changeMarkAsCompleteValue() {
    if (isNotEmptyArray(this.fourEyeMachineCheckLists)) {
      this.fourEyeMachineCheckLists.forEach(_femcl => {
        if (isNotEmptyArray(_femcl.hazards)) {
          _femcl.hazards.forEach(_cld => {
            if (this.isMarkAsCompleteChecked && (_cld.revieweStatus == 'Not Started' || _cld.revieweStatus == 'not started')) _cld.revieweStatus = 'Done'
            else if (!this.isMarkAsCompleteChecked) this.fourEyeMachineCheckLists = JSON.parse(JSON.stringify(this.bk_fourEyeMachineCheckLists))
          })
        }
      });
    }
  }

}
