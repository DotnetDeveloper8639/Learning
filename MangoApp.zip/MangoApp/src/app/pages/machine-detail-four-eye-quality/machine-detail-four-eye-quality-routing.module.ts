import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MachineDetailFourEyeQualityPage } from './machine-detail-four-eye-quality.page';

const routes: Routes = [
  {
    path: '',
    component: MachineDetailFourEyeQualityPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MachineDetailFourEyeQualityPageRoutingModule {}
