import { Component, OnInit } from '@angular/core';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { isNotEmptyArray, isNotNullAndUndefined, isObjectEmpty } from 'src/app/utilities/utils';
import { ModalController, PopoverController } from '@ionic/angular';
import { StatusPopoverComponent } from 'src/app/components/status-popover/status-popover.component';
import { AddRemoveColumnSelectorComponent } from 'src/app/components/add-remove-column-selector/add-remove-column-selector.component';
import { LocalSettingsService } from 'src/app/services/local-settings/local-settings.service';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';

@Component({
  selector: 'app-order-management',
  templateUrl: './order-management.page.html',
  styleUrls: ['./order-management.page.scss'],
})
export class OrderManagementPage implements OnInit {
  radius: number = 125;
  current: number = 55;
  color = 'blue';
  gradientclr: boolean = true;
  orderManagementList = [];
  orderManagementEffortMetricsData: any;
  isJobOrderStatusSearchbarExpand: boolean = false;
  private bk_orderManagementList: any;
  jobOrderManagementColumnSelectorPermission: any = {};
  constructor(private backendCallServices: BackendCallService,
    public popoverController: PopoverController, public modelCtrl: ModalController,
    public localSettingsSrv: LocalSettingsService,) { }

  ngOnInit() {
    this.initializeOrderManagemnet();
  }

  async initializeOrderManagemnet() {
    await this.getEffortMetricsData();
    this.getOrderDetails();
  }

  getEffortMetricsData() {
    this.backendCallServices.getOrderManagementEffortmetrics().then(res => {
      if (!isObjectEmpty(res)) this.orderManagementEffortMetricsData = res
    }).catch(err => {
      console.log("getting issue in fetching order management effort metrics data :", err);
    })
  }

  getOrderDetails() {
    this.backendCallServices.getOrderManagementDetails().then(res => {
      if (isNotEmptyArray(res)) {
        this.bk_orderManagementList = JSON.parse(JSON.stringify(res));
        this.orderManagementList = res;
        this.getColumnSelectorPermission(['jobOrderWidgetColumnSelector']);
      }
    }).catch(err => {
      console.log("getting issue in fetching order management details :", err);
    })
  }

  ionViewWillLeave() {
    if (this.isJobOrderStatusSearchbarExpand) {
      this.isJobOrderStatusSearchbarExpand = !this.isJobOrderStatusSearchbarExpand;
      this.orderManagementList = this.bk_orderManagementList;
    }
  }

  async openAddOrRemoveColumnSelectorAlertModal(type) {
    let props = { columnSelectorFor: type };
    const modal = await this.modelCtrl.create({
      component: AddRemoveColumnSelectorComponent,
      cssClass: 'add-remove-widget-class',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const {
      data: {
        columnSelectorSelectedValue: {
          isDataChangedForColumnSelector,
          columnSelectorWidgetFor,
        },
      },
    } = await modal.onWillDismiss();
    if (isDataChangedForColumnSelector && columnSelectorWidgetFor) {
      this.getColumnSelectorPermission([columnSelectorWidgetFor]);
    }
  }

  getColumnSelectorPermission(types = []) {
    const _self = this;
    if (types.includes('jobOrderWidgetColumnSelector')) {
      const data = _self.localSettingsSrv.getJobOrderManagementColumnSelectorWidgetStorageValue();
      if (isNotEmptyArray(data)) _self.checkJobOrderManagementColumnSelectorPermission(data);
    }
  }

  checkJobOrderManagementColumnSelectorPermission(value) {
    const _self = this;
    value.forEach((_v) => {
      if (_v.val === 'joId') _self.jobOrderManagementColumnSelectorPermission['jobOrderId'] = _v.isChecked;
      if (_v.val === 'jSId') _self.jobOrderManagementColumnSelectorPermission['serviceId'] = _v.isChecked;
      if (_v.val === 'jOfferId') _self.jobOrderManagementColumnSelectorPermission['offerId'] = _v.isChecked;
      if (_v.val === 'jPrjId') _self.jobOrderManagementColumnSelectorPermission['projectId'] = _v.isChecked;
      if (_v.val === 'jStartDate') _self.jobOrderManagementColumnSelectorPermission['startDate'] = _v.isChecked;
      if (_v.val === 'jEndDate') _self.jobOrderManagementColumnSelectorPermission['endDate'] = _v.isChecked;
      if (_v.val === 'jCustName') _self.jobOrderManagementColumnSelectorPermission['customerName'] = _v.isChecked;
      if (_v.val === 'jCostPrg') _self.jobOrderManagementColumnSelectorPermission['costProgress'] = _v.isChecked;
      if (_v.val === 'jHourPrg') _self.jobOrderManagementColumnSelectorPermission['hourProgress'] = _v.isChecked;
      if (_v.val === 'jPrg') _self.jobOrderManagementColumnSelectorPermission['progress'] = _v.isChecked;
      if (_v.val === 'jStatus') _self.jobOrderManagementColumnSelectorPermission['status'] = _v.isChecked;
    });
  }

  appearJobOrderTrackerSearch() {
    this.isJobOrderStatusSearchbarExpand = !this.isJobOrderStatusSearchbarExpand;
    if (!this.isJobOrderStatusSearchbarExpand) this.orderManagementList = this.bk_orderManagementList;
  }

  jobOrderManagementTrackerSearch(event) {
    const { value } = event.detail;
    if (value && isNotEmptyArray(this.bk_orderManagementList)) {
      this.orderManagementList = this.bk_orderManagementList.filter(_bkoml => {
        return (
          (isNotNullAndUndefined(_bkoml.order_Id) ? (_bkoml.order_Id.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.service_Id) ? (_bkoml.service_Id.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.offer_Id) ? (_bkoml.offer_Id.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.project_Id) ? (_bkoml.project_Id.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.start_Date) ? (_bkoml.start_Date.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.end_Date) ? (_bkoml.end_Date.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.customer_Name) ? (_bkoml.customer_Name.toLowerCase().indexOf(value.toLowerCase())) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.cost_Progress) ? (_bkoml.cost_Progress.toString().toLowerCase().indexOf(value)) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.hour_Progress) ? (_bkoml.hour_Progress.toString().toLowerCase().indexOf(value)) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.progress) ? (_bkoml.progress.toString().toLowerCase().indexOf(value)) > -1 : false) ||
          (isNotNullAndUndefined(_bkoml.status) ? (_bkoml.status.toLowerCase().indexOf(value.toLowerCase())) > -1 : false)
        );
      })
    } else this.orderManagementList = this.bk_orderManagementList;
  }

  async openStatusPopover(ev: any, type, task?) {
    let props = { type };
    const popover = await this.popoverController.create({
      component: StatusPopoverComponent,
      cssClass: 'my-custom-class',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    // await popover.onDidDismiss().then((result) => {
    //   if (task && result.data !== undefined) {
    //     typeof result.data === 'string'
    //       ? (task.status = result.data)
    //       : (task.taskManagerUsers = result.data);
    //   }
    // });
  }

  exportOrderManagementdata() {
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('Job Order Management');
    worksheet.columns = [
      { header: 'Job Order ID', key: 'order_Id', width: 12, },
      { header: 'Service ID', key: 'service_Id', width: 30 },
      { header: 'Offer ID', key: 'offer_Id', width: 30 },
      { header: 'Project ID', key: 'project_Id', width: 20 },
      { header: 'Start Date', key: 'start_Date', width: 20 },
      { header: 'End Date', key: 'end_Date', width: 10 },
      { header: 'Customer Name', key: 'customer_Name', width: 25 },
      { header: 'Cost Progress', key: 'cost_Progress', width: 15 },
      { header: 'Hours Progress', key: 'hour_Progress', width: 15 },
      { header: 'Progress', key: 'order.progress', width: 15 },
      { header: 'Status', key: 'status', width: 15 },
      // { header: 'Contact Person', key: 'price', width: 10, style: { font: { name: 'Arial Black', size: 10 } } },
    ];
    worksheet.addRows(this.orderManagementList, "n");
    // worksheet.addRow({ ProjectId: e.project_Id, ProjectName: e.project_Name, CustomerName: e.customer_Name, CustomerId: e.customer_Id, ContactPerson: e.contact_Name, Region: e.region, ProjectManager: e.project_Manager, Progress: e.progress, HoursProgress: e.hours_Progress, EndDate: e.end_Date, Status: e.status }, "n");
    workbook.xlsx.writeBuffer().then((orderManagementList) => {
      let blob = new Blob([orderManagementList], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      fs.saveAs(blob, 'JobOrderManagement.xlsx');
    })
  }
}
