import {
  Component,
  OnInit,
  Pipe,
  ViewChild,
  PipeTransform,
} from '@angular/core';
import { Location } from '@angular/common';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { AlertModalPage } from 'src/app/components/alert-modal/alert-modal.page';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-add-machine',
  templateUrl: './add-machine.page.html',
  styleUrls: ['./add-machine.page.scss'],
})
export class AddMachinePage implements OnInit {
  @ViewChild('addMachineForm') form: NgForm;
  machinesList: {
    name: string;
    industryType: string;
    description: string;
    disable: boolean;
    estimatedHours: number;
    machineType: string;
    location: string;
  }[] = [];
  newMachinesList: any[] = [{}];
  eachMachineForm: any = {};
  each_service: any = {};
  showHide: boolean = false;
  total: number;
  // page: string="service";
  constructor(
    private _location: Location,
    private router: Router,
    private route: ActivatedRoute,
    public sharedValue: ShareValuesService,
    public modalController: ModalController
  ) {
    this.route.queryParams.subscribe((params) => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.each_service =
          this.router.getCurrentNavigation().extras.state.each_service;
        console.log('each service', this.each_service);
      }
    });
  }

  ngOnInit() { }

  goBack() {
    this._location.back();
  }
  get totalHrs() {
    return 20;
  }

  submit(form: NgForm) {
    if(this.each_service.page=="projectDetails"){
      console.log("hh",form.value);
      // document.dispatchEvent(new CustomEvent('newMachine',{detail:Object.values(form.value)}))
      // this.sharedValue.projectDetailsMachines.push(...Object.values(form.value));
      this._location.back();
    }else{
      for (let each of this.sharedValue.listOfServices) {
        console.log(each.id, this.each_service);
        if (form.valid) {
          if (each.id == this.each_service.id) {
            if (each.id == this.each_service.id) {
              each['machines'] = each['machines'] || [];
              each.machines.push(...Object.values(form.value));
              for (let machine of each.machines) {
                machine.selectedMachinechecked = false;
              }
              console.log(
                'checking service data',
                this.sharedValue.listOfServices,
                JSON.stringify(this.sharedValue.listOfServices)
              );
              this._location.back();
              break;
            }
          }
        } else {
          form.form.markAllAsTouched();
          // this.sharedValue.showToast('', 'Please fill mandatory fields');
        }
      }
    }
  }

  async cancelConfirmation() {
    const msg = `Are You Sure You Want to Cancel?`;
    let props = { alertContent: msg }
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const { data: { isConfirmed } } = await modal.onWillDismiss();
    if (isConfirmed) this.goBack()
  }

  totalPrice() {
    console.log('total');
    this.total = 0;
    for (let data of this.machinesList) {
      console.log('total');
      let sum = data.estimatedHours + data.estimatedHours;
      this.total += sum;
    }
    return this.total;
  }

  showHideForm() {
    this.showHide = !this.showHide;
  }

  onSubmit() { }
}

@Pipe({
  name: 'totalhrs',
  pure: false,
})
export class TotalHrsPipe implements PipeTransform {
  transform(arr: any[]): number {
    if (!arr?.length) {
      return 0;
    }
    return arr.reduce((prev, nxt) => prev + (nxt.estimatedHours || 0), 0);
  }
}
