import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { isObjectEmpty } from 'src/app/utilities/utils';

@Component({
  selector: 'app-view-order',
  templateUrl: './view-order.page.html',
  styleUrls: ['./view-order.page.scss'],
})
export class ViewOrderPage implements OnInit {
  orderManagementList = [];
  offerDetails: any;
  constructor(private route: ActivatedRoute, private backendCallServices: BackendCallService) { }

  ngOnInit() {
    const orderDetailId = this.route.snapshot.params.id;
    orderDetailId && this.getOrderDetail(orderDetailId);
  }

  getOrderDetail(orderId) {
    if (orderId) {
      this.backendCallServices.getOrderDetail(orderId).then(res => {
        if (!isObjectEmpty(res)) this.offerDetails = res
      }).catch(err => {
        console.log('getting issue in order detail :', err);
      })
    }
  }
}
