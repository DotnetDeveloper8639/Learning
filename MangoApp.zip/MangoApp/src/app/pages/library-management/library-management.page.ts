import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router'
import { ModalController, ToastController } from '@ionic/angular';
import { libraryManagementUserInfo, recentDocumentsInfo } from '../../modals/libraryManagementdata';
import { UploadFileComponent } from 'src/app/components/upload-file/upload-file.component';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { isNotEmptyArray } from 'src/app/utilities/utils';

@Component({
  selector: 'app-library-management',
  templateUrl: './library-management.page.html',
  styleUrls: ['./library-management.page.scss'],
})
export class LibraryManagementPage implements OnInit {
  libraryManData = libraryManagementUserInfo;
  recentDocumentsInfo = recentDocumentsInfo;
  librarydata = [];
  recentDocument: any;
  bookmarksData: any;
  selectBookMarkData = [];
  filterTerm: any;
  openSearch: boolean = false;
  bookmarkIdvalue: any;

  constructor(private router: Router, public sharedValue: ShareValuesService, public toastController: ToastController, public modalController: ModalController, public activatedRoute: ActivatedRoute, public backendService: BackendCallService) {
    this.activatedRoute.queryParams.subscribe(params => {
      if (params && params.data) {
        console.log(params);
      }
    })
  }

  ionViewWillEnter() {
    this.getlibrariesManagementData();
    this.isSessionClose();
    this.getBookmarkData();
  }

  ngOnInit() {
    // this.getBookmarkData();
    // setTimeout(() => { this.ngOnInit() }, 1000 * 10)
  }

  getlibrariesManagementData() {
    this.librarydata = this.libraryManData;
    this.recentDocument = this.recentDocumentsInfo;
  }

  navigatetoDetails(type) {
    this.router.navigate(['view-library-man-details/:title']);
  }

  openUpload(isUploadFile) {
    this.openAlertModal(isUploadFile);
  }

  async openAlertModal(msg, isUploadFile = false) {
    const modal = await this.modalController.create({
      component: UploadFileComponent,
      cssClass: isUploadFile
        ? 'mango-dashboard-customization-modal'
        : 'mango-upload-customization-modal',
      backdropDismiss: false,
      showBackdrop: false,
    });
    await modal.present();
  }

  isOpenSearch() {
    console.log('ev', this.openSearch);
    this.openSearch = !this.openSearch;
  }

  isSessionClose() {
    this.openSearch = false
  }

  getBookmarkData() {
    if (isNotEmptyArray(this.selectBookMarkData)) this.selectBookMarkData = []
    const userId = 101010;
    const _self = this;
    _self.backendService.getBookmarDataDetails(userId).subscribe(res => {
      _self.bookmarksData = res;
      this.bookmarksData.value.forEach((element) => {
        this.selectBookMarkData.push({
          name: element.name,
          type: element.type,
          bookmarkId: element.id,
          version: element.version,
          image: element.preview_image_url
          //roadMapSectionName: element.sectionName,
        })
      });
    }, error => {
      (err) => { }
    });
  }

  isuncheckBookmark(selectBookMarkData, item) {
    const userId = 101010;
    const _self = this;
    _self.bookmarkIdvalue = selectBookMarkData.bookmarkId;
    let id = [
      _self.bookmarkIdvalue
    ]
    console.log('id', id)
    this.backendService.deleteBookmarkData(id).then(
      (response: any) => {
        console.log('response', response)
        if (response.value === "Bookmark deleted successfully") {
          this.getBookmarkData();
          this.sharedValue.showToast('', 'Removed From Bookmarks');
        }
      },
      error => {
        (err) => { }
      });
  }
}
