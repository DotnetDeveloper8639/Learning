import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddFromLibraryPageRoutingModule } from './add-from-library-routing.module';

import { AddFromLibraryPage } from './add-from-library.page';
import { componentModule } from 'src/app/components/components.module';
import { NgPipesModule } from 'ngx-pipes';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AddFromLibraryPageRoutingModule,
    componentModule,
    NgPipesModule
  ],
  declarations: [AddFromLibraryPage],
})
export class AddFromLibraryPageModule {}
