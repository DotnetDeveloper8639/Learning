import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { Location } from '@angular/common';
import { ModalController, PopoverController } from '@ionic/angular';
import { FilterMoodalComponent } from 'src/app/components/filter-moodal/filter-moodal.component';
import { AlertModalPage } from 'src/app/components/alert-modal/alert-modal.page';
@Component({
  selector: 'app-add-from-library',
  templateUrl: './add-from-library.page.html',
  styleUrls: ['./add-from-library.page.scss'],
})
export class AddFromLibraryPage implements OnInit {
  selectedMachines: boolean = false;
  selectedMachinesArry = []
  currentNumber = 0;
  checkAllMachines;
  machinesFilteredList = [];
  MachineTypesList = [];
  apiMachinesList = [];
  each_service;
  selectAll: boolean;
  machineQuantity: number = 0;
  applyFilter: boolean = false;
  showAddOffer: boolean = false;
  filterValues = { machine_type: '', manufacturer: '' };
  constructor(
    public backendService: BackendCallService,
    private router: Router,
    private route: ActivatedRoute,
    public sharedValue: ShareValuesService,
    private _location: Location,
    public popoverController: PopoverController,
    public modalController: ModalController
  ) {
    this.route.queryParams.subscribe((params) => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.each_service =
          this.router.getCurrentNavigation().extras.state.each_service;
        console.log('each service', this.each_service);
      }
    });
  }

  ionViewWillEnter() {
    // this.backendService.getmastermachinedetails().subscribe(
    //   (data: any) => {
    //     const machineTypeSets = {}; //new Set();
    //     this.apiMachinesList = data.value;
    //     console.log('getmastermachinedetails API called', data.value);
    //     for (let each of this.apiMachinesList) {
    //       machineTypeSets[each.machine_type] = machineTypeSets[
    //         each.machine_type
    //       ] || {
    //         type: each.machine_type,
    //         checked: (each.checked = false),
    //         list: [],
    //       };
    //       machineTypeSets[each.machine_type].list.push(each);
    //     }
    //     this.MachineTypesList = Object.values(machineTypeSets);
    //     console.log(machineTypeSets, this.MachineTypesList);
    //   },
    //   (err) => {}
    // );
  }
  selectedMachinesTab() {
    console.log(this.each_service);

    // const machineTypeSets = {}; //new Set();
    // for (let each of this.each_service.machines) {
    //   machineTypeSets[each.machine_type] = machineTypeSets[
    //     each.machine_type
    //   ] || {
    //     type: each.machine_type,
    //     checked: (each.checked = false),
    //     list: [],
    //   };
    //   machineTypeSets[each.machine_type].list.push(each);
    // }
    // this.MachineTypesList = Object.values(machineTypeSets);
    // console.log(machineTypeSets, this.MachineTypesList);
  }
  quantityIncDec(each, val) {
    if (val == 1) {
      if (!each.hasOwnProperty('quantity')) {
        each.quantity = 0;
      }
      each.quantity++
      console.log(each);
      this.addMachine(each)
    } else {
      console.log(each, val);
      if (each.quantity != 0) {
        each.quantity--
        console.log(each, val);
        this.addMachine(each)
      }
    }
  }

  searchMachine(searchTerm) {
    console.log(JSON.stringify(searchTerm));
    this.apiMachinesList = []
    this.backendService.searchMachineMaster(searchTerm).subscribe(
      (data: any) => {
        if (data && data.value) {
          this.apiMachinesList = data.value;
          console.log(this.apiMachinesList.length);

          this.apiMachinesList.forEach((obj) => obj.quantity = 1);
        } else if (data.statusCode == 201) {
          const noDataFond = data.returnText
        }
      }
    );
    console.log(searchTerm);
  }



  addMachine(selectedMachine, btnShow?) {
    console.log(selectedMachine);
    btnShow ? selectedMachine.addbtnShow = btnShow : selectedMachine.addbtnShow = !btnShow
    if (btnShow) {
      this.selectedMachinesArry.push(selectedMachine)
    }
    this.showAddOffer = true;
    // if(btnShow){
    //   for (let each of this.sharedValue.listOfServices) {
    //     console.log(each.id, this.each_service);
    //     if (each.id == this.each_service.id) {
    //       each['machines'] = each['machines'] || [];
    //       selectedMachine.checked = true;
    //       for (let i=0 ; i < selectedMachine.quantity;i++) {
    //         each.machines.push(selectedMachine);
    //       }
    //       // each.machines.push(selectedMachine);
    //       console.log(
    //         'checking service data',
    //         this.sharedValue.listOfServices,each.machines
    //         // JSON.stringify(this.sharedValue.listOfServices)
    //       );
    //       break;
    //     }
    //   }
    // }
  }

  async showFilterPopup(ev, each_service) {
    // this.applyFilter = false
    console.log("each_service", each_service, this.sharedValue.customersInfo);
    const popover = await this.popoverController.create({
      component: FilterMoodalComponent,
      cssClass: 'my-filtercustom-class',
      event: ev,
      componentProps: { each_service },
      translucent: true,
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      console.log(result.data.data);
      this.applyFilter = true
      this.filterValues.machine_type = result.data.data.machineType;
      this.filterValues.manufacturer = result.data.data.manufacturer;
      this.filterValues = { ...this.filterValues }
      console.log(this.applyFilter, this.filterValues, each_service.machines);

      // if (task && result.data !== undefined) {
      //   typeof result.data === 'string'
      //     ? (task.status = result.data)
      //     : (task.taskManagerUsers = result.data);
      // }
    });
    // const { role } = await popover.onDidDismiss();
    // console.log('onDidDismiss resolved with role', role);
  }

  deleteAll() {
    this.selectedMachinesArry = []
  }

  deleteMachines(deletemachine) {
    console.log(deletemachine);
    this.selectedMachinesArry.forEach(function (item, index, object) {
      if (item.id === deletemachine.id) {
        object.splice(index, 1);
      }
    });
    // for (let j = 0; j < this.sharedValue.listOfServices.length; j++) {
    //   this.sharedValue.listOfServices[j].machines.forEach(function(item, index, object) {
    //     if (item.id === deletemachine.id) {
    //       object.splice(index, 1);
    //     }
    //   });
    //   break;
    // }
  }

  addToOffer() {
    for (let eachService of this.sharedValue.listOfServices) {
      if (eachService.id == this.each_service.id) {
        eachService['machines'] = eachService['machines'] || [];
        if (eachService.hasOwnProperty('machines')) {
          // for (let each_machine of eachService.machines) {
          for (let machine of this.selectedMachinesArry) {
            for (let i = 0; i < machine.quantity; i++) {
              // for (let each_machine of eachService.machines) {
              machine.selectedMachinechecked = false;
              const parseData = JSON.parse(JSON.stringify(machine))
              eachService.machines.push(parseData)
              // }
            }
          }
          // }
        }
        console.log(
          'checking service data',
          this.sharedValue.listOfServices, eachService.machines
          // JSON.stringify(this.sharedValue.listOfServices)
        );
        break;
      }

      console.log(this.each_service);
      // for (let eachService of this.sharedValue.listOfServices) {
      //   if (eachService.hasOwnProperty('machines')) {
      //     for (let machine of eachService.machines) {
      //       machine.selectedMachinechecked = false
      //       if(machine.hasOwnProperty('quantity')){
      //       for (let i=0 ; i < machine.quantity;i++) {
      //         // each.machines.push(selectedMachine);
      //           this.selectedMachinesArry.push(machine);
      //       }  
      //     }
      //     }

      // eachService.machines = Array.from(
      //   new Set(eachService.machines.map((a) => a.id))
      // ).map((id) => {
      //   return eachService.machines.find((a) => a.id === id);
      // });
      // console.log(
      //   'unique values',
      //   eachService.machines.length,
      //   eachService.machines
      // );
      // }
    }
    this._location.back();
  }
  goBack() {
    this._location.back();
  }

  selectAllChange(ev) {
    console.log(ev);
    if (this.selectAll) {
      for (let mc of this.MachineTypesList) {
        mc.checked = true;
        for (let each_mc of mc.list) {
          each_mc.checked = true;
        }
      }
      for (let each of this.sharedValue.listOfServices) {
        if (each.id == this.each_service.id) {
          each['machines'] = each['machines'] || [];
          for (let machine of ev) {
            each.machines.push(machine);
          }
          console.log(
            'checking service data',
            each,
            this.sharedValue.listOfServices,
            this.MachineTypesList
          );
          break;
        }
      }
    } else {
      for (let mc of this.MachineTypesList) {
        mc.checked = false;
        for (let each_mc of mc.list) {
          each_mc.checked = false;
        }
      }
      for (let i = 0; i < this.sharedValue.listOfServices.length; i++) {
        console.log(this.sharedValue.listOfServices[i], this.each_service);
        if (this.sharedValue.listOfServices[i].id == this.each_service.id) {
          this.sharedValue.listOfServices['machines'] =
            this.sharedValue.listOfServices['machines'] || [];
          for (
            let j = 0;
            j < this.sharedValue.listOfServices[i].machines.length;
            j++
          ) {
            for (let machine of ev) {
              if (
                this.sharedValue.listOfServices[i].machines[j].id === machine.id
              ) {
                this.sharedValue.listOfServices[i].machines.splice(j, 1);
              }
            }
          }
          console.log(
            'checking service data',
            this.sharedValue.listOfServices,
            this.MachineTypesList
          );
          break;
        }
      }
    }
  }
  ngOnInit() {
    console.log(JSON.parse(JSON.stringify({ dta: "data" })))
  }

  async cancelConfirmation() {
    const msg = `Are You Sure You Want to Cancel?`;
    let props = { alertContent: msg }
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const { data: { isConfirmed } } = await modal.onWillDismiss();
    if (isConfirmed) this.goBack()
  }
}

// machineTypeChange(ev) {
  //   console.log(ev);
  //   if (ev.checked) {
  //     for (let mc of this.MachineTypesList) {
  //       if (ev.type == mc.type) {
  //         mc.checked = true;
  //         for (let each_mc of mc.list) {
  //           each_mc.checked = true;
  //         }
  //       }
  //     }
  //     for (let each of this.sharedValue.listOfServices) {
  //       console.log(each.id, this.each_service);
  //       if (each.id == this.each_service.id) {
  //         each['machines'] = each['machines'] || [];
  //         for (let machine of ev.list) {
  //           machine.checked = true;
  //           each.machines.push(machine);
  //         }
  //         console.log(
  //           'checking service data',
  //           this.sharedValue.listOfServices,
  //           this.MachineTypesList
  //         );
  //         break;
  //       }
  //     }
  //   } else {
  //     for (let mc of this.MachineTypesList) {
  //       if (ev.type == mc.type) {
  //         mc.checked = false;
  //         for (let each_mc of mc.list) {
  //           each_mc.checked = false;
  //         }
  //       }
  //     }
  //     for (let i = 0; i < this.sharedValue.listOfServices.length; i++) {
  //       console.log(this.sharedValue.listOfServices[i], this.each_service);
  //       if (this.sharedValue.listOfServices[i].id == this.each_service.id) {
  //         this.sharedValue.listOfServices['machines'] =
  //           this.sharedValue.listOfServices['machines'] || [];
  //         for (
  //           let j = 0;
  //           j < this.sharedValue.listOfServices[i].machines.length;
  //           j++
  //         ) {
  //           for (let machine of ev.list) {
  //             machine.checked = false;
  //             if (
  //               this.sharedValue.listOfServices[i].machines[j].id === machine.id
  //             ) {
  //               this.sharedValue.listOfServices[i].machines.splice(j, 1);
  //             }
  //           }
  //         }
  //         console.log(
  //           'checking service data',
  //           this.sharedValue.listOfServices,
  //           this.MachineTypesList
  //         );
  //         break;
  //       }
  //     }
  //   }
  // }