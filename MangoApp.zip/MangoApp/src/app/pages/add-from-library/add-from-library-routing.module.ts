import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddFromLibraryPage } from './add-from-library.page';

const routes: Routes = [
  {
    path: '',
    component: AddFromLibraryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AddFromLibraryPageRoutingModule {}
