import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ViewAllSearchResultsPage } from './view-all-search-results.page';

const routes: Routes = [
  {
    path: '',
    component: ViewAllSearchResultsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ViewAllSearchResultsPageRoutingModule {}
