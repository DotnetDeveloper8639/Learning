import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ViewAllSearchResultsPageRoutingModule } from './view-all-search-results-routing.module';

import { ViewAllSearchResultsPage } from './view-all-search-results.page';
import { componentModule } from '../../components/components.module';

@NgModule({
  imports: [
    CommonModule,
    componentModule,
    FormsModule,
    IonicModule,
    ViewAllSearchResultsPageRoutingModule,
  ],
  declarations: [ViewAllSearchResultsPage],
})
export class ViewAllSearchResultsPageModule {}
