import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common'
import { ModalController} from '@ionic/angular';
import { ProjectAccessComponent } from 'src/app/components/project-access/project-access.component'

@Component({
  selector: 'app-view-all-search-results',
  templateUrl: './view-all-search-results.page.html',
  styleUrls: ['./view-all-search-results.page.scss'],
})
export class ViewAllSearchResultsPage implements OnInit {
  constructor(private location: Location, public modalController: ModalController) { }

  goBack() {
    this.location.back();
  }

  doFilter() { }

  ngOnInit() { }

  async openAlertModal(msg, type, isProjectAccess) {
    console.log('data', type);
    let props = { type };
    console.log('name', props)
    const modal = await this.modalController.create({
      component: ProjectAccessComponent,
      cssClass: isProjectAccess
        ? 'mango-dashboard-customization-modal'
        : 'mango-upload-customization-modal ',
      backdropDismiss: false,
      componentProps: props,
      showBackdrop: false,
    });
    await modal.present();
  }
}
