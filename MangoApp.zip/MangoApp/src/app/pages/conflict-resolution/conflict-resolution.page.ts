import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { isNotEmptyArray } from 'src/app/utilities/utils';
import { PopoverController } from '@ionic/angular';
import { StatusPopoverComponent } from 'src/app/components/status-popover/status-popover.component';

@Component({
  selector: 'app-conflict-resolution',
  templateUrl: './conflict-resolution.page.html',
  styleUrls: ['./conflict-resolution.page.scss'],
})
export class ConflictResolutionPage implements OnInit {
  otherMeasure = 'iH'
  isAllConflictResolved = false;
  machineListInfo = [];
  availableRoadMap = [
    { title: 'AB1 - General Provisions', id: 'rd101', isRoadMapSelected: false },
    { title: 'BB3 - Embargo and Prohibity', id: 'rd102', isRoadMapSelected: false }
  ];

  availableQuestions = [
    { id: 'qs101', title: '1.1 Has the company established  an energy control', subtitle: 'MRO Lock Out / Tag Out', isQuestionSelected: false },
    { id: 'qs102', title: '1.2 Does the energy control procedure clearly and ', subtitle: 'MRO Lock Out / Tag Out', isQuestionSelected: false }
  ];

  availableConflictSolutions = [
    {
      id: 'cs101', title: '1.1 : MRO: Lock Out/ Tag Out',
      subtitle: `Has the company established  an energy control program, consisting of energy control procedures, 
      employee training, periodic inspections to ensure that before any employee perform any servicing or maintenance on a machine 
      or equipment where the unexpected energizing, startup or release of stored energy could occur and cause injury, the machine or 
      equipment shall be isolated from the energy source and rendered inoperative ? Reference: OSHA 29CFR1910.147(C)(1)`,
      chooseOptions: [
        {
          id: 'cs101co101', type: 'Yes, Compliant', reported_by: 'John Doe', notes: `Has the protective materials and hardware been 
        standardized, are identifiable and only used for the purpose of energy isolation? Reference: OSHA 29CFR1910.147(c)(5)`, isExpand: false
        },
        {
          id: 'cs101co102', type: 'Not Applicable', reported_by: 'Emma Watson', notes: `Has the protective materials and hardware been 
        standardized, are identifiable and only used for the purpose of energy isolation? Reference: OSHA 29CFR1910.147(c)(5)`, isExpand: false
        },
        {
          id: 'cs101co103', type: 'Report Hazard', reported_by: 'Jonathan', notes: `Has the protective materials and hardware been 
        standardized, are identifiable and only used for the purpose of energy isolation? Reference: OSHA 29CFR1910.147(c)(5)`, isExpand: false
        }
      ]
    },
    {
      id: 'cs102', title: '1.2 : MRO: Lock Out/ Tag Out',
      subtitle: `Has the company established  an energy control program, consisting of energy control program, 
      employee training, periodic inspections to ensure that before any employee perform any servicing or maintenance on a machine 
      or equipment where the unexpected energizing, startup or release of stored energy could occur and cause injury, the machine or 
      equipment shall be isolated from the energy source and rendered inoperative ? Reference: OSHA 29CFR1910.147(C)(1)`,
      chooseOptions: [
        {
          id: 'cs102co101', type: 'Yes, Compliant', reported_by: 'John Doe', notes: `Has the protective materials and hardware been 
        standardized, are identifiable and only used for the purpose of energy isolation? Reference: OSHA 29CFR1910.147(c)(5)`, isExpand: false
        },
        //{ id: 'cs102co102', type: 'Not Applicable', reported_by : 'Emma Watson' }
      ]
    }
  ]

  availableHazards = [
    { title: 'Right side safety key', assessor: 'Paul Travis', id: 'hz101', hazValue: 13500, accpetmessage: 'Unacceptable' },
    { title: 'Left side entry door', assessor: 'Clark Simon', id: 'hz102', hazValue: 320, accpetmessage: 'High' },
    { title: 'Left side entry door', assessor: 'Paul Travis', id: 'hz103', hazValue: 320, accpetmessage: 'Very High' },
  ];

  availableInitialHazards = [
    { id: 'ih101', title: 'Drawings were not provided and therefore the control category of the safety circuit cannot be determined', date: '22/01/2021' },
    { id: 'ih102', title: 'We did not locate any protective material or hardware required to isolate machines from stored energy', date: '22/01/2021' }
  ]

  availableControlMeasures = [
    { id: 'cm101', title: 'We did not locate any protective material or hardware required to isolate machines from stored energy', date: '22/01/2021', determinePlr: 'd', category: 3 }
  ]

  availableImages = [
    { name: '../../../assets/images/machine-list.png', id: 'im101' },
    { name: '../../../assets/images/machine-list.png', id: 'im102' },
    { name: '../../../assets/images/machine-list.png', id: 'im103' }
  ]

  constructor(public location: Location, public popController: PopoverController,) { }

  ngOnInit() { }

  ionViewWillEnter() {
    let body = {
      machine_Name: 'Wegoma xs',
      machine_Id: "mchqwe3456",
      serial_Number: "272639",
      asset_Id: "JETu433",
      isMachineSelected: false,
      masterMachine: {
        machine_Type: "Universal Turning"
      },
      assignedStaff: {
        display_Name: "Jack Ryan"
      },
      bucketName: {
        bucket_Id: "eeabshan",
        bucket_Name: "Press Machines"
      }
    }
    this.machineListInfo.push(body);
  }

  goBack() {
    this.location.back();
  }

  markSelectedAsResolved() {
    let anyMachineSelected = this.machineListInfo.some(_ml => _ml.isMachineSelected);
    if (anyMachineSelected) this.isAllConflictResolved = true;
  }

  changeSelectedMachinesList(event, machine) {
    event.stopPropagation();
    this.machineListInfo.forEach(_sl => {
      if (_sl.machine_Id == machine.machine_Id) {
        if (_sl.isMachineSelected) _sl.isMachineSelected = false
        else _sl.isMachineSelected = true
      }
    })
  }

  changeSelectedRoadmapList(roadmap) {
    this.availableRoadMap.forEach(_sl => {
      if (_sl.id == roadmap.id) {
        if (_sl.isRoadMapSelected) delete _sl.isRoadMapSelected
        else _sl.isRoadMapSelected = true
      }
    })
  }

  changeSelectedQuestionList(question) {
    this.availableQuestions.forEach(_sl => {
      if (_sl.id == question.id) {
        if (_sl.isQuestionSelected) delete _sl.isQuestionSelected
        else _sl.isQuestionSelected = true
      }
    })
  }

  specificMachineMarkAsResolved(event, machine) {
    event.stopPropagation();
  }

  changeOtherMeasureSegment(type) {
    if (type) this.otherMeasure = type
  }

  expandOrCollapseNotes(option) {
    option.isExpand = !option.isExpand
  }

  changeConflictSolutionCheckboxSelection() {
    this.availableConflictSolutions.forEach(_acs => {
      if (isNotEmptyArray(_acs.chooseOptions)) {
        let selectedOptions = _acs.chooseOptions.filter(_cs => _cs['isStepChecked']);
        _acs['selectedOptions'] = selectedOptions || [];
      }
    })
  }

  async openPopUp(ev, type) {
    let props = { type };
    const popover = await this.popController.create({
      component: StatusPopoverComponent,
      cssClass: 'popProReport',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      const { data } = result
      if (data && data == 'sort_by_name') { }
      else if (data && data == 'sort_by_hrn') { }
    });
  }

}
