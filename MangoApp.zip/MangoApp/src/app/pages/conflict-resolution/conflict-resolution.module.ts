import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ConflictResolutionPageRoutingModule } from './conflict-resolution-routing.module';

import { ConflictResolutionPage } from './conflict-resolution.page';
import { componentModule } from '../../components/components.module';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ConflictResolutionPageRoutingModule,
    componentModule,
    NgSelectModule
  ],
  declarations: [ConflictResolutionPage],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ConflictResolutionPageModule { }
