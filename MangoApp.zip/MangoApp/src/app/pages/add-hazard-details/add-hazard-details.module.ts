import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddHazardDetailsPageRoutingModule } from './add-hazard-details-routing.module';

import { AddHazardDetailsPage } from './add-hazard-details.page';
import { componentModule } from 'src/app/components/components.module';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    componentModule,
    AddHazardDetailsPageRoutingModule,
    NgSelectModule
  ],
  declarations: [AddHazardDetailsPage]
})
export class AddHazardDetailsPageModule {}
