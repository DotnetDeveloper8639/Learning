import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddHazardDetailsPage } from './add-hazard-details.page';

const routes: Routes = [
  {
    path: '',
    component: AddHazardDetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AddHazardDetailsPageRoutingModule {}
