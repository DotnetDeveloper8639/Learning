import { Component, OnInit } from '@angular/core';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { NgForm } from '@angular/forms';
import { ModalController } from '@ionic/angular';
import { PickHazardComponent } from '../../components/pick-hazard/pick-hazard.component';
import { Location } from '@angular/common';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { ShareValuesService } from '../../services/sharedValues/share-values.service';
import { PlrScreenComponent } from '../../components/plr-screen/plr-screen.component';
import { hazardConsequences, hazardSources, hazardTypes } from 'src/app/modals/hazard-data';
@Component({
  selector: 'app-add-hazard-details',
  templateUrl: './add-hazard-details.page.html',
  styleUrls: ['./add-hazard-details.page.scss'],
})
export class AddHazardDetailsPage implements OnInit {
  hardDetailsData: any = {};
  hazardTypeList = hazardTypes;
  hazardSourceList = [

  ];
  hazardConsequencesList = [
   
  ];
  addNewHazardDetails: any[] = [{}];
  gethazardTypeListLoading: boolean;
  gethazardSourceListLoading: boolean;
  gethazardConsequencesListLoading: boolean;
  hazardRatingList = [
    { listName: "Probability of Occurence", listNameView: "Probability Of Occurences(PO)", dataChrn: {}, dataIhrn: {}, rating: '' },
    { listName: "Degree of Severity", listNameView: "Degree Of Severity(SD)", dataChrn: {}, dataIhrn: {}, rating: '' },
    { listName: "Frequency of Exposition", listNameView: "Frequency Of Exposition(FE)", dataChrn: {}, dataIhrn: {}, rating: '' },
    { listName: "Number of Persons Exposed", listNameView: "Number Of Persons Exposed(NP)", dataChrn: {}, dataIhrn: {}, rating: '' }]
  // initailHazardRatingList = [
  //   { listName: "Probility of Occurences(PO)" },
  //   { listName: "Degree of Severity(SD)" },
  //   { listName: "Frequency of Exposition(FE)" },
  //   { listName: "Number of Persons Exposed(NP)" }]
  weightagesList = [
    { label: "Almost Impossible(3)", value: "3" },
    { label: "Highly Unlikely(1)", value: "1" },
    { label: "Unlikely(5)", value: "5" },
    { label: "Possible(5)", value: "5" },
    { label: "Even Chance(5)", value: "5" },
    { label: "Probable(8)", value: "8" },
    { label: "Likely(10)", value: "10" },
    { label: "Certain(15)", value: "15" },
    { label: "Fatality(15)", value: "15" },
    { label: "Constantly(5)", value: "5" },
    { label: "More Than 50(12)", value: "12" }
  ];
  machineModeLists = [];//[{ machineMode: "Setup", id: "2C7BF27C-F6BF-42F3-B064-DB0F6B561699" },{ machineMode: "Normal", id: "2CDGBF27C-F6BF-42F3-B064-DB0F6B561699" }]
  getMachineModesLoading: boolean;
  machineModeList = []
  sectionData: any;
  pickCntrlMeasureValue: any;
  pickInitialHazardValue: any;
  imageSrc: string | ArrayBuffer;
  files = [];
  hazardData: any;
  // determinePlrValue: string;
  constructor(public backendService: BackendCallService,
    public modalController: ModalController, public location: Location, private route: ActivatedRoute, private router: Router, private sharedValue: ShareValuesService) {
    this.machineModeLists = JSON.parse(localStorage.getItem('machineModeList'));
    this.route.queryParams.subscribe((params) => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.sectionData = this.router.getCurrentNavigation().extras.state.sectionData;
        this.hardDetailsData = this.router.getCurrentNavigation().extras.state.hazardData
        console.log('each sectionData', this.sectionData, this.hardDetailsData);
        this.addNewHazardDetails?.forEach((each, index) => {
          each.hazardType = this.hardDetailsData.hazardDetails?.formData?.hazardTypesData[index].hazardType;
          each.source = this.hardDetailsData.hazardDetails?.formData?.hazardTypesData[index].source;
          each.consequences = this.hardDetailsData?.hazardDetails?.formData.hazardTypesData[index].consequences;
        });
        this.hazardRatingList?.forEach((each) => {
          this.machineModeLists?.forEach((machine) => {
            each.dataChrn[machine] = this.hardDetailsData?.hazardDetails?.formData?.chrnTable[each.listName][machine];
            each.dataIhrn[machine] = this.hardDetailsData?.hazardDetails?.formData?.ihrnTable[each.listName][machine];
          });
        })
      }
    });
    console.log(JSON.parse(localStorage.getItem('machineModeList')));
  }

  ngOnInit() {
  }
  get chrnTotal() {
    return this.machineModeLists?.map((each) => {
      let temp = 1;
      for (let eachVal of this.hazardRatingList) {
        // temp += parseInt(eachVal.dataChrn[each]?.value || 0); 
        temp = temp * parseInt(eachVal.dataChrn[each]?.value || 1);
      }
      return temp == 1 ? 0 : temp;
    })
  }

  async determinePlr() {
    const modal = await this.modalController.create({
      component: PlrScreenComponent,
      cssClass: 'plr-screen-class',
      backdropDismiss: false,
      // componentProps: props,
      showBackdrop: false,
    });
    await modal.present();
    await modal.onDidDismiss().then((result) => {
      console.log(result.data.plr_value);
      if (result?.data) {
        this.hardDetailsData.determinePlrValue = result.data.plr_value;
      }
    });
  }

  async selectEvent(ev:any,index:number){
    const value=ev.split(" ")[0]
    this.hazardSourceList=hazardSources[value]
    this.hazardConsequencesList=hazardConsequences[value]
    this.addNewHazardDetails[index].consequences=null;
    this.addNewHazardDetails[index].source=null;

  }

  get ihrnTotal() {
    return this.machineModeLists?.map((each) => {
      let temp = 1;
      for (let eachVal of this.hazardRatingList) {
        // temp += parseInt(eachVal.dataIhrn[each]?.value || 0);
        temp = temp * parseInt(eachVal.dataIhrn[each]?.value || 1);
      }
      return temp == 1 ? 0 : temp;
    })
  }

  uploadFile(fileChangeEvent) {
    const self = this;
    if (fileChangeEvent.target.files && fileChangeEvent.target.files[0]) {
      const file = fileChangeEvent.target.files[0];
      const reader = new FileReader();
      reader.onload = e => {
        self.imageSrc = reader.result
        self.files.push(self.imageSrc);
      };
      console.log(self.imageSrc, reader.result);
      reader.readAsDataURL(file);

    }
    console.log("fileChangeEvent", fileChangeEvent, fileChangeEvent.target.files[0].name, this.files);
  }

  complete(form: NgForm) {
    if (form.valid) {
      console.log(form.value, JSON.stringify(form.value));
      let navigationExtras: NavigationExtras = {
        queryParamsHandling: 'preserve',
        state: {
          hazardDetails: { formData: form.value, files: this.files, pickCntrlMeasureValue: this.pickCntrlMeasureValue, pickInitialHazardValue: this.pickInitialHazardValue, determinePlrValue: this.hardDetailsData.determinePlrValue },
          sectionData: this.sectionData
        },
      };
      this.router.navigate([window.location.pathname], navigationExtras);
    } else {
      form.form.markAllAsTouched()
      this.sharedValue.errorShowToast('', "Please fill all the mandatory fields");
    }

  }


  getMachineModesList() {
    this.getMachineModesLoading = true;
    this.backendService.getMachineModesList()
      .subscribe(
        (data: any) => {
          this.machineModeList = data;
          this.getMachineModesLoading = false;
          console.log('getProjectId API called', data);
        },
        (err) => {
          this.getMachineModesLoading = false;
        }
      );
  }

  async openPickHazardsList(type) {
    const props = { type: type }
    const modal = await this.modalController.create({
      component: PickHazardComponent,
      cssClass: 'pickhazard-alert-modal',
      backdropDismiss: false,
      componentProps: props,
      showBackdrop: false,
    });
    await modal.present();
    await modal.onDidDismiss().then((result) => {
      if (result && result.data) {
        if (type == "Pick Control Measure") {
          this.pickCntrlMeasureValue = result.data.value
          this.hardDetailsData.pickControlMeasure = result.data.value
        } else {
          this.pickInitialHazardValue = result.data.value;
          this.hardDetailsData.pickInitialHazard = result.data.value;
        }
      }
    });
  }

  gethazardTypeList() {
    this.gethazardTypeListLoading = true;
    this.backendService.gethazardTypeList()
      .subscribe(
        (data: any) => {
          // this.hazardTypeList = data;
          this.gethazardTypeListLoading = false;
          console.log('gethazardTypeList API called', data);
        },
        (err) => {
          this.gethazardTypeListLoading = false;
        }
      );
  }

  gethazardSourceList() {
    this.gethazardSourceListLoading = true;
    this.backendService.gethazardSourceList()
      .subscribe(
        (data: any) => {
          // this.hazardSourceList = data;
          this.gethazardSourceListLoading = false;
          console.log('gethazardTypeList API called', data);
        },
        (err) => {
          this.gethazardSourceListLoading = false;
        }
      );
  }

  goBack() {
    // this.location.back()
    this.router.navigate([window.location.pathname]);
  }

  gethazardConsequencesList() {
    this.gethazardConsequencesListLoading = true;
    this.backendService.gethazardConsequencesList()
      .subscribe(
        (data: any) => {
          // this.hazardConsequencesList = data;
          this.gethazardConsequencesListLoading = false;
          console.log('gethazardTypeList API called', data);
        },
        (err) => {
          this.gethazardConsequencesListLoading = false;
        }
      );
  }

}
