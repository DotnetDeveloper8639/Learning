import { Component, OnInit, ViewChild } from '@angular/core';
import { ModalController, PopoverController } from '@ionic/angular';
import { AlertModalPage } from 'src/app/components/alert-modal/alert-modal.page';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { LoadingController } from '@ionic/angular';
import {
  doubleDecimal,
  isEmptyArray,
  isNotEmptyArray,
  isNotNullAndUndefined,
  toNumber,
} from 'src/app/utilities/utils';
import { SortingPipe } from 'src/app/pipes/sorting.pipe';
import { StatusPopoverComponent } from 'src/app/components/status-popover/status-popover.component';
import { LocalSettingsService } from './../../services/local-settings/local-settings.service';
import { AddRemoveColumnSelectorComponent } from 'src/app/components/add-remove-column-selector/add-remove-column-selector.component';
import { IonReorderGroup } from '@ionic/angular';
import { ItemReorderEventDetail } from '@ionic/core';
import { Router, NavigationExtras } from '@angular/router';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { ProjectrequestComponent } from 'src/app/components/projectrequest/projectrequest.component';
// import { HubConnection, HubConnectionBuilder } from '@aspnet/signalr'
import { environment } from 'src/environments/environment';
// import * as signalR from '@aspnet/signalr';
import { TranslateService } from "@ngx-translate/core";
import { TranslateModule } from '@ngx-translate/core';
import { LanguageSupportService } from 'src/app/services/language-support.service';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
})
export class DashboardPage implements OnInit {
  @ViewChild(IonReorderGroup) reorderGroup: IonReorderGroup;
  selectedTabTitle: string = 'DashBoard';
  projectLists = [];
  private bk_projectLists: any;
  sorOrderStatus: boolean = false;
  tasksManagersData = [];
  taskManagerUsers = [];
  projectTrackerColumnSelectorPermission: any = {};
  taskManagerColumnSelectorPermission: any = {};
  addRemoveColumnSelectorTypeFor = ['projectStatus', 'taskManagerWidgetColumnSelector'];
  isProjectTrackerWidgetPermission: boolean = true;
  isTaskManagerWidgetPermission: boolean = false;
  isFutureProjectsWidgetPermission: boolean = false;
  isOfferManagementWidgetPermission: boolean = false;
  isOrderManagementWidgetPermission: boolean = false;
  isRiskAssesssmentWidgetPermission: boolean = false;
  tableOrder = ['Task Manager', 'Project Status Tracker'];
  public isProjectStatusSearchbarExpand: boolean = false;
  selectedLanguage: any;
  fileName = 'Data.xlsx';

  constructor(
    public modalController: ModalController,
    public backendService: BackendCallService,
    public loadingController: LoadingController,
    public sortPipe: SortingPipe,
    public popoverController: PopoverController,
    public localSettingsSrv: LocalSettingsService,
    public router: Router,
    public sharedValue: ShareValuesService,
    private translateService: TranslateService, private tModule: TranslateModule, private serviceMulti: LanguageSupportService
    // public HubConnection: HubConnection,
    // public HubConnectionBuilder: HubConnectionBuilder
  ) { this.selectedLanguage = this.serviceMulti.getDefaultLanguage(); }

  ngOnInit() { }

  ionViewWillEnter() {
    this.getProjects();
    // this.getNotifications();
    this.initializeDashboardCustomization();
    const tableOrder = window.localStorage.getItem('TABLE-ORDER');
    if (tableOrder) {
      this.tableOrder = JSON.parse(tableOrder);
    }
  }

  ionViewWillLeave() {
    if (this.isProjectStatusSearchbarExpand) {
      this.isProjectStatusSearchbarExpand = !this.isProjectStatusSearchbarExpand;
      this.projectLists = this.bk_projectLists;
    }
  }

  swapWidgets(event: Event) {
    const ev = event as CustomEvent<ItemReorderEventDetail>;
    ev.detail.complete(this.tableOrder);
    window.localStorage.setItem('TABLE-ORDER', JSON.stringify(this.tableOrder));
  }

  getProjects() {
    const _self = this;
    _self.backendService
      .getProjectLists()
      .then((data) => {
        //   const { projects } = data;
        //   if (isNotEmptyArray(projects)) {
        //     projects.forEach((_p) => {
        //       if (_p.Actual_Time_hours && _p.Planned_Time_Hours)
        //         _p.timeHoursInPer = doubleDecimal(
        //           toNumber(
        //             ((_p.Actual_Time_hours / _p.Planned_Time_Hours) * 100) / 10
        //           )
        //         );
        //     });
        //     return (_self.projectLists = projects);
        //   }

        const { value } = data;
        //console.log('getting project data is now:', data);
        this.bk_projectLists = JSON.parse(JSON.stringify(data));
        return (_self.projectLists = data);
      })
      .catch((err) => {
        console.log('getting error for fetching projects lists:', err);
      });
  }

  getTaskManagerData() {
    this.backendService
      .getTaskManagerData()
      .then((data) => {
        const tasks = data;
        if (isNotEmptyArray(tasks)) {
          return (this.tasksManagersData = tasks);
        }
      })
      .catch((err) => {
        console.log('getting error for fetching task tracker lists:', err);
      });
  }

  // convertStringToNum(value) {
  //   let num = value.split('%');
  //   return toNumber(num[0]);
  // }

  sortData(data, widgetName?) {
    this.sorOrderStatus = !this.sorOrderStatus;
    if (widgetName === 'TaskManager') {
      this.sorOrderStatus == true
        ? this.sortPipe.transform(data, 'Task_Title', 'asc')
        : this.sortPipe.transform(data, 'Task_Title', 'dsc');
    } else {
      this.sorOrderStatus == true
        ? this.sortPipe.transform(data, 'project_name', 'asc')
        : this.sortPipe.transform(data, 'project_name', 'dsc');
    }
  }

  initializeDashboardCustomization() {
    this.sharedValue
      .getDashboardCustomizationSubjectData()
      .subscribe((data) => {
        if (data['isValueChanged']) {
          setTimeout(() => {
            this.getDashboardWidgetPermission();
          }, 502);
        }
      });
  }

  openDashboardCustomization(isDashboardCustomize) {
    const msg = `Are You Sure You Want to Reset to default widgets?`;
    this.openAlertModal(msg, isDashboardCustomize);
  }

  async openAlertModal(msg, isDashboardCustomize = false) {
    let props = { isDashboardCustomize };
    if (!msg) msg = `Are You Sure You Want to Reset to default widgets?`;
    if (!isDashboardCustomize) props['alertContent'] = msg;
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: isDashboardCustomize
        ? 'mango-dashboard-customization-modal'
        : 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    // const {
    //   data: { selectedDashboardWidgets, shouldResetDashboardWidgetPermission },
    // } = await modal.onWillDismiss();
    // if (
    //   shouldResetDashboardWidgetPermission ||
    //   (isNotNullAndUndefined(selectedDashboardWidgets) &&
    //     (isNotEmptyArray(selectedDashboardWidgets) ||
    //       isEmptyArray(selectedDashboardWidgets)))
    // )
    //   this.getDashboardWidgetPermission();
  }

  async openStatusPopover(ev: any, type, task?, projectStatus?, projectEncryptedId?) {
    let props = { type };
    if (projectStatus) props['projectStatus'] = projectStatus
    const popover = await this.popoverController.create({
      component: StatusPopoverComponent,
      cssClass: 'my-custom-class',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      const { data } = result;
      if (task && result.data !== undefined) {
        typeof result.data === 'string'
          ? (task.status = result.data)
          : (task.taskManagerUsers = result.data);
      }
      else if (data == 'editProj') this.navigateToEditProject(projectEncryptedId);
    });
  }

  navigateToEditProject(id) {
    this.sharedValue.edit_flow_temp_Encrypted_project_id = id;
    this.router.navigateByUrl('/project-management');
    setTimeout(() => {
      this.sharedValue.edit_flow_temp_Encrypted_project_id = '';
    }, 1000)
  }

  addOrRemoveColumnSelectorWidgets(type) {
    this.openAddOrRemoveColumnSelectorAlertModal(type);
  }

  getDashboardWidgetPermission() {
    const _self = this;
    _self.isProjectTrackerWidgetPermission =
      _self.localSettingsSrv.getProjectTrackerWidgetPermissionValue();
    _self.isTaskManagerWidgetPermission =
      _self.localSettingsSrv.getTaskManagerWidgetPermissionValue();
    _self.isFutureProjectsWidgetPermission =
      _self.localSettingsSrv.getFutureProjectsWidgetPermissionValue();
    _self.isOfferManagementWidgetPermission =
      _self.localSettingsSrv.getOfferManagementWidgetPermissionValue();
    _self.isOrderManagementWidgetPermission =
      _self.localSettingsSrv.getOrderManagementWidgetPermissionValue();
    _self.isRiskAssesssmentWidgetPermission =
      _self.localSettingsSrv.getRiskAssessmentWidgetPermissionValue();
    _self.getColumnSelectorPermission(_self.addRemoveColumnSelectorTypeFor);
    _self.loadDashboardTrackerData();
  }

  loadDashboardTrackerData() {
    if (this.isTaskManagerWidgetPermission) this.getTaskManagerData();
  }

  async openAddOrRemoveColumnSelectorAlertModal(type) {
    let props = { columnSelectorFor: type };
    const modal = await this.modalController.create({
      component: AddRemoveColumnSelectorComponent,
      cssClass: 'add-remove-widget-class',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const {
      data: {
        columnSelectorSelectedValue: {
          isDataChangedForColumnSelector,
          columnSelectorWidgetFor,
        },
      },
    } = await modal.onWillDismiss();
    if (isDataChangedForColumnSelector && columnSelectorWidgetFor) this.getColumnSelectorPermission([columnSelectorWidgetFor]);
  }

  getColumnSelectorPermission(types) {
    const _self = this;
    if (types.includes('projectStatus')) {
      const data =
        _self.localSettingsSrv.getProjectStatusColumnSelectorWidgetStorageValue();
      if (isNotEmptyArray(data))
        _self.checkProjectTrackerColumnSelectorPermission(data);
    }
    if (this.isTaskManagerWidgetPermission && types.includes('taskManagerWidgetColumnSelector')) {
      const data = _self.localSettingsSrv.getTaskManagerColumnSelectorWidgetStorageValue();
      if (isNotEmptyArray(data)) _self.checkTaskManagerColumnSelectorPermission(data);
    }
  }

  checkProjectTrackerColumnSelectorPermission(value) {
    const _self = this;
    value.forEach((_v) => {
      if (_v.val === 'pid')
        _self.projectTrackerColumnSelectorPermission['projectId'] =
          _v.isChecked;
      // if (_v.val === 'nom')
      //   _self.projectTrackerColumnSelectorPermission['noOfMachine'] =
      //     _v.isChecked;
      if (_v.val === 'pname')
        _self.projectTrackerColumnSelectorPermission['projectName'] =
          _v.isChecked;
      if (_v.val === 'cname')
        _self.projectTrackerColumnSelectorPermission['customerName'] =
          _v.isChecked;
      // if (_v.val === 'tih')
      //   _self.projectTrackerColumnSelectorPermission['timeInHours'] =
      //     _v.isChecked;
      if (_v.val === 'custId')
        _self.projectTrackerColumnSelectorPermission['customerId'] =
          _v.isChecked;
      // if (_v.val === 'aname')
      //   _self.projectTrackerColumnSelectorPermission['accountName'] =
      //     _v.isChecked;
      if (_v.val === 'contactName')
        _self.projectTrackerColumnSelectorPermission['contactName'] =
          _v.isChecked;
      if (_v.val === 'custAddress')
        _self.projectTrackerColumnSelectorPermission['customerAddress'] =
          _v.isChecked;
      // if (_v.val === 'cid')
      //   _self.projectTrackerColumnSelectorPermission['costInDollar'] =
      //     _v.isChecked;
      if (_v.val === 'rgns')
        _self.projectTrackerColumnSelectorPermission['regions'] = _v.isChecked;
      if (_v.val === 'pmname')
        _self.projectTrackerColumnSelectorPermission['projectManName'] =
          _v.isChecked;
      // if (_v.val === 'pp')
      //   _self.projectTrackerColumnSelectorPermission['projectPhase'] =
      //     _v.isChecked;
      // if (_v.val === 'rid')
      //   _self.projectTrackerColumnSelectorPermission['revenueInDollar'] =
      //     _v.isChecked;
      if (_v.val === 'prg')
        _self.projectTrackerColumnSelectorPermission['projectProgress'] =
          _v.isChecked;
      if (_v.val === 'hrPrg')
        _self.projectTrackerColumnSelectorPermission['projectHourProgress'] =
          _v.isChecked;
      // if (_v.val === 'std')
      //   _self.projectTrackerColumnSelectorPermission['startDate'] =
      //     _v.isChecked;
      if (_v.val === 'etd')
        _self.projectTrackerColumnSelectorPermission['endDate'] = _v.isChecked;
      if (_v.val === 'status')
        _self.projectTrackerColumnSelectorPermission['status'] = _v.isChecked;
    });
  }

  checkTaskManagerColumnSelectorPermission(value) {
    const _self = this;
    value.forEach((_v) => {
      if (_v.val === 'tid') _self.taskManagerColumnSelectorPermission['taskId'] = _v.isChecked;
      if (_v.val === 'tTitle') _self.taskManagerColumnSelectorPermission['taskTitle'] = _v.isChecked;
      if (_v.val === 'tLabel') _self.taskManagerColumnSelectorPermission['taskLabel'] = _v.isChecked;
      if (_v.val === 'tCreatedDate') _self.taskManagerColumnSelectorPermission['createdDate'] = _v.isChecked;
      if (_v.val === 'tPriority') _self.taskManagerColumnSelectorPermission['priority'] = _v.isChecked;
      if (_v.val === 'tDescrp') _self.taskManagerColumnSelectorPermission['description'] = _v.isChecked;
      if (_v.val === 'tAssignedTo') _self.taskManagerColumnSelectorPermission['assignedTo'] = _v.isChecked;
      if (_v.val === 'tDueDate') _self.taskManagerColumnSelectorPermission['dueDate'] = _v.isChecked;
      if (_v.val === 'tStatus') _self.taskManagerColumnSelectorPermission['status'] = _v.isChecked;
    });
  }

  // getNotifications() {
  //   //   const _self = this;
  //   //   _self.backendService
  //   //     .getNotification()
  //   //     .then((data) => {

  //   //       const { value } = data;
  //   //       //console.log('getting project data is now:', data);
  //   //       return (_self.projectLists = data);
  //   //     })
  //   //     .catch((err) => {
  //   //       console.log('getting error for fetching projects lists:', err);
  //   //     });

  //   const connection = new signalR.HubConnectionBuilder()
  //     .configureLogging(signalR.LogLevel.Debug)
  //     .withUrl('https://schsignalrnotifications.azurewebsites.net/' + 'notify', {

  //       skipNegotiation: true,
  //       transport: signalR.HttpTransportType.WebSockets
  //     })
  //     .build();

  //   connection.start().then(function () {
  //     console.log('SignalR Connected!');
  //   }).catch(function (err) {
  //     return console.error(err.toString());
  //   });
  // }

  apperProjectStatusTrackerSearch() {
    this.isProjectStatusSearchbarExpand = !this.isProjectStatusSearchbarExpand;
    if (!this.isProjectStatusSearchbarExpand) this.projectLists = this.bk_projectLists;
  }

  projectStatusTrackerSearch(event) {
    const { value } = event.detail;
    if (value && isNotEmptyArray(this.bk_projectLists)) {
      this.projectLists = this.bk_projectLists.filter(_bkpl => {
        return (
          (_bkpl.project_Id.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.project_Name.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.customer_Name.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.customer_Id.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.contact_Name.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.customer_Address.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.region.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.project_Manager.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.progress.toString().toLowerCase().indexOf(value)) > -1 ||
          (_bkpl.hours_Progress.toString().toLowerCase().indexOf(value)) > -1 ||
          (_bkpl.end_Date.toLowerCase().indexOf(value.toLowerCase())) > -1 ||
          (_bkpl.status.toLowerCase().indexOf(value.toLowerCase())) > -1
        );
      })
    } else this.projectLists = this.bk_projectLists;
  }

  //project Request Access 
  async openprojectRequest(msg, type, isProjectRequestAccess) {
    console.log('data', type);
    let props = { type };
    console.log('name', props)
    const modal = await this.modalController.create({
      component: ProjectrequestComponent,
      cssClass: isProjectRequestAccess
        ? 'mango-dashboard-customization-modal'
        : 'mango-upload-customization-modal ',
      backdropDismiss: false,
      componentProps: props,
      showBackdrop: false,
    });
    await modal.present();
  }

  languageChange() {
    this.serviceMulti.setLanguage(this.selectedLanguage);  // add this
  }

  exportProjectdata() {
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('ProjectStatusTracker');
    worksheet.columns = [
      { header: 'Project Id', key: 'project_Id', width: 12, },
      { header: 'Project Name', key: 'project_Name', width: 30 },
      { header: 'Customer Name', key: 'customer_Name', width: 30 },
      { header: 'Customer Id', key: 'customer_Id', width: 20 },
      { header: 'Contact Person', key: 'contact_Name', width: 20 },
      { header: 'Region', key: 'region', width: 10 },
      { header: 'Project Manager', key: 'project_Manager', width: 25 },
      { header: 'Progress', key: 'progress', width: 15 },
      { header: 'Hours Progress', key: 'hours_Progress', width: 15 },
      { header: 'End Date', key: 'end_Date', width: 15 },
      { header: 'Status', key: 'status', width: 15 },
      // { header: 'Contact Person', key: 'price', width: 10, style: { font: { name: 'Arial Black', size: 10 } } },
    ];
    worksheet.addRows(this.projectLists, "n");
    // worksheet.addRow({ ProjectId: e.project_Id, ProjectName: e.project_Name, CustomerName: e.customer_Name, CustomerId: e.customer_Id, ContactPerson: e.contact_Name, Region: e.region, ProjectManager: e.project_Manager, Progress: e.progress, HoursProgress: e.hours_Progress, EndDate: e.end_Date, Status: e.status }, "n");
    workbook.xlsx.writeBuffer().then((projectLists) => {
      let blob = new Blob([projectLists], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      fs.saveAs(blob, 'ProjectStatusTracker.xlsx');
    })
  }

  exportTaskMandata() {
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('TaskManager');
    worksheet.columns = [
      { header: 'Task Id', key: 'task_Id', width: 12, },
      { header: 'Task Title', key: 'task_Title', width: 30 },
      { header: 'Task Label', key: 'task_Label', width: 30 },
      { header: 'Created Date', key: 'created_Date', width: 20 },
      { header: 'Priority', key: 'priority', width: 20 },
      { header: 'Description', key: 'description', width: 10 },
      { header: 'Assigned To', key: 'assigned_To', width: 25 },
      { header: 'Due Date', key: 'due_Date', width: 15 },
      { header: 'Status', key: 'status', width: 15 },
    ];
    worksheet.addRows(this.tasksManagersData, "n");
    console.log('task', this.tasksManagersData)
    // worksheet.addRow({ ProjectId: e.project_Id, ProjectName: e.project_Name, CustomerName: e.customer_Name, CustomerId: e.customer_Id, ContactPerson: e.contact_Name, Region: e.region, ProjectManager: e.project_Manager, Progress: e.progress, HoursProgress: e.hours_Progress, EndDate: e.end_Date, Status: e.status }, "n");
    workbook.xlsx.writeBuffer().then((tasksManagersData) => {
      let blob = new Blob([tasksManagersData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      fs.saveAs(blob, 'TaskManager.xlsx');
    })
  }
}
