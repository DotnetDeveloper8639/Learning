import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { HazardChecklitsFourEyePageRoutingModule } from './hazard-checklits-four-eye-routing.module';

import { HazardChecklitsFourEyePage } from './hazard-checklits-four-eye.page';
import { componentModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HazardChecklitsFourEyePageRoutingModule,
    componentModule
  ],
  declarations: [HazardChecklitsFourEyePage]
})
export class HazardChecklitsFourEyePageModule { }
