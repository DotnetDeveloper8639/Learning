import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { HazardChecklitsFourEyePage } from './hazard-checklits-four-eye.page';

describe('HazardChecklitsFourEyePage', () => {
  let component: HazardChecklitsFourEyePage;
  let fixture: ComponentFixture<HazardChecklitsFourEyePage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ HazardChecklitsFourEyePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(HazardChecklitsFourEyePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
