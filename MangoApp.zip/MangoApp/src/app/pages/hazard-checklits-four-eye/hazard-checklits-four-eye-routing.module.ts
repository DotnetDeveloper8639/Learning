import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HazardChecklitsFourEyePage } from './hazard-checklits-four-eye.page';

const routes: Routes = [
  {
    path: '',
    component: HazardChecklitsFourEyePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HazardChecklitsFourEyePageRoutingModule {}
