import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';

@Component({
  selector: 'app-hazard-checklits-four-eye',
  templateUrl: './hazard-checklits-four-eye.page.html',
  styleUrls: ['./hazard-checklits-four-eye.page.scss'],
})
export class HazardChecklitsFourEyePage implements OnInit {
  hazardCheckLists: any;
  machineName: any;
  machineType: any;
  hazardMachineId: any;

  constructor(private route: ActivatedRoute, private location: Location, public backendService: BackendCallService,) { }

  ngOnInit() {
  }

  goBack() {
    this.location.back();
  }

  ionViewWillEnter() {
    this.machineName = this.route.snapshot.params.machinename;
    this.machineType = this.route.snapshot.params.machinetype;
    this.hazardMachineId = this.route.snapshot.params.hazardmachineid;
    //this.hazardMachineId && this.constructHazardChekList();
    this.hazardCheckLists = {
      hazardName: 'Right Side Safety Key',
      hazardTypeLists: [
        {
          hazardType: 'Electrical Hazards',
          hazardSource: [
            { list: 'electric arcs, electromagnetic phenomena' },
            { list: 'burning,electrocution' }
          ]
        },
        {
          hazardType: 'Mechanical Hazards',
          hazardSource: [
            { list: 'acceleration, decleration, sharp edges' },
            { list: 'running over, throwing' },
          ]
        }
      ],
      currentHazardRating: {
        machineMode: 'Normal, Set-up, Maintenance, Cleaning',
        hrnLists: [
          { list: 'Probability of Occurance (PO)', normal: 'Certain (15)', setup: 'Probable (8)', maintenance: 'Probable (8)', cleaning: 'Probable (8)', overallcalc: '13500' },
          { list: 'Degree of Severity (SD)', normal: 'Fatality (15)', setup: 'Fatality (15)', maintenance: 'Fatality (15)', cleaning: 'Fatality (15)', overallcalc: '7200' },
          { list: 'Frequency of Exposition (FE)', normal: 'Constantly (5)', setup: 'Constantly (5)', maintenance: 'Constantly (5)', cleaning: 'Constantly (5)', overallcalc: '7200' },
          { list: 'Number of Persons Exposed (NP)', normal: 'More than 50 (12)', setup: 'More than 50 (12)', maintenance: 'More than 50 (12)', cleaning: 'More than 50 (12)', overallcalc: '7200' }
        ]
      },
      initialHazard: 'We did not locate any protective material or hardware required to isolate machines from stored energy.',
      controlMeasure: {
        title: 'Install a safety sensor on the machine to detect the safe positioning of the tank.',
        determinedLabel: [
          { title: 'Determined Plr', value: 'd' },
          { title: 'Recommended Category ', value: '3' }
        ]
      },
      indicativeHazardRating: {
        machineMode: 'Normal, Set-up, Maintenance, Cleaning',
        hrnLists: [
          { list: 'Probability of Occurance (PO)', normal: 'Highly Unlikely (1)', setup: 'Unlikely (1,5)', maintenance: 'Unlikely (1,5)', cleaning: 'Unlikely (1,5)', overallcalc: '900' },
          { list: 'Degree of Severity (SD)', normal: 'Fatality (15)', setup: 'Fatality (15)', maintenance: 'Fatality (15)', cleaning: 'Fatality (15)', overallcalc: '13500' },
          { list: 'Frequency of Exposition (FE)', normal: 'Constantly (5)', setup: 'Constantly (5)', maintenance: 'Constantly (5)', cleaning: 'Constantly (5)', overallcalc: '13500' },
          { list: 'Number of Persons Exposed (NP)', normal: 'More than 50 (12)', setup: 'More than 50 (12)', maintenance: 'More than 50 (12)', cleaning: 'More than 50 (12)', overallcalc: '13500' }
        ]
      },
    }
  }

  constructHazardChekList() {
    this.backendService.getFourEyeQualityHazardCheckListsInfo(this.hazardMachineId).then(res => {

    }).catch(err => {
      console.log('getting issue in fetching four eye quality hazard cheklist info :', err);
    })
  }

}
