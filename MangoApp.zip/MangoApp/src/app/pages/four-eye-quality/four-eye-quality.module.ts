import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FourEyeQualityPageRoutingModule } from './four-eye-quality-routing.module';

import { FourEyeQualityPage } from './four-eye-quality.page';
import { componentModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FourEyeQualityPageRoutingModule,
    componentModule
  ],
  declarations: [FourEyeQualityPage]
})
export class FourEyeQualityPageModule { }
