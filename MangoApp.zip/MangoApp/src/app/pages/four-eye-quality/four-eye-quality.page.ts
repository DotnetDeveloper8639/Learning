import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { fourEyeQualicyCheckMachineModalLists } from 'src/app/modals/four-eye-quality-machines-modal';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';

@Component({
  selector: 'app-four-eye-quality',
  templateUrl: './four-eye-quality.page.html',
  styleUrls: ['./four-eye-quality.page.scss'],
})
export class FourEyeQualityPage implements OnInit {
  private fourEyeQualityLists = [];
  machineId: any;
  machineName: any;
  serviceMachineId: any;

  constructor(private route: ActivatedRoute, private location: Location, public backendService: BackendCallService) { }

  ngOnInit() {
    this.machineId = this.route.snapshot.params.machineid;
    this.serviceMachineId = this.route.snapshot.params.servicemachineid;
    this.machineName = this.route.snapshot.params.machinename;
    this.machineId && this.serviceMachineId && this.machineName && this.constructFourEyeQualityLists();
  }

  goBack() {
    this.location.back();
  }

  constructFourEyeQualityLists() {
    this.backendService.getFourEyeQualityPerformInfo(this.serviceMachineId).then(res => {
      if (res) this.fourEyeQualityLists.push(res);
    }).catch(err => {
      console.log('getting issue in fetching four eye quality info for machine list :', err);
    })
  }

}
