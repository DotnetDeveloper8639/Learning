import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { isNotEmptyArray } from 'src/app/utilities/utils';
import { ProjectManagementLayoutPage } from '../project-management-layout/project-management-layout.page';

@Component({
  selector: 'app-machine-details',
  templateUrl: './machine-details.page.html',
  styleUrls: ['./machine-details.page.scss'],
})
export class MachineDetailsPage implements OnInit {
  selectedSegment: string = "machineDetails";
  machine_details: any;
  project_id: any;
  isShowButton: any;
  isButtonEnable: boolean = false;
  constructor(private router: Router, private route: ActivatedRoute, public sharedValue: ShareValuesService, public backendService: BackendCallService,) {

  }

  ngOnInit() {

  }

  ionViewWillEnter() {
    const machineId = this.route.snapshot.params.id;
    ProjectManagementLayoutPage.searchServiceData.subscribe((res) => {
      if (res.machineListInfo.length) {
        this.machine_details = (res.machineListInfo as any[]).find((each) => each.machine_Id == machineId);
        this.getConfiguredroadmaps();
      }
    })
  }

  segmentChanged(ev) {
    console.log(ev);

  }

  configureRoadmap() {
    let navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      state: {
        machine_details: this.machine_details,
        // project_id:this.encrypted_project_id,
      },
    };
    this.router.navigate([window.location.pathname, 'risk-assessment'], navigationExtras)
  }

  getConfiguredroadmaps() {
    this.backendService.getConfiguredroadmaps(this.machine_details?.serviceMachine_Id[0]?.serviceMachineId)
      .subscribe(
        (data: any) => {
          this.sharedValue.selectedRoadmapsList = data;
          console.log('getConfiguredroadmaps API called', data);
          this.checkRoadMapStatus();
        },
        (err) => {
        }
      );
  }

  checkRoadMapStatus() {
    let listsOfRoadMapStatus = this.sharedValue.getRoadMapStatusLists();
    if (isNotEmptyArray(listsOfRoadMapStatus) && isNotEmptyArray(this.sharedValue.selectedRoadmapsList)) {
      listsOfRoadMapStatus.forEach(_ls => {
        this.sharedValue.selectedRoadmapsList.forEach(_sl => {
          if (_sl.id == _ls.roadMapId) _sl.status = _ls.status ? _ls.status : 'Not Started'
        })
      })
    }
  }

  openRoadMap(roadmap) {
    roadmap.serviceMachineId = this.machine_details?.serviceMachine_Id[0]?.serviceMachineId
    this.sharedValue.extendedRoadMapPayload.serviceMachineId = this.machine_details?.serviceMachine_Id[0]?.serviceMachineId
    this.sharedValue.extendedRoadMapPayload.userId = "7892B01E-5EE1-4702-81C1-DE9D35EA2FA9"
    let navigationExtras: NavigationExtras = {
      queryParams: roadmap,
      queryParamsHandling: 'merge'
    };
    this.router.navigate([window.location.pathname, 'risk-assessment-sections'], navigationExtras);
  }

  onUploadSystema() {
    this.isButtonEnable = true;
  }

}
