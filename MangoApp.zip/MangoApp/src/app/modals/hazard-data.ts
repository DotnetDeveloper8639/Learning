export const hazardTypes = ["Mechanical Hazard", "Electrical Hazard",
    "Thermal Hazard", "Noise Hazard", "Vibration Hazard", "Radiation Hazard",
    "Materials Hazard", "Ergonomis Hazard", "Environment Hazard", "Combination Hazard"]

export const hazardSources = {
    Mechanical: [
        { source: "acceleration, deceleration" },
        { source: "sharp edges" },
        { source: "moveable piece approaching to a fixed part" },
        { source: "cutting of parts" },
        { source: "elastic pieces" },
        { source: "object falling" },
        { source: "gravity" },
        { source: "height from the ground" },
        { source: "high pressure" },
        { source: "instability" },
        { source: "kinetic energy" },
        { source: "machine mobility" },
        { source: "moving parts" },
        { source: "rotating elements" },
        { source: "rough surface, slippery" },
        { source: "sharp edges" },
        { source: "energy stored" },
        { source: "vacuum" }
    ],
    Electrical: [
        { source: "electric arcs" },
        { source: "electromagnetic phenomena" },
        { source: "exposed circuits" },
        { source: "low dielectric strength" },
        { source: "exposed circuits under fault conditions" },
        { source: "short circuit" },
        { source: "thermal radiation" }

    ],
    Thermal: [
        { source: "explosion" },
        { source: "fire" },
        { source: "objects or materials with high or low temperature" },
        { source: "radiation from hot springs" }
    ],
    Noise: [
        { source: "cavitation phenomenon" },
        { source: "exhaust system" },
        { source: "gas leaking at high speed" },
        { source: "production processes (stamping, cutting, etc.)" },
        { source: "moving parts" },
        { source: "friction surfaces" },
        { source: "unbalanced rotating parts" },
        { source: "tire noise" },
        { source: "worn parts" }
    ],
    Vibration: [
        { source: "cavitation phenomenon" },
        { source: "misalignment of moving parts" },
        { source: "mobile equipment" },
        { source: "friction surfaces" },
        { source: "unbalanced rotating parts" },
        { source: "equipment that vibrates" },
        { source: "worn parts" }
    ],
    Radiation: [
        { source: "ionizing radiation sources" },
        { source: "low frequency electromagnetic radiation" },
        { source: "optical radiation (infrared, visible or ultraviolet), including laser" },
        { source: "electromagnetic radiations in radiofrequency" }
    ],
    Materials: [
        { source: "aerosols" },
        { source: "agents biological and microbiological (viral or bacterial)" },
        { source: "fuels" },
        { source: "dust" },
        { source: "explosives" },
        { source: "fiber" },
        { source: "flammable objects" },
        { source: "fluids" },
        { source: "fumes" },
        { source: "gases" },
        { source: "mixtures" },
        { source: "oxidants" }
    ],
    Ergonomis: [
        { source: "access" },
        { source: "project or location indicators, indicators and dashboards" },
        { source: "design, location or identification of control devices" },
        { source: "efforts" },
        { source: "twinkling, glowing, shadow, strobe effect" },
        { source: "spot light" },
        { source: "mental overload, idle" },
        { source: "posture" },
        { source: "repetitive activity" },
        { source: "visibility" }
    ],
    Environment: [
        { source: "dust or fog" },
        { source: "electromagnetic disturbance" },
        { source: "lightning" },
        { source: "humidity" },
        { source: "pollution" },
        { source: "snow" },
        { source: "temperature" },
        { source: "water" },
        { source: "wind" },
        { source: "lack of oxygen" }
    ],
    Combination: [
        { source: "for example, repetitive activities + effort"},
        {source:"for example, dehydration, loss of + high temperature environments" },
    ]

}
export const hazardConsequences = {
    Mechanical: [
        { consequence: "running over" },
        { consequence: "throwing" },
        { consequence: "crushing" },
        { consequence: "cutting and mutilation" },
        { consequence: "getting trapped or tangled" },
        { consequence: "getting stuck" },
        { consequence: "friction and abrasion" },
        { consequence: "impact" },
        { consequence: "injection" },
        { consequence: "scraping" },
        { consequence: "slipping, stumbling and falling" },
        { consequence: "drilling" },
        { consequence: "suffocation." },

    ],
    Electrical: [
        { consequence: "burning" },
        { consequence: "chemical effects" },
        { consequence: "effects on medical implants" },
        { consequence: "electrocution" },
        { consequence: "falling or throwing" },
        { consequence: "fire" },
        { consequence: "shock" },
        { consequence: "Projection of sparks"},
    ],
    Thermal: [
        { consequence: "burning" },
        { consequence: "dehydration" },
        { consequence: "discomfort" },
        { consequence: "Freeze" },
        { consequence: "damage caused by radiation of hot sources" },
        { consequence: "scald" }
    ],
    Noise: [
        { consequence: "discomfort" },
        { consequence: "loss of consciousness" },
        { consequence: "loss of balance" },
        { consequence: "permanent hearing loss" },
        { consequence: "stress" },
        { consequence: "buzz" },
        { consequence: "tiredness" },
        { consequence: "others (eg mechanical, electrical) due to interference in communication or acoustic signals" }
    ],
    Vibration: [
        { consequence: "discomfort" },
        { consequence: "lumbar morbidity" },
        { consequence: "neurological dysfunction" },
        { consequence: "osteo-articular disorders" },
        { consequence: " spine trauma" },
        { consequence: "vascular disorders" }
    ],
    Radiation: [
        { consequence: "burning" },
        { consequence: "damage to the eyes and skin" },
        { consequence: "effects on reproductive capacity" },
        { consequence: "mutations" },
        { consequence: " headache, insomnia, etc" },
        { consequence: "carcinogenic effects" }
    ],
    Materials: [
        { consequence: "difficulty breathing, choking" },
        { consequence: "cancer" },
        { consequence: "corrosion" },
        { consequence: "effects on reproductive capacity" },
        { consequence: "explosions" },
        { consequence: "fire" },
        { consequence: "infections" },
        { consequence: "mutations" },
        { consequence: "poisoning" },
        { consequence: "sensitivity disorders" }
    ],
    Ergonomis: [
        { consequence: "discomfort" },
        { consequence: "fatigue" },
        { consequence: "musculoskeletal disorders" },
        { consequence: "stress" },
        { consequence: "others (eg mechanical, electrical) due to human errors." },
    ],
    Environment: [
        { consequence: "burn" },
        { consequence: "mild illnesses" },
        { consequence: "falling or slipping" },
        { consequence: "suffocation" },
        { consequence: "any other consequence of the effect caused by sources hazards of the machine or its specific parts." },
        ],
    Combination: [
        { consequence: "for example, dehydration, loss of consciousness and heart attack" },
    ]
}












