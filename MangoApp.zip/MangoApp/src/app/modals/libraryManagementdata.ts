export const libraryManagementUserInfo = [
    {
        title: 'Machine Library',
        subtitle: 'Files | 205',
        icon: '../../../assets/images/Machine Library.svg',
    },
    {
        title: 'Standards Documents',
        subtitle: 'Files | 206',
        icon: '../../../assets/images/Standards Document.svg',
    },
    {
        title: 'Legislations Documents',
        subtitle: 'Files | 206',
        icon: '../../../assets/images/Legislations Document.svg',
    },
    {
        title: 'RoadMap Library',
        subtitle: 'Files | 206',
        icon: '../../../assets/images/Roadmap Document.svg',
    },
    {
        title: ' RA Process Library',
        subtitle: 'Files | 206',
        icon: '../../../assets/images/RA Process Library.svg',
    },
    {
        title: 'Hazard Catalog',
        subtitle: 'Files | 206',
        icon: '../../../assets/images/Hazard Catalog.svg',
    },
    {
        title: 'Report Template',
        subtitle: 'Files | 206',
        icon: '../../../assets/images/Report Template.svg',
    },
    {
        title: 'Control Measures',
        subtitle: 'Files | 206',
        icon: '../.././assets/images/control Measure.svg',
    },
    {
        title: 'Initial Hazards',
        subtitle: 'Files | 206',
        icon: '../../../assets/images/Initial Hazard.svg',
    },
];
export const recentDocumentsInfo = [
    {
        title: 'Wegoma VK-3522',
        subtitle: 'ISO 12100:2010',
        icon: '../../../assets/images/artboard10.svg',
    },
    {
        title: ' Wegoma KA-111',
        subtitle: 'ISO 12100:2012',
        icon: '../../../assets/images/artboard9.svg',
    },
    {
        title: '  Wegoma KL-148-P',
        subtitle: 'ISO 12100:2011',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: '  Wegoma: Circular Mitre',
        subtitle: 'ISO 12100:2010',
        icon: '../../../assets/images/artboard9.svg',
    },
    {
        title: '  Wegoma: Circular Mitre',
        subtitle: 'ISO 13850:2012',
        icon: '../../../assets/images/artboard10.svg',
    },
    {
        title: ' Wegoma KA-111',
        subtitle: 'ISO 12100:2009',
        icon: '../../../assets/images/artboard8.svg',
    },
];
export const bookmarksInfo = [
    {
        title: 'Wegoma VK-3522',
        subtitle: 'ISO 12100:2010',
        icon: '../../../assets/images/artboard10.svg',
    },
    {
        title: ' Wegoma KA-111',
        subtitle: 'ISO 12100:2012',
        icon: '../../../assets/images/artboard9.svg',
    },
    {
        title: '  Wegoma KL-148-P',
        subtitle: 'ISO 12100:2011',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: '  Wegoma: Circular Mitre ',
        subtitle: 'ISO 12100:2010',
        icon: '../../../assets/images/artboard9.svg',
    },
    {
        title: '  Wegoma: Circular Mitre',
        subtitle: 'ISO 13850:2012',
        icon: '../../../assets/images/artboard10.svg',
    },
    {
        title: ' Wegoma KA-111',
        subtitle: 'ISO 12100:2009',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: '  Wegoma: Circular Mitre ',
        subtitle: 'ISO 12100:2010',
        icon: '../../../assets/images/artboard9.svg',
    },
    {
        title: '  Wegoma: Circular Mitre',
        subtitle: 'ISO 13850:2012',
        icon: '../../../assets/images/artboard10.svg',
    },
    {
        title: ' Wegoma KA-111',
        subtitle: 'ISO 12100:2009',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: '  Wegoma KL-148-P',
        subtitle: 'ISO 12100:2011',
        icon: '../../../assets/images/artboard8.svg',
    },
];
export const machineDetails = [
    {
        title: 'Wegoma VK-3522',
        description: 'The VK-3522 Glass Installation and Control Units from Wegoma boasts a robust, strong construction for long-lasting results',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'Wegoma KA-111',
        description: 'The Wegoma KA-111 Transom Groover provides clean welding to seams and crosses on the top and bottom transom sight surfaces.',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
    {
        title: 'Wegoma KL-148-P',
        description: 'The KL 148P disposes of a pneumatic saw aggregate feed as well as of an automatic work routine and an infinitely variable adjustable tempo, this allows a light and easy work. The v-cutting saw KL 148M disposes of a manual saw aggregate feed.',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'Wegoma: Circular Mitre ',
        description: 'The MS 550 is a very robust machine with big exactness. All regulators and all settings are in the front of the machine. hydropneumatic saw feed adjustable, sawblade inclination 90° - 45° right via handwheel',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
];
export const standardDetails = [
    {
        title: 'ISO 12100:2010',
        description: 'TSafety of machinery — General principles for design — Risk assessment and risk reduction',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'ISO 13849-1:2015',
        description: 'Safety of machinery — Safety- related parts of control systems — Part 1: General principles for design',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
    {
        title: 'ISO 13849-2:2012',
        description: 'Safety of machinery — Safety- related parts of control systems — Part 2: Validation',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'ISO 13850:2015',
        description: 'Safety of machinery — Emergency stop function — Principles for design',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
];
export const legislationsDocuments = [
    {
        title: 'ISO 12100:2010',
        description: 'TSafety of machinery — General principles for design — Risk assessment and risk reduction',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'ISO 13849-1:2015',
        description: 'Safety of machinery — Safety- related parts of control systems — Part 1: General principles for design',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
    {
        title: 'ISO 13849-2:2012',
        description: 'Safety of machinery — Safety- related parts of control systems — Part 2: Validation',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'ISO 13850:2015',
        description: 'Safety of machinery — Emergency stop function — Principles for design',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
];
export const roadmapDocument = [
    {
        title: 'ISO 12100:2010',
        description: 'TSafety of machinery — General principles for design — Risk assessment and risk reduction',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'ISO 13849-1:2015',
        description: 'Safety of machinery — Safety- related parts of control systems — Part 1: General principles for design',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
    {
        title: 'ISO 13849-2:2012',
        description: 'Safety of machinery — Safety- related parts of control systems — Part 2: Validation',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'ISO 13850:2015',
        description: 'Safety of machinery — Emergency stop function — Principles for design',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
];
export const raProcessLibrary = [
    {
        title: 'ISO 12100:2010',
        description: 'TSafety of machinery — General principles for design — Risk assessment and risk reduction',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'ISO 13849-1:2015',
        description: 'Safety of machinery — Safety- related parts of control systems — Part 1: General principles for design',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
    {
        title: 'ISO 13849-2:2012',
        description: 'Safety of machinery — Safety- related parts of control systems — Part 2: Validation',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'ISO 13850:2015',
        description: 'Safety of machinery — Emergency stop function — Principles for design',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
];
export const hazardCatalog = [
    {
        title: 'ISO 12100:2010',
        description: 'TSafety of machinery — General principles for design — Risk assessment and risk reduction',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'ISO 13849-1:2015',
        description: 'Safety of machinery — Safety- related parts of control systems — Part 1: General principles for design',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
    {
        title: 'ISO 13849-2:2012',
        description: 'Safety of machinery — Safety- related parts of control systems — Part 2: Validation',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'ISO 13850:2015',
        description: 'Safety of machinery — Emergency stop function — Principles for design',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
];
export const reportTemplate = [
    {
        title: 'ISO 12100:2010',
        description: 'TSafety of machinery — General principles for design — Risk assessment and risk reduction',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'ISO 13849-1:2015',
        description: 'Safety of machinery — Safety- related parts of control systems — Part 1: General principles for design',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
    {
        title: 'ISO 13849-2:2012',
        description: 'Safety of machinery — Safety- related parts of control systems — Part 2: Validation',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard8.svg',
    },
    {
        title: 'ISO 13850:2015',
        description: 'Safety of machinery — Emergency stop function — Principles for design',
        subDesc: 'Released October 2011 Ver 1.3',
        icon: '../../../assets/images/artboard9.svg',
    },
]
