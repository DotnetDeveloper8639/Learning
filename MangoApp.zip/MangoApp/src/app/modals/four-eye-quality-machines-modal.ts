export const fourEyeQualicyCheckMachineModalLists = [
    {
        machineName: 'Wegoma THX',
        type: 'Cleaner',
        madeIn: 'Germany',
        location: 'Brazil',
        roadMapsLists: [
            {
                rmap: 'NRI-General Provisions',
                tHazard: 3,
                rHazard: 0,
                deviations: 0,
                reviewer: 'Pramod',
                status: false
            },
            {
                rmap: 'NR3-Embargo and Prohibition',
                tHazard: 2,
                rHazard: 0,
                deviations: 0,
                reviewer: 'Ammy',
                status: true
            },
            {
                rmap: 'NR3-Embargo and Prohibition',
                tHazard: 2,
                rHazard: 0,
                deviations: 0,
                reviewer: 'Ammy',
                status: true
            },
            {
                rmap: 'NR3-Embargo and Prohibition',
                tHazard: 2,
                rHazard: 0,
                deviations: 0,
                reviewer: 'Ammy',
                status: false
            }
        ]
    },
    {
        machineName: 'Wegoma THX',
        type: 'Cleaner',
        madeIn: 'Germany',
        location: 'Brazil',
        roadMapsLists: [
            {
                rmap: 'NRI-General Provisions',
                tHazard: 3,
                rHazard: 0,
                deviations: 0,
                reviewer: 'Pramod',
                status: false
            },
            {
                rmap: 'NR3-Embargo and Prohibition',
                tHazard: 2,
                rHazard: 0,
                deviations: 0,
                reviewer: '',
                status: false
            }
        ]
    }
]