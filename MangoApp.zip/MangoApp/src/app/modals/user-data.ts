export const userManagementUserInfo = [
    { 'id': 1, 'name': 'Patricia Rivera', 'thumbnailUrl': '' },
    { 'id': 2, 'name': 'Bobby Diaz', 'thumbnailUrl': '', },
    { 'id': 3, 'name': 'Bobby McDonald', 'thumbnailUrl': '' },
    { 'id': 4, 'name': 'Bobby Reyes', 'thumbnailUrl': '' },
    { 'id': 5, 'name': 'Larry Alvarado', 'thumbnailUrl': '' },
    { 'id': 6, 'name': 'Craig Andrews', 'thumbnailUrl': '' },
    { 'id': 7, 'name': 'Martha Pierce', 'thumbnailUrl': '' },
    { 'id': 8, 'name': 'Rose Holmes', 'thumbnailUrl': '' },
]

export const roleManagementUserInfo = [
    { 'id': 1, 'name': 'Philip Wade', 'role': 'Line Manager', 'type': 'user', 'thumbnailUrl': '' },
    { 'id': 2, 'name': 'Nicolas Holland', 'role': 'Sales Clerk', 'type': 'user', 'thumbnailUrl': '', },
    { 'id': 3, 'name': 'Barbara Willis', 'role': 'Line Manager', 'type': 'group', 'thumbnailUrl': '' },
    { 'id': 4, 'name': 'Eliza Cooper', 'role': 'Sales Clerk', 'type': 'user', 'thumbnailUrl': '' },
    { 'id': 5, 'name': 'Rose Gilbert', 'role': 'Sales Clerk', 'type': 'group', 'thumbnailUrl': '' },
    { 'id': 6, 'name': 'Bruce Griffin', 'role': 'Sales Clerk', 'type': 'group', 'thumbnailUrl': '' },
    { 'id': 7, 'name': 'Dan Cook', 'role': 'Sales Clerk', 'type': 'group', 'thumbnailUrl': '' },
    { 'id': 8, 'name': 'Rose Holmes', 'role': 'Sales Clerk', 'type': 'user', 'thumbnailUrl': '' },
    { 'id': 9, 'name': 'Martha Pierce', 'role': '', 'thumbnailUrl': '' },
    { 'id': 10, 'name': 'Maggy', 'role': '', 'thumbnailUrl': '' },
]

export const roleManagementAllRoles = [
    { 'id': 1, 'name': 'Global Admin', 'role': '', 'thumbnailUrl': '' },
    { 'id': 2, 'name': 'Local Admin', 'role': '', 'thumbnailUrl': '' },
    { 'id': 3, 'name': 'Line Manager', 'role': 'Org Role', 'thumbnailUrl': '' },
    { 'id': 4, 'name': 'Project Manager', 'role': '', 'thumbnailUrl': '' },
    { 'id': 5, 'name': 'Project Operator', 'role': '', 'thumbnailUrl': '' },
]

export const groupManagementAllGroups = [
    {
        'id': 1, 'name': 'John Deer Grp', 'sub_name': 'Pharetra quam', 'users': [
            { 'thumbnailUrl': '' },
            { 'thumbnailUrl': '' },
            { 'thumbnailUrl': '' }
        ]
    },
    {
        'id': 2, 'name': 'Electrical Grp', 'sub_name': 'Odio eros maecenas', 'users': [
            { 'thumbnailUrl': '' },
            { 'thumbnailUrl': '' },
            { 'thumbnailUrl': '' }
        ]
    },
    {
        'id': 3, 'name': 'Robotics Grp', 'sub_name': 'Eget purus', 'users': [
            { 'thumbnailUrl': '' },
            { 'thumbnailUrl': '' },
            { 'thumbnailUrl': '' },
            { 'thumbnailUrl': '' },
            { 'thumbnailUrl': '' }
        ]
    },
]
export const projectAccessInfo = [
    {
        ProjectId: 'PRJ20210517-001',
        ProjectName: 'John Deere ',
        Region: 'Russia',
        Approved: 'Luke',
        Request: '10/07/2021',
        RequestStatus: 'Pending'
    },
    {
        ProjectId: 'PRJ20210517-001',
        ProjectName: 'Wegoma',
        Region: 'Canada',
        Approved: 'Philips',
        Request: '10/07/2021',
        RequestStatus: 'Approved'
    },
    {
        ProjectId: 'PRJ20210517-001',
        ProjectName: 'NLX 2000',
        Region: 'Germany',
        Approved: 'Emily',
        Request: '10/07/2021',
        RequestStatus: 'Approved'
    },
    {
        ProjectId: 'PRJ20210517-001',
        ProjectName: 'Wegoma 3000',
        Region: 'USA',
        Approved: 'John',
        Request: '10/07/2021',
        RequestStatus: 'Pending'
    },
];