import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  {
    path: 'login',
    loadChildren: () =>
      import('./pages/login/login.module').then((m) => m.LoginPageModule),
  },
  {
    path: 'dashboard',
    loadChildren: () =>
      import('./pages/dashboard/dashboard.module').then(
        (m) => m.DashboardPageModule
      ),
  },
  {
    path: 'view-all-search-results',
    loadChildren: () =>
      import(
        './pages/view-all-search-results/view-all-search-results.module'
      ).then((m) => m.ViewAllSearchResultsPageModule),
  },
  {
    path: 'offer-management',
    loadChildren: () =>
      import('./pages/offer-management/offer-management.module').then(
        (m) => m.OfferManagementPageModule
      ),
  },
  {
    path: 'offer-management/create-offer/create-service',
    loadChildren: () =>
      import('./pages/create-service/create-service.module').then(
        (m) => m.CreateServicePageModule
      ),
  },

  {
    path: 'project-management',
    loadChildren: () =>
      import('./pages/project-management/project-management.module').then(
        (m) => m.ProjectManagementPageModule
      ),
  },
  // {
  //   path: 'project-management/project-detail/:id',
  //   loadChildren: () =>
  //     import('./pages/project-detail/project-detail.module').then(
  //       (m) => m.ProjectDetailPageModule
  //     ),
  // },
  {
    path: 'user-management',
    loadChildren: () =>
      import('./user-management/user-management.module').then(
        (m) => m.UserManagementPageModule
      ),
  },
  {
    path: 'project-detail',
    loadChildren: () =>
      import('./pages/project-detail/project-detail.module').then(
        (m) => m.ProjectDetailPageModule
      ),
  },
  {
    path: 'add-machine',
    loadChildren: () =>
      import('./pages/add-machine/add-machine.module').then(
        (m) => m.AddMachinePageModule
      ),
  },
  {
    path: 'offer-management/add-machine',
    loadChildren: () =>
      import('./pages/add-machine/add-machine.module').then(
        (m) => m.AddMachinePageModule
      ),
  },
  {
    path: 'offer-management/create-offer',
    loadChildren: () =>
      import('./pages/create-offer/create-offer.module').then(
        (m) => m.CreateOfferModule
      ),
  },
  {
    path: 'offer-management/view-offer/:id',
    loadChildren: () =>
      import('./pages/view-offer/view-offer.module').then(
        (m) => m.ViewOfferPageModule
      ),
  },
  {
    path: 'view-offer/create-offer',
    loadChildren: () =>
      import('./pages/create-offer/create-offer.module').then(
        (m) => m.CreateOfferModule
      ),
  },
  {
    path: 'order-management',
    loadChildren: () =>
      import('./pages/order-management/order-management.module').then(
        (m) => m.OrderManagementPageModule
      ),
  },
  {
    path: 'order-management/view-order/:id',
    loadChildren: () =>
      import('./pages/view-order/view-order.module').then(
        (m) => m.ViewOrderPageModule
      ),
  },
  {
    path: 'offer-management/add-from-library',
    loadChildren: () =>
      import('./pages/add-from-library/add-from-library.module').then(
        (m) => m.AddFromLibraryPageModule
      ),
  },
  {
    path: 'library-management',
    loadChildren: () => import('./pages/library-management/library-management.module').then(m => m.LibraryManagementPageModule)
  },
  {
    path: 'library-management/viewLibrary/view-library-man-details/:title',
    loadChildren: () => import('./pages/viewLibrary/view-library-man-details/view-library-man-details.module').then(m => m.ViewLibraryManDetailsPageModule)
  },
  {
    path: 'four-eye-quality',
    loadChildren: () => import('./pages/four-eye-quality/four-eye-quality.module').then(m => m.FourEyeQualityPageModule)
  },
  {
    path: 'dashboard/project-detail/:id/four-eye-quality/:machineid/:servicemachineid/:machinename',
    loadChildren: () => import('./pages/four-eye-quality/four-eye-quality.module').then(m => m.FourEyeQualityPageModule)
  },
  {
    path: 'project-management/project-detail/:id/four-eye-quality/:machineid/:servicemachineid/:machinename',
    loadChildren: () => import('./pages/four-eye-quality/four-eye-quality.module').then(m => m.FourEyeQualityPageModule)
  },
  {
    path: 'machine-details',
    loadChildren: () => import('./pages/machine-details/machine-details.module').then(m => m.MachineDetailsPageModule)
  },
  {
    path: 'machine-detail-four-eye-quality',
    loadChildren: () => import('./pages/machine-detail-four-eye-quality/machine-detail-four-eye-quality.module').then(m => m.MachineDetailFourEyeQualityPageModule)
  },
  {
    path: 'dashboard/project-detail/:id/four-eye-quality/:machineid/:servicemachineid/:machinename/machine-detail-four-eye-quality/:machinetype',
    loadChildren: () => import('./pages/machine-detail-four-eye-quality/machine-detail-four-eye-quality.module').then(m => m.MachineDetailFourEyeQualityPageModule)
  },
  {
    path: 'project-management/project-detail/:id/four-eye-quality/:machineid/:servicemachineid/:machinename/machine-detail-four-eye-quality/:machinetype',
    loadChildren: () => import('./pages/machine-detail-four-eye-quality/machine-detail-four-eye-quality.module').then(m => m.MachineDetailFourEyeQualityPageModule)
  },
  {
    path: 'hazard-checklits-four-eye',
    loadChildren: () => import('./pages/hazard-checklits-four-eye/hazard-checklits-four-eye.module').then(m => m.HazardChecklitsFourEyePageModule)
  },
  {
    path: 'dashboard/project-detail/:id/four-eye-quality/:machineid/:servicemachineid/:machinename/machine-detail-four-eye-quality/:machinetype/hazard-checklits-four-eye/:hazardmachineid',
    loadChildren: () => import('./pages/hazard-checklits-four-eye/hazard-checklits-four-eye.module').then(m => m.HazardChecklitsFourEyePageModule)
  },
  {
    path: 'project-management/project-detail/:id/four-eye-quality/:machineid/:servicemachineid/:machinename/machine-detail-four-eye-quality/:machinetype/hazard-checklits-four-eye/:hazardmachineid',
    loadChildren: () => import('./pages/hazard-checklits-four-eye/hazard-checklits-four-eye.module').then(m => m.HazardChecklitsFourEyePageModule)
  },
  {
    path: 'offer-management/edit-machines',
    loadChildren: () => import('./pages/edit-machines/edit-machines.module').then(m => m.EditMachinesPageModule)
  },
  {
    path: 'project-management/project-detail/:id',
    data: {
      previousPage: 'project-management'
    },
    loadChildren: () => import('./pages/project-management-layout/project-management-layout.module').then(m => m.ProjectManagementLayoutPageModule)
  },
  {
    path: 'dashboard/project-detail/:id',
    data: {
      previousPage: 'dashboard'
    },
    loadChildren: () => import('./pages/project-management-layout/project-management-layout.module').then(m => m.ProjectManagementLayoutPageModule)
  },
  {
    path: 'generate-report',
    loadChildren: () => import('./pages/generate-report/generate-report.module').then(m => m.GenerateReportPageModule)
  },
  {
    path: 'conflict-resolution',
    loadChildren: () => import('./pages/conflict-resolution/conflict-resolution.module').then(m => m.ConflictResolutionPageModule)
  },
  {
    path: 'dashboard/project-detail/:id/conflict-resolution',
    loadChildren: () => import('./pages/conflict-resolution/conflict-resolution.module').then(m => m.ConflictResolutionPageModule)
  },
  {
    path: 'project-management/project-detail/:id/conflict-resolution',
    loadChildren: () => import('./pages/conflict-resolution/conflict-resolution.module').then(m => m.ConflictResolutionPageModule)
  },
  {
    path: 'provisional-quote',
    loadChildren: () => import('./pages/provisional-quote/provisional-quote.module').then( m => m.ProvisionalQuotePageModule)
  },
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule { }
