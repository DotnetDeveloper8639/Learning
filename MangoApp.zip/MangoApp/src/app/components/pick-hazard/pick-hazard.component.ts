import { Component, Input, OnInit, Pipe, PipeTransform, Type } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-pick-hazard',
  templateUrl: './pick-hazard.component.html',
  styleUrls: ['./pick-hazard.component.scss'],
})
export class PickHazardComponent implements OnInit {
  @Input() type: string;
  initialHazardsList = [];
  selectedData;
  constructor(public backendService: BackendCallService,
    public sharedValue: ShareValuesService, public modalController: ModalController) { }

  ngOnInit() {
  }

  ionViewWillEnter() {
    if (this.type == 'Pick Initial Hazard') this.getInitialHazardsList();
    else this.getCounterMeasuresList()
  }

  showSearchBarIcon(){

  }

  close() {
    this.modalController.dismiss()
  }

  getCounterMeasuresList() {
    this.backendService.getCounterMeasuresList()
      .subscribe(
        (data: any) => {
          this.initialHazardsList = data;
          //console.log('getInitialHazardsList API called', data);
        },
        (err) => {
        }
      );
  }

  save() {
    this.modalController.dismiss(this.selectedData)
  }

  getInitialHazardsList() {
    this.backendService.getInitialHazardsList()
      .subscribe(
        (data: any) => {
          this.initialHazardsList = data;
          //console.log('getInitialHazardsList API called', data);
        },
        (err) => {
        }
      );
  }

}
@Pipe({
  name: 'searchFilter'
})

export class SearchFilterPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (!value) return null;
    if (!args) return value;

    args = args.toLowerCase();
    console.log("search", value, args);

    return value.filter(function (data) {
      return JSON.stringify(data).toLowerCase().includes(args);
    });
  }

}

