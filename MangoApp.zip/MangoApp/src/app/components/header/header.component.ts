import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, PopoverController } from '@ionic/angular';
import { NotificationComponent } from '../notification/notification.component';
import { StatusPopoverComponent } from '../status-popover/status-popover.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  showSearchBar: boolean = false;
  isItemAvailable = false;
  toggled: boolean = false;
  isinputitems: boolean = false
  dummyData = [];
  constructor(
    private router: Router,
    private modalController: ModalController,
    private popController: PopoverController
  ) { }

  ngOnInit() { }

  showSearchBarIcon() {
    this.showSearchBar = !this.showSearchBar;
    // this.isinputitems = !this.isinputitems
    this.isinputitems = true;
  }
  initializeItem() {
    this.dummyData = [
      {
        name: 'top-menu-1',
        item: [
          {
            name: 'item-1-1',
            item: [
              {
                name: 'item-1-1-1',
                item: [
                  {
                    name: 'item-1-1-1-1',
                    url: '/item1111',
                  },
                  {
                    name: 'item-1-1-1-2',
                    url: '/item1112',
                  },
                ],
              },
              {
                name: 'item-1-1-2',
                item: [
                  {
                    name: 'item-1-1-2-1',
                    url: '/item1121',
                  },
                  {
                    name: 'item-1-1-2-2',
                    url: '/item1122',
                  },
                ],
              },
            ],
          },
          {
            name: 'item-1-2',
            item: [
              {
                name: 'item-1-2-1',
                item: [
                  {
                    name: 'item-1-2-1-1',
                    url: '/item1211',
                  },
                  {
                    name: 'item-1-2-1-2',
                    url: '/item1212',
                  },
                ],
              },
              {
                name: 'item-1-2-2',
                item: [
                  {
                    name: 'item-1-2-2-1',
                    url: '/item1221',
                  },
                  {
                    name: 'item-1-2-2-2',
                    url: '/item1222',
                  },
                ],
              },
            ],
          },
        ],
      },
      {
        name: 'top-menu-2',
        item: [
          {
            name: 'item-2-1',
            item: [
              {
                name: 'item-2-1-1',
                item: [
                  {
                    name: 'item-2-1-1-1',
                    url: '/item2111',
                  },
                  {
                    name: 'item-2-1-1-2',
                    url: '/item2112',
                  },
                ],
              },
              {
                name: 'item-2-1-2',
                item: [
                  {
                    name: 'item-2-1-2-1',
                    url: '/item2121',
                  },
                  {
                    name: 'item-2-1-2-2',
                    url: '/item2122',
                  },
                ],
              },
            ],
          },
          {
            name: 'item-2-2',
            item: [
              {
                name: 'item-2-2-1',
                item: [
                  {
                    name: 'item-2-2-1-1',
                    url: '/item2211',
                  },
                  {
                    name: 'item-2-2-1-2',
                    url: '/item2212',
                  },
                ],
              },
              {
                name: 'item-2-2-2',
                item: [
                  {
                    name: 'item-2-2-2-1',
                    url: '/item2221',
                  },
                  {
                    name: 'item-2-2-2-2',
                    url: '/item2222',
                  },
                ],
              },
            ],
          },
        ],
      },
    ];
  }
  getItems(ev: any) {
    //console.log('get data', ev);

    // Reset items back to all of the items
    this.initializeItem();

    // set val to the value of the searchbar
    const val = ev.target.value;

    // if the value is an empty string don't filter the items
    if (val && val.trim() !== '') {
      this.isItemAvailable = true;
      this.dummyData = this.dummyData.filter((item) => {
        return item.name.toLowerCase().indexOf(val.toLowerCase()) > -1;
      });
    } else {
      this.isItemAvailable = false;
      // this.isinputitems = false
    }
  }

  viewAllResults() {
    this.isItemAvailable = false;
    this.isinputitems = true;
    this.showSearchBar = !this.showSearchBar;
    this.router.navigate(['view-all-search-results']);
  }

  async showNotification() {
    const popover = await this.popController.create({
      component: NotificationComponent,
      cssClass: 'my-custom-class',
      // event: ev,
      translucent: true,
    });
    await popover.present();
    // const { role } = await popover.onDidDismiss();
    // console.log('onDidDismiss resolved with role', role);
  }

  showDefaultBar() {
    this.showSearchBar = !this.showSearchBar;
  }

  async openLanSettings(ev: any, type, task?) {
    let props = { type };
    const popover = await this.popController.create({
      component: StatusPopoverComponent,
      cssClass: 'langsettings',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      console.log(result,'checkResult')
    });
  }

  closePopOver() {
    this.popController.dismiss()
  }

}
