import { Component, Input, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { isEmptyArray, isNotEmptyArray } from 'src/app/utilities/utils';

@Component({
  selector: 'app-add-machine-to-bucket',
  templateUrl: './add-machine-to-bucket.component.html',
  styleUrls: ['./add-machine-to-bucket.component.scss'],
})
export class AddMachineToBucketComponent implements OnInit {
  @Input() shouldCreateOnlyNewBucket: boolean = false;
  @Input() shouldEditBucket: boolean = false;
  @Input() bucketLists: any;
  title = "Add To Bucket"
  bucketListInfo: any = [];
  selectedBucketRadioValue: any;
  shouldNewBucketCreate: boolean = false;
  newBucketInput: any;
  isAlertBox: boolean = false;
  contentToDelete: any;
  contentToDeleteId: any;
  isAnyBucketNameEdited: boolean = false;
  bucketListToEdit = [];
  isAnyBucketDeleted: boolean = false;
  editOrDeleteSelectionCheckboxInfo = {
    isAllCheckboxSelected: false,
    selectedCount: 0
  }
  chooseAnyBucketFirstToDelete: boolean = false;
  deletedBucketLists = [];
  everyCheckBoxSelected: any;
  isAnyBucketCheckboxSelectedToDelete: boolean = false;

  constructor(public modalController: ModalController, public sharedValue: ShareValuesService) { }

  ngOnInit() {
    //this.bucketListInfo = this.sharedValue.bucketLists;
    this.bucketListInfo = this.bucketLists;
    if (this.shouldCreateOnlyNewBucket) {
      this.title = 'Create New Bucket';
      this.shouldNewBucketCreate = true;
    } else if (this.shouldEditBucket) this.title = 'Edit or Delete Buckets'
  }

  close() {
    if (this.shouldNewBucketCreate && !this.shouldCreateOnlyNewBucket) this.resetToDefaultType();
    else {
      this.modalController.dismiss({});
    }
  }

  resetToDefaultType() {
    this.title = "Add To Bucket"
    this.shouldNewBucketCreate = false;
    this.newBucketInput = '';
  }

  addBucket() {
    if (this.shouldNewBucketCreate) {
      this.newBucketInput && this.closeModalAndPassBucketName(this.newBucketInput, '')
    } else {
      this.selectedBucketRadioValue && this.closeModalAndPassBucketName('', this.selectedBucketRadioValue)
    }
  }

  closeModalAndPassBucketName(bucketName, bucketId) {
    let _scaatb = false;
    if (this.shouldNewBucketCreate && this.newBucketInput) _scaatb = true;
    this.modalController.dismiss({
      'bucketName': bucketName,
      'bucketId': bucketId,
      'shouldAddToBucket': this.shouldCreateOnlyNewBucket ? true : false,
      'shouldConstructAndAddToBucket': _scaatb
    });
  }

  changeSelectedBucketRadioData(event) {
    this.selectedBucketRadioValue = event.detail.value;
  }

  createNewBucket() {
    this.title = 'Add To New Bucket';
    this.shouldNewBucketCreate = true
  }

  deleteBucket(bucket) {
    this.isAlertBox = true;
    this.contentToDelete = bucket.bucket_Name;
    this.contentToDeleteId = bucket.bucket_Id;
  }

  closeAlert() {
    this.isAlertBox = false;
    this.contentToDelete = null;
    this.contentToDeleteId = null;
    if (this.editOrDeleteSelectionCheckboxInfo.selectedCount > 0) {
      this.isAnyBucketCheckboxSelectedToDelete = true
      setTimeout(() => { this.isAnyBucketCheckboxSelectedToDelete = false }, 500)
    }
  }

  confirmBucketDelete() {
    if (this.editOrDeleteSelectionCheckboxInfo.isAllCheckboxSelected || this.everyCheckBoxSelected) {
      this.isAnyBucketDeleted = true;
      if (isEmptyArray(this.deletedBucketLists)) this.deletedBucketLists = this.bucketListInfo;
      else this.bucketListInfo.filter(_bl => { if (_bl.isCheckboxSelected) this.deletedBucketLists.push(_bl) });
      this.saveEditOption();
    } else if (!this.editOrDeleteSelectionCheckboxInfo.isAllCheckboxSelected && !this.everyCheckBoxSelected && this.bucketListInfo.some(_bl => _bl.isCheckboxSelected)) {
      this.bucketListInfo.filter(_bl => {
        if (_bl.isCheckboxSelected) this.deletedBucketLists.push(_bl)
      });
      this.bucketListInfo = this.bucketListInfo.filter(_bl => !_bl.isCheckboxSelected);
      this.isAnyBucketDeleted = true;
      this.closeAlert();
      this.editOrDeleteSelectionCheckboxInfo.selectedCount = 0;
    } else {
      this.isAnyBucketDeleted = true;
      let _mb = this.bucketListInfo.find(_bl => _bl.bucket_Id == this.contentToDeleteId);
      _mb && this.deletedBucketLists.push(_mb);
      this.bucketListInfo = this.bucketListInfo.filter(_bl => _bl.bucket_Id !== this.contentToDeleteId);
      this.closeAlert();
      this.editOrDeleteSelectionCheckboxInfo.selectedCount = 0;
      if (isEmptyArray(this.bucketListInfo)) this.saveEditOption();
    }
  }

  saveEditOption() {
    let editedBucketInfo = [];
    let deletedBucketInfo = [];
    if (this.isAnyBucketNameEdited && isNotEmptyArray(this.bucketListToEdit)) editedBucketInfo = this.bucketListToEdit.filter(_ble => !_ble.isSameName);
    if (this.isAnyBucketDeleted && isNotEmptyArray(this.deletedBucketLists)) deletedBucketInfo = this.deletedBucketLists
    this.modalController.dismiss({
      'updatedBucketLists': editedBucketInfo,
      'deletedBucketLists': deletedBucketInfo,
      'isBucketUpdated': true
    });
  }

  editBucketName(event, bucketInfo) {
    let isBucketNameIsSame = (bucketInfo.bucket_Name.trim() == event.detail.value.trim())
    let matchedBucketLists = this.bucketListInfo.find(_bck => _bck.bucket_Name === bucketInfo.bucket_Name);
    if (matchedBucketLists) {
      let body = { 'title': bucketInfo.bucket_Name, 'bucketId': bucketInfo.bucket_Id, 'newTitle': event.detail.value, 'isSameName': isBucketNameIsSame }
      if (isNotEmptyArray(this.bucketListToEdit)) {
        let matchedBucketToEdit = this.bucketListToEdit.find(_be => _be.title == bucketInfo.bucket_Name)
        if (matchedBucketToEdit) {
          matchedBucketToEdit.newTitle = event.detail.value;
          matchedBucketToEdit.isSameName = isBucketNameIsSame
        }
        else this.bucketListToEdit.push(body);
      } else this.bucketListToEdit.push(body);
    }
    let isBucketNameEdited = this.bucketListToEdit.some(_ble => !_ble.isSameName)
    this.isAnyBucketNameEdited = isBucketNameEdited;
  }

  deleteAllSelectedBucket() {
    if (this.editOrDeleteSelectionCheckboxInfo.selectedCount == 0) return this.chooseAnyBucketFirstToDelete = true;
    else {
      let anyCheckboxSelected = this.bucketListInfo.some(_bkl => _bkl.isCheckboxSelected)
      if (anyCheckboxSelected) {
        const { selectedCount } = this.editOrDeleteSelectionCheckboxInfo
        this.isAlertBox = true;
        this.contentToDelete = (selectedCount == this.bucketListInfo.length ? 'All Buckets' : selectedCount > 1 ? 'Buckets' : 'Bucket');
      } else this.chooseAnyBucketFirstToDelete = true
    }
  }

  changeAllEditOrDeleteBucketSelection() {
    this.bucketListInfo.forEach(_bl => _bl.isCheckboxSelected = this.editOrDeleteSelectionCheckboxInfo.isAllCheckboxSelected)
  }

  changeParticularEditOrDeleteBucketCheckboxSelection(bucketList) {
    if (!this.isAnyBucketCheckboxSelectedToDelete) {
      if (bucketList.isCheckboxSelected) this.editOrDeleteSelectionCheckboxInfo.selectedCount++;
      else this.editOrDeleteSelectionCheckboxInfo.selectedCount--;
      if (this.editOrDeleteSelectionCheckboxInfo.selectedCount > 0 && this.chooseAnyBucketFirstToDelete) this.chooseAnyBucketFirstToDelete = false;
      let everyCheckboxSelected = this.bucketListInfo.every(_bkl => _bkl.isCheckboxSelected);
      if (everyCheckboxSelected) this.editOrDeleteSelectionCheckboxInfo.isAllCheckboxSelected = true;
      this.everyCheckBoxSelected = everyCheckboxSelected
    }
  }

}