import { Component, Input, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { isEmptyArray, isNotEmptyArray } from 'src/app/utilities/utils';
import { roleManagementAllRoles, roleManagementUserInfo } from 'src/app/modals/user-data';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';

@Component({
  selector: 'app-search-modal',
  templateUrl: './search-modal.component.html',
  styleUrls: ['./search-modal.component.scss'],
})
export class SearchModalComponent implements OnInit {
  @Input() type: any;
  isItemAvailable = false;
  dummyData = [];
  users = [];
  userNotFound: boolean = true;
  enterUserConsoleGroupName: any;
  enterUserConsoleAddRole: any;
  availableRolesInfo = [];
  selectedRoleToAssign = null;
  availableUnasssignedRoleToUser: any;
  isAnyUserSelectedFor4EyeCheck: boolean = false;
  selectedCustomerRadioValue: any;
  constructor(public modalController: ModalController, public backendCallService: BackendCallService) { }

  ngOnInit() {
  }

  ionViewWillEnter() {
    this.users = [];
    if (this.type === 'user_console_role_mang_assign_user_role') {
      this.getAllRoles();
      // this.availableRolesInfo = roleManagementAllRoles;
      // this.availableUnasssignedRoleToUser = roleManagementUserInfo.filter(_rmui => !_rmui.role);

    }
  }

  getAllRoles() {
    return this.backendCallService.getAllRoles().then(_roles => {
      const { Data } = _roles
      if (isNotEmptyArray(Data)) {
        this.availableRolesInfo = Data;
        console.log('this.availableRolesInfo :', this.availableRolesInfo);
      }
    }).catch(err => {
      console.log('Issue in fetching all roles:', err);
    })
  }

  initializeItem() {
    if (this.type === 'user_console_role_mang_assign_user_role') {
      this.dummyData = this.availableUnasssignedRoleToUser || [];
    } else {
      this.dummyData = [
        {
          albumId: 1,
          id: 1,
          title: 'accusamus beatae ad facilis cum similique qui sunt',
          url: 'https://via.placeholder.com/600/92c952',
          thumbnailUrl: 'https://wallpaperaccess.com/full/2213426.jpg',
          name: 'John',
          checked: false,
        },
        {
          albumId: 1,
          id: 2,
          title: 'reprehenderit est deserunt velit ipsam',
          url: 'https://via.placeholder.com/600/771796',
          thumbnailUrl:
            'https://d2qp0siotla746.cloudfront.net/img/use-cases/profile-picture/template_3.jpg',
          name: 'Rayon',
          checked: false,
        },
        {
          albumId: 1,
          id: 3,
          title: 'officia porro iure quia iusto qui ipsa ut modi',
          url: 'https://via.placeholder.com/600/24f355',
          thumbnailUrl:
            'https://data.whicdn.com/images/322027365/original.jpg?t=1541703413',
          name: 'Jack',
          checked: false,
        },
        {
          albumId: 1,
          id: 4,
          title: 'culpa odio esse rerum omnis laboriosam voluptate repudiandae',
          url: 'https://via.placeholder.com/600/d32776',
          thumbnailUrl:
            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRoR705XkXkGGsCyzwkEBv72MLAkns5q7NVXr5NemRUiKYZ9VYPWRGKayXmXhhEMmvuOaI&usqp=CAU',
          name: 'Raju',
          checked: false,
        },
        {
          albumId: 1,
          id: 5,
          title: 'natus nisi omnis corporis facere molestiae rerum in',
          url: 'https://via.placeholder.com/600/f66b97',
          thumbnailUrl:
            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3e6GhxT-87Dy--Q1NI8mu31-vobrE4ruInA&usqp=CAU',
          name: 'Ramesh',
          checked: false,
        },
      ];
      if (this.type == 'user_console_add_user' || this.type == 'user_console_group_mang_add_group' || this.type == 'assign-4-eye-quality-check-user') this.dummyData.forEach(_dd => _dd.thumbnailUrl = '')
    }
  }
  getItems(ev: any) {
    if (this.type == 'user_console_add_user') {
      const { value } = ev.target;
      if (value) this.searchUserToToAdd(value);
      else {
        this.isItemAvailable = false;
        this.userNotFound = true;
        if (isNotEmptyArray(this.dummyData)) this.dummyData = [];
      }
    } else if (this.type == 'user_console_role_mang_assign_user_role' || this.type == 'user_console_group_mang_add_group') {
      const { value } = ev.target;
      if (value) this.searchUserToAddInRoles(value);
      else {
        this.isItemAvailable = false;
        if (isNotEmptyArray(this.dummyData)) this.dummyData = [];
      }
    } else {
      // Reset items back to all of the items
      this.initializeItem();

      // set val to the value of the searchbar
      const val = ev.target.value;

      // if the value is an empty string don't filter the items
      if (val && val.trim() !== '') {
        this.isItemAvailable = true;
        this.dummyData = this.dummyData.filter((item) => {
          return item.name.toLowerCase().indexOf(val.toLowerCase()) > -1;
        });
        if (this.type == 'user_console_add_user' || this.type == 'assign-4-eye-quality-check-user') this.userNotFound = isEmptyArray(this.dummyData) ? true : false;
      } else {
        this.isItemAvailable = false;
        if (this.type == 'user_console_add_user' || this.type == 'assign-4-eye-quality-check-user') this.userNotFound = true;
        if (this.type == 'assign-4-eye-quality-check-user') this.anyUserAddedFor4EyeQualityCheck()
      }
    }
  }

  searchUserToToAdd(searchWord) {
    this.backendCallService.searchUserInfoToAdd().then(_userlists => {
      const { Data } = _userlists
      if (isNotEmptyArray(Data) && searchWord && searchWord.trim() !== '') {
        //this.isItemAvailable = true;
        this.dummyData = Data;
        this.dummyData = this.dummyData.filter((item) => {
          return item.Display_Name.toLowerCase().indexOf(searchWord.toLowerCase()) > -1;
        });
        if (isNotEmptyArray(this.dummyData)) { this.isItemAvailable = true; this.userNotFound = false; }
        else { this.isItemAvailable = false; this.userNotFound = true; }
      }
    }).catch(err => {
      console.log('Issue in fetching User Info To Add :', err);
    })
  }

  searchUserToAddInRoles(searchWord) {
    this.backendCallService.getAllUsers().then(_users => {
      const { Data } = _users
      if (isNotEmptyArray(Data) && searchWord && searchWord.trim() !== '') {
        this.dummyData = Data;
        this.dummyData.forEach(_dd => { _dd.Display_Name = _dd.First_Name + ' ' + _dd.Last_Name })
        this.dummyData = this.dummyData.filter((item) => {
          return (
            item.First_Name.toLowerCase().indexOf(searchWord.toLowerCase()) > -1 ||
            item.Last_Name.toLowerCase().indexOf(searchWord.toLowerCase()) > -1
          );
        });
        if (isNotEmptyArray(this.dummyData)) this.isItemAvailable = true;
        else this.isItemAvailable = false;
      }
    }).catch(err => {
      console.log('Issue in fetching User Info for adding in roles :', err);
    })
  }

  addUser(event, data) {
    data.checked = event.detail.checked;
    this.dummyData.find((item) => item.id == data.id).checked = data.checked;
    //if (this.type == 'assign-4-eye-quality-check-user') this.anyUserAddedFor4EyeQualityCheck();
  }

  anyUserAddedFor4EyeQualityCheck() {
    if (this.selectedCustomerRadioValue) this.selectedCustomerRadioValue = '';
    if (!this.selectedCustomerRadioValue) this.isAnyUserSelectedFor4EyeCheck = false
  }

  changeSelectedRadioValue(event) {
    this.selectedCustomerRadioValue = event.detail.value;
    if (this.selectedCustomerRadioValue) this.isAnyUserSelectedFor4EyeCheck = true;
  }

  close() {
    this.modalController.dismiss({
      dismissed: true,
      // selectedDashboardWidgets: value
    });
  }
  assignUser(modetype?) {
    let selectedUsers = []
    this.dummyData.filter((each: any) => {
      each.checked ? this.users.push(each) : '';
    });
    if (this.type == 'assign-4-eye-quality-check-user') {
      selectedUsers = this.dummyData.filter(_dd => { return _dd.id == this.selectedCustomerRadioValue })
    } else selectedUsers = this.users
    this.modalController
      .dismiss({
        dismissed: true,
        selectedUsers: selectedUsers,
        modeType: this.type,
        groupName: this.enterUserConsoleGroupName,
        newRole: this.enterUserConsoleAddRole,
        roleToAssign: this.selectedRoleToAssign ? this.selectedRoleToAssign : ''
      })
      .then(() => (this.users = []));
  }

  removeUser(data) {
    console.log(data);
    if (this.type == 'user_console_add_user' || this.type == 'user_console_role_mang_assign_user_role' || this.type == 'user_console_group_mang_add_group') {
      let matchedUser = this.dummyData.find(_dd => _dd.Id == data.Id)
      if (matchedUser && matchedUser.checked) matchedUser.checked = false;
    } else {
      this.dummyData.find((item) => item.id == data.id).checked = false;
      this.isItemAvailable = false;
    }
  }
}
