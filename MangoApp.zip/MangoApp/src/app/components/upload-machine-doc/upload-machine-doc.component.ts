import { Component, Input, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import { isNotEmptyArray } from 'src/app/utilities/utils';
import { Router } from '@angular/router';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { ModalController, ToastController } from '@ionic/angular';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
type AOA = any[][];

@Component({
  selector: 'app-upload-machine-doc',
  templateUrl: './upload-machine-doc.component.html',
  styleUrls: ['./upload-machine-doc.component.scss'],
})
export class UploadMachineDocComponent implements OnInit {
  data: AOA = [[1, 2], [3, 4]];
  master = [];
  roadMapData = []
  @Input() type: any;
  isShowButton: any;
  isButtonEnable: boolean = false;
  libraryManagementUserInfo = [];
  roadMapUploadData: any;
  configure: any;



  constructor(
    public backendService: BackendCallService,
    public modalController: ModalController,
    public toastController: ToastController,
    public sharedValue: ShareValuesService,
    public router: Router
  ) { }

  ngOnInit() {
  }

  //machineUpload File
  onUploadChange(evt: any) {
    if (isNotEmptyArray(this.master)) this.master = []
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];
      this.data = <AOA>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
      console.log('data is', JSON.stringify(this.data));
      for (let i = 0; i <= this.data.length; i++) {
        if (i > 0 && isNotEmptyArray(this.data[i])) {
          // if (this.data[i][0] == '' || this.data[i][1] == '' || this.data[i][2] == '') {
          // }
          this.master.push({
            "Machine_Name": this.data[i][0],
            "Machine_Type": this.data[i][1],
            "Manufacturer": this.data[i][2]
          })
        }
      }
      this.uploadMacLibrary()
    }
    reader.readAsBinaryString(target.files[0]); {
    }
  }

  //RoadMapUpload File
  onRoadMapUpload(evt: any) {
    if (isNotEmptyArray(this.roadMapData)) this.roadMapData = []
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];
      this.data = <AOA>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
      console.log('data is', JSON.stringify(this.data));
      for (let i = 0; i <= this.data.length; i++) {
        if (i > 0 && isNotEmptyArray(this.data[i])) {
          this.roadMapData.push({
            roadMapMasterId: '',
            roadMapName: this.data[i][0],
            roadMapVersion: "" + this.data[i][5] + "",
            description: this.data[i][1],
            // version: ,
            roadMapSections: [{
              roadMapSectionId: '',
              roadMapMasterId: '',
              sectionName: this.data[i][2],
              roadMapSubSection: [{
                roadMapSubSectionId: "string",
                roadMapSectionId: "string",
                subSectionName: "string",
                stepMaster: [{
                  stepMasterId: '',
                  stepBody: "" + this.data[i][4] + ""
                }]
              }]
            }]
          })
        }
      }
      console.log('map', JSON.stringify(this.roadMapData))
      this.uploadRmap()
    }
    reader.readAsBinaryString(target.files[0]);
  }

  // Control Measure Documents
  onUploadControlMeasure(evt: any) {
    if (isNotEmptyArray(this.master)) this.master = [];
    const userId = "7892B01E-5EE1-4702-81C1-DE9D35EA2FA9"
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];
      this.data = <AOA>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
      console.log('data is', JSON.stringify(this.data));
      for (let i = 0; i <= this.data.length; i++) {
        if (i > 0 && isNotEmptyArray(this.data[i])) {
          this.master.push({
            "id": "",
            "value": "" + this.data[i][0] + "",
            "userId": userId,
          })
        }
        console.log('configre', this.master)
      }
      this.uploadControlMeaLibrary()
    }
    reader.readAsBinaryString(target.files[0]); {
    }
  }

  onUploadInitialHazard(evt: any) {
    if (isNotEmptyArray(this.master)) this.master
    const target: DataTransfer = <DataTransfer>(evt.target);
    const userId = "7892B01E-5EE1-4702-81C1-DE9D35EA2FA9"
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];
      this.data = <AOA>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
      console.log('data is', JSON.stringify(this.data));
      for (let i = 0; i <= this.data.length; i++) {
        if (i > 0 && isNotEmptyArray(this.data[i])) {
          this.master.push({
            "id": "",
            "value": "" + this.data[i][0] + "",
            "userId": userId
          })
        }
      }
      this.UploadInitialHazardLibrary()
    }
    reader.readAsBinaryString(target.files[0]); {
    }
  }

  uploadRmap() {
    this.backendService.uploadRoadMapData(this.roadMapData).subscribe(
      (response: any) => {
        console.log('response', response);
        if (response.value == "Failed to save data") {
          this.sharedValue.showToast('', 'Failed to save data');
          this.isButtonEnable = false;
        }
        else {
          // this.sharedValue.showToast('', 'Data is saved ');
          this.isButtonEnable = true
        }
      },
      (err) => { }
    )
  }

  uploadMacLibrary() {
    this.backendService.uploadMasterData(this.master).subscribe(
      (response: any) => {
        console.log('response', response);
        if (response.value == "Failed to save data") {
          this.sharedValue.showToast('', 'Failed to save data');
          this.isButtonEnable = false;
        }
        else {
          // this.sharedValue.showToast('', 'Data is saved ');
          this.isButtonEnable = true
        }
      },
      (err) => { }
    )
  }

  uploadControlMeaLibrary() {
    this.backendService.uploadControlMeasure(this.master).subscribe(
      (response: any) => {
        console.log('response', response);
        if (response.value == "Failed to save data") {
          this.sharedValue.showToast('', 'Failed to save data');
          this.isButtonEnable = false;
        }
        else {
          // this.sharedValue.showToast('', 'Data is saved ');
          this.isButtonEnable = true
        }
      },
      (err) => { }
    )
  }

  UploadInitialHazardLibrary() {
    this.backendService.uploadIntialHazard(this.master).subscribe(
      (response: any) => {
        console.log('response', response);
        if (response.value == "Failed to save data") {
          this.sharedValue.showToast('', 'Failed to save data');
          this.isButtonEnable = false;
        }
        else {
          // this.sharedValue.showToast('', 'Data is saved ');
          this.isButtonEnable = true
        }
      },
      (err) => { }
    )
  }

  close() {
    const _self = this;
    _self.modalController.dismiss({
      dismissed: true,
    });
  }

  dismissModal() {
    const _self = this;
    _self.modalController.dismiss({
      dismissed: true,
      MachinefileUpload: true,
    });
    this.sharedValue.showToast('', 'File Uploaded successfully');
  }

  dismissRoadMapModal() {
    const _self = this;
    _self.modalController.dismiss({
      dismissed: true,
      RoadFileUpload: true
    });
    this.sharedValue.showToast('', 'File Uploaded successfully');
  }

  dismissInitialHazard() {
    const _self = this;
    _self.modalController.dismiss({
      dismissed: true,
      intialUpload: true
    });
    this.sharedValue.showToast('', 'File Uploaded successfully');
  }

  dismissControlMeasure() {
    const _self = this;
    _self.modalController.dismiss({
      dismissed: true,
      controlMeasure: true
    });
    this.sharedValue.showToast('', 'File Uploaded successfully');
  }

  getRoadMapLibraryData() {
    if (isNotEmptyArray(this.libraryManagementUserInfo)) this.libraryManagementUserInfo = []
    const _self = this;
    _self.backendService.getRoadMapDetails().subscribe(res => {
      _self.roadMapUploadData = res;
      this.roadMapUploadData.value.forEach((element) => {
        this.libraryManagementUserInfo.push({
          machineId: element.id,
          machineTitle: element.roadMapName,
          machineType: element.roadMapVersion,
          machineManufacture: element.sectionName,
        })
      });
    }, error => {
      (err) => { }
    });
  }
}
