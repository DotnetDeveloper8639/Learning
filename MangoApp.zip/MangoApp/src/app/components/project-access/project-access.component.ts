import { Component, OnInit } from '@angular/core';
import { ModalController, ToastController } from '@ionic/angular';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';

@Component({
  selector: 'app-project-access',
  templateUrl: './project-access.component.html',
  styleUrls: ['./project-access.component.scss'],
})
export class ProjectAccessComponent implements OnInit {

  constructor(
    public modalController: ModalController,
    public toastController: ToastController,
    public sharedValue: ShareValuesService,
  ) { }

  ngOnInit() { }

  close() {
    const _self = this;
    _self.modalController.dismiss({
      dismissed: true,
    });
  }

  dismissModal() {
    const _self = this;
    _self.modalController.dismiss({
      dismissed: true,
    });
    this.sharedValue.showToast('', 'Request Sent Successfully');
  }

}
