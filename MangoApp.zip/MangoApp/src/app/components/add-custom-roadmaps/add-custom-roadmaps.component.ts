import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ModalController } from '@ionic/angular';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';

@Component({
  selector: 'app-add-custom-roadmaps',
  templateUrl: './add-custom-roadmaps.component.html',
  styleUrls: ['./add-custom-roadmaps.component.scss'],
})
export class AddCustomRoadmapsComponent implements OnInit {
  // customRoadmapName:string;
  newMachinesList: any[] = [{}];
  constructor(public modalController: ModalController, public backendService: BackendCallService, public sharedValue: ShareValuesService,) {

  }

  ngOnInit() { }

  close() {
    this.modalController.dismiss()
  }
  submit(form: NgForm) {
    if (form.value) {
      const roadmaps = []
      const roadmapsList = []
      roadmaps.push(...Object.values(form.value));
      for (let each of roadmaps) {
        const dataObj = {
          roadMapName: each.customRoadmap,
          roadMapVersion: "",
          description: "",
          version: "",
          isCustom:true
        }
        roadmapsList.push(dataObj)
      }
      console.log(form.value, roadmaps, roadmapsList);
      const payload = roadmapsList
      this.backendService
        .addCustomRoadmap(payload)
        .subscribe(
          (data: any) => {
            console.log('addCustomRoadmap API called', data);
            this.sharedValue.showToast('', data.value);
          },
          (err) => {
          }
        );
    }
    this.modalController.dismiss(form.value)
  }
}
