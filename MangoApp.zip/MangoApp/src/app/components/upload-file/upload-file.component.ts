import { Component, OnInit } from '@angular/core';
import { ModalController, ToastController, AlertController } from '@ionic/angular';
import { libraryManagementUserInfo } from '../../modals/libraryManagementdata';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as XLSX from 'xlsx';
import { isNotEmptyArray } from 'src/app/utilities/utils';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
type AOA = any[][];

@Component({
  selector: 'app-upload-file',
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.scss'],
})
export class UploadFileComponent implements OnInit {
  libraryData = [];
  librarybindData: any;
  isShowButton: any;
  isSubmitDone: any;
  isShowStepper: boolean = false;
  isButtonEnable: boolean = false;
  isDoneButtonEnable: boolean = false;
  isUploadEnable: boolean = false;
  Next: boolean = false;
  Done: boolean = false;
  isShowlabel: boolean = false
  file: any;
  machineName: any;
  machinetype: any;
  manufacturer: any;
  fileSource: any;
  selectedFile: File | null = null;
  fileToUpload: any;

  selectedStepperValue = "selectType";
  myForm = new FormGroup({
    file: new FormControl('', [Validators.required]),
  });
  data: AOA = [[1, 2], [3, 4]];
  wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
  fileName: string = 'SheetJS.xlsx';


  constructor(
    public modalController: ModalController,
    public backendService: BackendCallService,
    public sharedService: ShareValuesService,
    public toastController: ToastController,
    public alert: AlertController
  ) { }

  ngOnInit() {
    this.libraryData = libraryManagementUserInfo;
  }

  close() {
    const _self = this;
    _self.modalController.dismiss({
      dismissed: true,
    });
  }

  onClickNext() {
    this.isShowStepper = true;
    this.librarybindData = this.libraryData.forEach((element) => {
      console.log('value', element.title)
      this.librarybindData = element.title;
    });
    this.isUploadEnable = true;
    this.Done = true;
  }

  dismissModal() {
    const _self = this;
    _self.modalController.dismiss({
      dismissed: true,
    });
    this.sharedService.showToast('', 'File Uploaded successfully');
  }

  fileUpload(files: FileList) {
    this.fileToUpload = files.item(0);
    console.log('file', this.fileToUpload)
  }

  async submitFile() {
    let formData = new FormData();
    formData.append('file', this.fileSource);
    console.log('file', this.fileSource);
    this.backendService.uploadDocument(formData).subscribe(
      (data: any) => {
        if (data && data.value) {
          console.log('Result', Response)
        } else if (data.statusCode == 201) {
          const noDataFond = data.returnText
        }
      }
    );
  }

  uploadFileToServer() {
    this.backendService.uploadDocument(this.fileToUpload).subscribe(data => {
      // do something, if upload success
    }, error => {
      console.log(error);
    });
  }


  changeButtonEvent(event) {
    if (!this.isShowButton) {
      this.isButtonEnable = false;
    }
    else {
      this.isButtonEnable = true
    };
  }

  onFileChange(event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.myForm.patchValue({
        fileSource: file
      });
    }
  }
  isDoneSubmit(event){
    if (!this.isSubmitDone) {
      this.isDoneButtonEnable = false;
    }
    else {
      this.isDoneButtonEnable = true
    };
  }
}


