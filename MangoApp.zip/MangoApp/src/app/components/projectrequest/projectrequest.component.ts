import { Component, OnInit } from '@angular/core';
import { ModalController, ToastController } from '@ionic/angular';
import { projectAccessInfo } from '../../modals/user-data';

@Component({
  selector: 'app-projectrequest',
  templateUrl: './projectrequest.component.html',
  styleUrls: ['./projectrequest.component.scss'],
})
export class ProjectrequestComponent implements OnInit {
  projectAccessData = projectAccessInfo;
  projectAccess = [];

  constructor(public modalController: ModalController) { }

  ngOnInit() { }

  ionViewWillEnter() {
    this.getProjectAccessInfo();
  }

  close() {
    const _self = this;
    _self.modalController.dismiss({
      dismissed: true,
    });
  }

  getProjectAccessInfo() {
    this.projectAccess = this.projectAccessData;
  }

}
