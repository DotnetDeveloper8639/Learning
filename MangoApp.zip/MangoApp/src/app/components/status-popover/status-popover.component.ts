import { Component, Input, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { ModalController, PopoverController } from '@ionic/angular';
import { SearchModalComponent } from 'src/app/components/search-modal/search-modal.component';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { AlertModalPage } from 'src/app/components/alert-modal/alert-modal.page';
import { TranslateService } from "@ngx-translate/core";
import { TranslateModule } from '@ngx-translate/core';
import { LanguageSupportService } from 'src/app/services/language-support.service';
import { AuthCookieManagerService } from 'src/app/services/auth-cookie-manager/auth-cookie-manager.service';
import { authCookieKey } from 'src/app/utilities/constant';
import { UserAuthService } from 'src/app/services/user-auth/user-auth.service';
import { LocalSettingsService } from 'src/app/services/local-settings/local-settings.service';
@Component({
  selector: 'app-status-popover',
  templateUrl: './status-popover.component.html',
  styleUrls: ['./status-popover.component.scss'],
})
export class StatusPopoverComponent implements OnInit {
  @Input() type: string;
  @Input() projectStatus: string;
  @Input() viewServiceDetails: any;
  @Input() offerDetail: any;
  @Input() offer_id: any;
  @Input() each_service: any;
  @Input() isFourEyeRequested: boolean = false;
  selectedUsers: any = [];
  msg: any;
  selectedLanguage: any;
  private shouldDisableEditProjectButton: boolean = false;
  private shouldDisableDeleteProjectButton: boolean = false;
  constructor(
    public modalController: ModalController,
    public popoverController: PopoverController,
    public router: Router,
    public backendService: BackendCallService,
    public sharedValue: ShareValuesService,
    public translateService: TranslateService,
    private tModule: TranslateModule, private serviceMulti: LanguageSupportService,
    public authCookieManagerService: AuthCookieManagerService,
    public userAuthService: UserAuthService,
    public localStorageService: LocalSettingsService
  ) { this.selectedLanguage = this.serviceMulti.getDefaultLanguage(); }

  ngOnInit() { }

  ionViewWillEnter() {
    if (this.projectStatus == "yet to start") this.shouldDisableDeleteProjectButton = true;
    else if (this.projectStatus == 'block' || this.projectStatus == 'blocked') this.shouldDisableEditProjectButton = true;
  }

  selectType(type) {
    console.log(type)
    type == 'assign' || type == 'edit' || type == 'delete'
      ? this.openSearchModal(type)
      : type == 'add-new-machine' || type == 'add-from-library'
        ? this.addMachine(type)
        : this.popoverController.dismiss(type);
  }

  selectOption(type) {
    //console.log(type);
    type == 'editProj' || type == 'deleteProj' || type == 'blockProj' || type == 'closeProj' || type == 'releaseProj'
      ? this.closeBox(type) :
      this.popoverController.dismiss(type)
  }

  selectOfferType(type) {
    // console.log('select offer type', type);
    if (type == 'Review Offer') {
    } else if (type == 'Hold Offer') {
    } else if (type == 'Edit Offer') {
    } else if (type == 'Assign To') {
    }
  }

  viewOfferPopOver(type) {
    console.log('viewOfferPopOver', type);
    if (type == 'edit-offer') {
    } else if (type == 'delete-offer') {
      this.offerDelete();
      // var payload = [this.offer_id];
      // this.backendService.deleteOffer(payload).subscribe(
      //   (data: any) => {
      //     console.log('deleteOffer API called', data);
      //     this.popoverController.dismiss(type);
      //     this.sharedValue.showToast('', data.value);
      //     this.router.navigate(['offer-management']);
      //   },
      //   (err) => { }
      // );
    }
  }

  listOfServiceMore(type) {
    if (type == 'edit-service') {
      this.popoverController.dismiss(type);
    } else if (type == 'delete-service') {
      var payload = [this.viewServiceDetails.service_id];
      this.backendService.deleteOfferService(payload).subscribe(
        (data: any) => {
          this.popoverController.dismiss(this.viewServiceDetails);
          this.sharedValue.showToast('', data.value);
          // this.router.navigate(['offer-management']);
        },
        (err) => { }
      );
    } else if (type == 'In-Active') {
    }
  }
  addMachine(type) {
    console.log('addMachine', type);
    let navigationExtras: NavigationExtras = {
      state: {
        each_service: this.each_service,
      },
    };
    if (type == 'add-new-machine') {
      this.router.navigate(['offer-management/add-machine'], navigationExtras);
      this.popoverController.dismiss();
    } else if (type == 'add-from-library') {
      this.router.navigate(
        ['offer-management/add-from-library'],
        navigationExtras
      );
      this.popoverController.dismiss();
    }
    // if (type == 'edit-offer' || type == 'delete-offer') {
    //   this.router.navigate(['view-offer/create-offer']);
    //   this.popoverController.dismiss(type);
    // } else {
    //   let navigationExtras: NavigationExtras = {
    //     state: {
    //       each_service: this.each_service,
    //     },
    //   };
    //   this.router.navigate(['offer-management/add-machine'], navigationExtras);
    //   this.popoverController.dismiss();
    // }
  }

  async openSearchModal(type) {
    let props = { type };
    console.log(this.type);
    const modal = await this.modalController.create({
      component: SearchModalComponent,
      cssClass: 'my-custom-class',
      backdropDismiss: true,
      componentProps: props,
      showBackdrop: false,
    });
    await modal.present();
    await modal.onDidDismiss().then((result) => {
      result.data.selectedUsers
        ? (this.selectedUsers = result.data.selectedUsers)
        : (this.selectedUsers = []);
      this.popoverController.dismiss(this.selectedUsers);
    });
  }

  myMachinesSegmentAddBucketButton(type) {
    this.popoverController.dismiss(type);
  }

  async closeBox(type) {
    let props = { type };
    if (type == 'editProj') {
      this.msg = `Are You Sure You Want to edit Project?`;
    }
    else if (type == 'deleteProj') {
      this.msg = `Are You Sure You Want to Delete this Project?`;
    }
    else if (type == 'blockProj') {
      this.msg = `Are You Sure You Want to Block this Project ?`;
    }
    else if (type == 'releaseProj') {
      this.msg = `Are You Sure You Want to Release this Project ?`;
    }
    else if (type == 'closeProj') {
      this.msg = `Are You Sure You Want to Close this Project ?`;
    }
    else if (type == 'deleteOffer') {
      this.msg = `Are You Sure You Want to Delete this Offer ?`;
    }
    props['alertContent'] = this.msg;
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const { data } = await modal.onWillDismiss();
    let info;
    if (data && data.isConfirmed) info = type
    this.popoverController.dismiss(info);
  }

  async offerDelete() {
    let props = {
      isViewOfferDelete: true
    };
    const msg = `Are You Sure You Want to Delete Offer ?`;
    props['alertContent'] = msg;
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const {
      data: { isOfferCreationConfirmClose },
    } = await modal.onWillDismiss();
    if (isOfferCreationConfirmClose)
      this.popoverController.dismiss();
    this.offerDel();
  }


  offerDel() {
    var payload = [this.offer_id];
    this.backendService.deleteOffer(payload).subscribe(
      (data: any) => {
        console.log('deleteOffer API called', data);
        this.popoverController.dismiss();
        this.sharedValue.showToast('', data.value);
        this.router.navigate(['offer-management']);
      },
      (err) => { }
    );
  }

  redirectOffer() {
    this.popoverController.dismiss();
    this.router.navigate(['offer-management/create-offer']);
  }

  languageChange() {
    this.serviceMulti.setLanguage(this.selectedLanguage);
    this.popoverController.dismiss("openChangeLan");
  }

  logOut() {
    let cookieInfo = this.authCookieManagerService.read(authCookieKey);
    if (cookieInfo) this.authCookieManagerService.remove(authCookieKey);
    this.localStorageService.clearAllLocalStorageInfo();
    this.userAuthService.logOut();
  }

  async logOutModalConfirmation() {
    let props = { alertContent: `Are You Sure You Want to Logout ?` };
    const modal = await this.modalController.create({
      component: AlertModalPage,
      cssClass: 'mango-alert-modal',
      backdropDismiss: false,
      showBackdrop: false,
      componentProps: props,
    });
    await modal.present();
    const { data: { isConfirmed } } = await modal.onWillDismiss();
    if (isConfirmed) {
      this.popoverController.dismiss();
      this.logOut();
    }
  }
}
