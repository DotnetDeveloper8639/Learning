import { Component, Input, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';
import { FormData } from '../../pages/risk-assessment-sections/roadmap-interface';
@Component({
  selector: 'app-riskassessment-accordion',
  templateUrl: './riskassessment-accordion.component.html',
  styleUrls: ['./riskassessment-accordion.component.scss'],
})
export class RiskassessmentAccordionComponent implements OnInit {
  @Input() sectionName: string;
  @Input() subSectionName: string;
  @Input() subSectionSteps: any = [];
  @Input() isCustom: string;
  @Input() roadMapName: string;
  isListItemOpened: boolean = false;
  files = [];
  imageSrc: any;
  constructor(private router: Router, private domSanitizer: DomSanitizer, private sharedValue: ShareValuesService) {
    setTimeout(() => {
      console.log('accordion is:', this.subSectionName, this.subSectionSteps);  // You will get the @Input value
    });
  }

  ngOnInit() { }

  toggleAccordion(step): void {
    step.isListItemOpened = !step.isListItemOpened;
  }

  addHazardDetails(index, step) {
    console.log(step);
    if(step.stepBody){
      const data = { sectionName: this.sectionName, subSectionName: this.subSectionName, index: index ,roadMapName:this.roadMapName}
      let navigationExtras: NavigationExtras = {
        queryParamsHandling: 'preserve',
        skipLocationChange: true,
        state: {
          sectionData: data,
          hazardData: step
        },
      };
      this.router.navigate([window.location.pathname, 'add-hazard-details'], navigationExtras)
    } else {
      this.sharedValue.errorShowToast("", "Please complete all the mandatory Fields")
    }

  }
  markAsComplete(step) {
    step.isListItemOpened = !step.isListItemOpened;
  }

  uploadFile(fileChangeEvent) {
    const self = this;
    if (fileChangeEvent.target.files && fileChangeEvent.target.files[0]) {
      const file = fileChangeEvent.target.files[0];
      const reader = new FileReader();
      reader.onload = e => {
        self.imageSrc = reader.result
        self.files.push(self.imageSrc);
      };
      console.log(self.imageSrc, reader.result);
      reader.readAsDataURL(file);

    }
    console.log("fileChangeEvent", fileChangeEvent, fileChangeEvent.target.files[0].name, this.files);
  }

}
