import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { SideNavComponent } from './side-nav/side-nav.component';
import { StatusPopoverComponent } from './status-popover/status-popover.component';
import { SearchModalComponent } from './search-modal/search-modal.component';
import { AlertModalPage } from './alert-modal/alert-modal.page';
import { AddRemoveColumnSelectorComponent } from './add-remove-column-selector/add-remove-column-selector.component';
import { RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { NotificationComponent } from './notification/notification.component';
import { AddMachineToBucketComponent } from './add-machine-to-bucket/add-machine-to-bucket.component';
import { UploadFileComponent } from './upload-file/upload-file.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { FilterMoodalComponent } from './filter-moodal/filter-moodal.component';
import { UploadMachineDocComponent } from './upload-machine-doc/upload-machine-doc.component';
import { NgPipesModule } from 'ngx-pipes';
// import {AngularFileDragDropModule} from '../../projects/file-drag-drop/src/lib/angular-file-drag-drop.module';
import { AddCustomRoadmapsComponent } from './add-custom-roadmaps/add-custom-roadmaps.component';
import { ProjectAccessComponent } from './project-access/project-access.component';
import { ProjectrequestComponent } from './projectrequest/projectrequest.component';
import { RiskassessmentAccordionComponent } from './riskassessment-accordion/riskassessment-accordion.component';
import { AddCustomSectionsComponent } from './add-custom-sections/add-custom-sections.component';
import { TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import { PickHazardComponent } from './pick-hazard/pick-hazard.component';
import { PlrScreenComponent } from './plr-screen/plr-screen.component';
import { SearchFilterPipe } from '../components/pick-hazard/pick-hazard.component';
import { ViewOpportunitiesComponent } from '../components/view-opportunities/view-opportunities.component'
// import { NgPipesModule } from 'ngx-pipes';

@NgModule({
  declarations: [
    SideNavComponent,
    HeaderComponent,
    StatusPopoverComponent,
    AlertModalPage,
    SearchModalComponent,
    AddRemoveColumnSelectorComponent,
    NotificationComponent,
    AddMachineToBucketComponent,
    UploadFileComponent,
    FilterMoodalComponent,
    RiskassessmentAccordionComponent,
    UploadMachineDocComponent,
    AddCustomRoadmapsComponent,
    ProjectAccessComponent,
    ProjectrequestComponent,
    AddCustomSectionsComponent,
    PickHazardComponent,
    PlrScreenComponent,
    SearchFilterPipe,
    ViewOpportunitiesComponent
  ],
  exports: [SideNavComponent, HeaderComponent, RiskassessmentAccordionComponent, ViewOpportunitiesComponent],
  imports: [FormsModule, CommonModule, RouterModule, IonicModule, NgSelectModule, NgPipesModule, TranslateModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class componentModule { }
export function httpTranslateLoader(http: HttpClient): TranslateHttpLoader {
  return new TranslateHttpLoader(http);
}
