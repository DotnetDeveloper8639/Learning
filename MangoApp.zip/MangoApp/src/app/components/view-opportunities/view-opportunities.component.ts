import { Component, OnInit } from '@angular/core';
import { ModalController, ToastController } from '@ionic/angular';
import { isNotEmptyArray } from 'src/app/utilities/utils';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { element } from 'protractor';

@Component({
  selector: 'app-view-opportunities',
  templateUrl: './view-opportunities.component.html',
  styleUrls: ['./view-opportunities.component.scss'],
})
export class ViewOpportunitiesComponent implements OnInit {
  opporData: any;
  getOpportDataList = [];
  opportunityId: any;
  companyName: any;
  status: any;

  constructor(public modalController: ModalController, public backendService: BackendCallService) { }

  ngOnInit() { }

  ionViewWillEnter() {
    this.getOpportunities();
  }

  close() {
    const _self = this;
    _self.modalController.dismiss({
      dismissed: true,
    });
  }

  getOpportunities() {
    if (isNotEmptyArray(this.getOpportDataList)) this.getOpportDataList = []
    const _self = this;
    this.getOpportDataList = [];
    _self.backendService.getOpportunitiesData().subscribe(res => {
      _self.opporData = res;
      this.opporData.value.forEach((element) => {
        this.getOpportDataList.push({
          oppoId: element.opportunityId,
          companyName: element.customer_Name,
          status: element.status,
        })
      });
      console.log('data', this.getOpportDataList)
    }, error => {
      (err) => { }
    });
    //   if (isNotEmptyArray(this.getOpportDataList)) this.getOpportDataList = []
    //   this.backendService.getOpportunitiesData().subscribe(res => {
    //     this.opporData = res;
    //     this.opporData.value.forEach((element) => {
    //       this.getOpportDataList.push({
    //         oppoId: element.opportunityId,
    //         companyName: element.customerName,
    //         status: element.status,
    //         //roadMapSectionName: element.sectionName,
    //       })
    //     console.log('data', this.getOpportDataList)
    //   }, error => {
    //     (err) => { }
    //   });
    // }
  }

}
