import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ModalController } from '@ionic/angular';
import { BackendCallService } from 'src/app/services/backend-call/backend-call.service';
import { ShareValuesService } from 'src/app/services/sharedValues/share-values.service';

@Component({
  selector: 'app-add-custom-sections',
  templateUrl: './add-custom-sections.component.html',
  styleUrls: ['./add-custom-sections.component.scss'],
})
export class AddCustomSectionsComponent implements OnInit {
  newSectionList: any[] = [{}];
  @Input() type: string;
  @Input() roadmapId: string;
  @Input() roadMapSectionId: string;
  @Input() isExtended:boolean
  constructor(public modalController: ModalController, public backendService: BackendCallService, public sharedValue: ShareValuesService,) { }

  ngOnInit() { }

  close() {
    this.modalController.dismiss()
  }
  submit(form: NgForm) {
    // const sectionsList=[];
    if (form.valid) {

      // const sections=[]
      // sections.push(...Object.values(form.value));
      // console.log(form.value,this.type);
      if (this.type == "Section") {
        const sectionsList = Object.values(form.value).map((each: any) => {
          return {
            roadMapMasterId: this.roadmapId,
            sectionName: each.section
          }
        });
        this.modalController.dismiss(sectionsList);
        // for (let each of sections) {
        //   const dataObj = {
        //       roadMapMasterId: this.roadmapId,
        //       sectionName: each.section
        //   }
        //   sectionsList.push(dataObj)
        // }
        // console.log(form.value, sections, sectionsList);
        // const payload = sectionsList
        // this.backendService
        //   .addCustomsection(payload)
        //   .subscribe(
        //     (data: any) => {
        //       console.log('addCustomRoadmap API called', data);
        //       this.sharedValue.showToast('', data.value);
        //       this.modalController.dismiss(sectionsList)
        //     },
        //     (err) => {
        //     }
        //   );
      } else if (this.type == "Sub Section") {
        const sectionsList = Object.values(form.value).map((each: any) => {
          return {
            roadMapSectionId: this.roadmapId,
            subSectionName: each.section
          }
        });
        this.modalController.dismiss(sectionsList);
        //   for (let each of sections) {
        //     const dataObj = {
        //         roadMapSectionId: this.roadMapSectionId,
        //         subSectionName: each.section
        //     }
        //     sectionsList.push(dataObj)
        //   }
        //   console.log(form.value, sections, sectionsList);
        //   const payload = sectionsList
        //   this.backendService
        //     .addCustomSubSection(payload)
        //     .subscribe(
        //       (data: any) => {
        //         console.log('addCustomRoadmap API called', data);
        //         this.sharedValue.showToast('', data.value);
        //         this.modalController.dismiss(sectionsList)
        //       },
        //       (err) => {
        //       }
        //     );
        //  }
      }else if (this.type == "Change Roadmap Name") {
        
        const data={type:"Change Roadmap Name",name:form.value}
        console.log("Change Roadmap Name",form.value,data);
        this.modalController.dismiss(data);
      }

    } else {
      console.log(form);

      form.form.markAllAsTouched();
    }

  }
  scrollSection(ionBtn){
    setTimeout(() => {
      (ionBtn.el as HTMLElement).scrollIntoView({behavior:'smooth'});
    }, 100);

  }

}
