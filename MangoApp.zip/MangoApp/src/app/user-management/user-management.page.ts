import { Component, OnInit } from '@angular/core';
import { ModalController, PopoverController } from '@ionic/angular';
import { SearchModalComponent } from '../components/search-modal/search-modal.component';
import { StatusPopoverComponent } from '../components/status-popover/status-popover.component';
import { userManagementUserInfo, roleManagementUserInfo, roleManagementAllRoles, groupManagementAllGroups } from '../modals/user-data';
import { BackendCallService } from '../services/backend-call/backend-call.service';
import { ShareValuesService } from '../services/sharedValues/share-values.service';
import { isNotBlank, isNotEmptyArray, isNotNullAndUndefined, isObjectEmpty } from '../utilities/utils';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.page.html',
  styleUrls: ['./user-management.page.scss'],
})
export class UserManagementPage implements OnInit {
  sideNav: string = 'um';
  selectedUserManagemnetConsole = 'user';
  userManagementAllUserInfo = [];
  bk_userManagementAllUserInfo = [];
  roleManagementAllUserInfo = [];
  roleManagementUsersAssignRoles = [];
  bk_roleManagementUsersAssignRoles = [];
  roleManagementUsersAllRoles = [];
  bk_roleManagementUsersAllRoles = [];
  roleManagementUiToDisplay = 'all-roles';
  groupManagementUsers = [];
  bk_groupManagementUsers = [];
  searchUserInput: any;
  isUsersSearchbarExpand: boolean = false;;
  constructor(
    public modalController: ModalController,
    public popoverController: PopoverController,
    public backendCallService: BackendCallService,
    public sharedService: ShareValuesService
  ) { }

  ngOnInit() { }

  ionViewWillEnter() {
    this.roleManagementAllUserInfo = roleManagementUserInfo.filter(_rmaui => _rmaui.role)
    this.initializeUserConsole();
  }

  async initializeUserConsole() {
    await this.getAllUsersInfo();
    await this.getAllRoles();
    await this.getAllRoleAssignments();
    await this.getAllGroups();
  }

  getAllUsersInfo() {
    return this.backendCallService.getAllUsers().then(_user => {
      const { Data } = _user
      if (isNotEmptyArray(Data)) {
        this.userManagementAllUserInfo = Data;
        this.bk_userManagementAllUserInfo = JSON.parse(JSON.stringify(this.userManagementAllUserInfo));
      }
    }).catch(err => {
      console.log('Issue in fetching all users:', err);
    })
  }

  getAllRoles() {
    return this.backendCallService.getAllRoles().then(_roles => {
      const { Data } = _roles
      if (isNotEmptyArray(Data)) {
        this.roleManagementUsersAllRoles = Data;
        this.bk_roleManagementUsersAllRoles = JSON.parse(JSON.stringify(this.roleManagementUsersAllRoles));
      }
    }).catch(err => {
      console.log('Issue in fetching all roles:', err);
    })
  }

  getAllRoleAssignments() {
    return this.backendCallService.getAllRoleAssignments().then(_rAssignments => {
      const { Data } = _rAssignments
      if (isNotEmptyArray(Data)) {
        this.roleManagementUsersAssignRoles = Data;
        this.roleManagementUsersAssignRoles.forEach(_ra => {
          if (isNotEmptyArray(_ra.Roles)) {
            _ra.Roles.forEach(_rar => {
              if (_ra['allAssignedRoles']) _ra['allAssignedRoles'] = _ra.allAssignedRoles + ',' + ' ' + _rar.role_name
              else _ra['allAssignedRoles'] = _rar.role_name
            })
          }
        })
        this.bk_roleManagementUsersAssignRoles = JSON.parse(JSON.stringify(this.roleManagementUsersAssignRoles));
      }
    }).catch(err => {
      console.log('Issue in fetching all role assignnments:', err);
    })
  }

  getAllGroups() {
    return this.backendCallService.getAllGroupsWithCount().then(_groups => {
      const { Data } = _groups
      if (isNotEmptyArray(Data)) {
        this.groupManagementUsers = Data;
        this.bk_groupManagementUsers = JSON.parse(JSON.stringify(this.groupManagementUsers));
      }
    }).catch(err => {
      console.log('Issue in fetching all groups:', err);
    })
  }

  selectdUserConsole(event, userType) {
    event.stopPropagation();
    if (userType == 'user') this.selectedUserManagemnetConsole = 'user';
    if (userType == 'role') this.selectedUserManagemnetConsole = 'role';
    if (userType == 'group') this.selectedUserManagemnetConsole = 'group';
    if (this.searchUserInput) this.resetAllInfo();
  }

  async openAddUserModal() {
    const type = this.getModalType();
    let props = { type };
    const modal = await this.modalController.create({
      component: SearchModalComponent,
      cssClass: 'my-custom-class',
      backdropDismiss: false,
      componentProps: props,
      showBackdrop: false,
    });
    await modal.present();
    await modal.onDidDismiss().then((result) => {
      const {
        data: { groupName, newRole, roleToAssign, modeType, selectedUsers },
      } = result;
      if (modeType == 'user_console_add_user' && isNotEmptyArray(selectedUsers)) {
        this.addNewUsers(selectedUsers);
      } else if (modeType == 'user_console_group_mang_add_group' && groupName && isNotEmptyArray(selectedUsers)) {
        this.addUserConsoleGroupManagementGroups(groupName, selectedUsers);
      } else if (modeType == 'user_console_role_mang_all_roles' && newRole) {
        this.addUserConsoleRoleManagmentNewRole(newRole);
      } else if (modeType == 'user_console_role_mang_assign_user_role' && roleToAssign && isNotEmptyArray(selectedUsers)) {
        this.assignRoleToUsers(roleToAssign, selectedUsers);
      }
    });
  }

  getModalType() {
    let type = 'user_console_add_user';
    if (this.selectedUserManagemnetConsole == 'role') {
      if (this.roleManagementUiToDisplay == 'all-roles') type = 'user_console_role_mang_all_roles'
      else type = 'user_console_role_mang_assign_user_role'
    } else if (this.selectedUserManagemnetConsole == 'group') type = 'user_console_group_mang_add_group'
    return type
  }

  addNewUsers(users) {
    const usersInfo = this.sharedService.initialzeNewUsersToAdd(users);
    this.backendCallService.addNewUsersToAd(usersInfo).then(res => {
      if (res && res.Data && res.StatusCode == 200) {
        this.sharedService.showToast('', 'User Added Successfully.');
        setTimeout(() => { this.getAllUsersInfo() }, 3000);
      }
    }).catch(err => {
      console.log('Getting issue in adding user to ad :', err);
    })
  }

  addUserConsoleGroupManagementGroups(groupName, selectedUsers) {
    if (isNotBlank(groupName) && isNotNullAndUndefined(groupName) && isNotEmptyArray(selectedUsers)) {
      let groupListsInfo = this.sharedService.initializeGroupManagementInfoToAdd(groupName, selectedUsers);
      if (groupListsInfo && isNotBlank(groupListsInfo.group.group_name) && isNotNullAndUndefined(groupListsInfo.group.group_name) && isNotEmptyArray(groupListsInfo.users)) {
        this.backendCallService.createGroupAndAddUsers(groupListsInfo).then(res => {
          if (res && res.Data) {
            this.sharedService.showToast('', `Group Created and ${groupListsInfo.users.length > 1 ? 'Users' : 'User'} Added Successfully.`);
            setTimeout(() => { this.getAllGroups() }, 3000)
          }
        }).catch(err => {
          console.log('getting issue in creating group and adding users :', err);
        })
      }
    }
  }

  addUserConsoleRoleManagmentNewRole(newRole) {
    if (newRole) {
      let role = { role_name: newRole }
      this.backendCallService.addNewRole(role).then(res => {
        if (res && res.Data) {
          this.sharedService.showToast('', 'New Role Created Successfully.');
          setTimeout(() => { this.getAllRoles() }, 3000)
        }
      }).catch(err => {
        console.log('getting issue in adding new role :', err);
        const { error: { Data, StatusCode, StatusReason } } = err;
        if (!Data && StatusCode == 400 && StatusReason == 'Role name already exists.') this.sharedService.errorShowToast('', StatusReason);
      })
    }
  }

  assignRoleToUsers(roleId, users) {
    if (isNotBlank(roleId) && isNotNullAndUndefined(roleId) && isNotEmptyArray(users)) {
      let roleAssignmentInfo = this.sharedService.initalizeRoleAssignments(roleId, users);
      if (!isObjectEmpty(roleAssignmentInfo) && roleAssignmentInfo.roleId && isNotEmptyArray(roleAssignmentInfo.users)) {
        this.backendCallService.assignRoleToUsers(roleAssignmentInfo).then(_res => {
          if (_res && _res.Data) {
            this.sharedService.showToast('', 'Role Assigned Successfully.');
            setTimeout(() => { this.getAllRoleAssignments() }, 3000);
          }
        }).catch(err => {
          console.log('getting issue in assigning role to users :', err);
        })
      }
    }
  }

  userConsoleRoleMangDropdownArrow(event, type) {
    event.stopPropagation();
    this.openStatusPopover(event, type);
  }

  async openStatusPopover(ev: any, type, task?) {
    let props = { type };
    const popover = await this.popoverController.create({
      component: StatusPopoverComponent,
      cssClass: 'my-custom-class',
      event: ev,
      translucent: true,
      componentProps: props,
      showBackdrop: false,
      // mode: 'ios',
    });
    await popover.present();
    await popover.onDidDismiss().then((result) => {
      const { data } = result;
      if (data) {
        this.roleManagementUiToDisplay = data;
        this.searchUserInput && this.resetAllInfo();
      }
    });
  }

  apperUserSearchBar() {
    this.isUsersSearchbarExpand = !this.isUsersSearchbarExpand;
  }

  searchUserManagementLists() {
    let value = this.searchUserInput;
    if (this.selectedUserManagemnetConsole == 'user') this.searchRelatedToUser(value);
    else if (this.selectedUserManagemnetConsole == 'role') {
      if (this.roleManagementUiToDisplay == 'all-roles') this.searchRelatedToAllRoles(value);
      else if (this.roleManagementUiToDisplay == 'assign-user-role') this.searchRelatedToAssignUserRole(value);
    } else if (this.selectedUserManagemnetConsole == 'group') this.searchRelatedToGroup(value);
  }

  searchRelatedToUser(searchWord) {
    if (searchWord && isNotEmptyArray(this.bk_userManagementAllUserInfo)) {
      this.userManagementAllUserInfo = this.bk_userManagementAllUserInfo.filter(_bumali => {
        return (
          (_bumali.First_Name.toLowerCase().indexOf(searchWord.toLowerCase())) > -1 ||
          (_bumali.Last_Name.toLowerCase().indexOf(searchWord.toLowerCase())) > -1
        );
      })
    } else this.resetUserListsInfo();
  }

  searchRelatedToAllRoles(searchWord) {
    if (searchWord && isNotEmptyArray(this.bk_roleManagementUsersAllRoles)) {
      this.roleManagementUsersAllRoles = this.bk_roleManagementUsersAllRoles.filter(_brmuar => {
        return (
          (_brmuar.role_name.toLowerCase().indexOf(searchWord.toLowerCase())) > -1
        );
      })
    } else this.resetAllRolesInfo()
  }

  searchRelatedToAssignUserRole(searchWord) {
    if (searchWord && isNotEmptyArray(this.bk_roleManagementUsersAssignRoles)) {
      this.roleManagementUsersAssignRoles = this.bk_roleManagementUsersAssignRoles.filter(_brmuar => {
        return (
          (_brmuar.UserName.toLowerCase().indexOf(searchWord.toLowerCase())) > -1 ||
          (_brmuar.allAssignedRoles.toLowerCase().indexOf(searchWord.toLowerCase())) > -1
        );
      })
    } else this.resetRoleAssignmentInfo()
  }

  searchRelatedToGroup(searchWord) {
    if (searchWord && isNotEmptyArray(this.bk_groupManagementUsers)) {
      this.groupManagementUsers = this.bk_groupManagementUsers.filter(_bgmu => {
        return (
          (_bgmu.group_name.toLowerCase().indexOf(searchWord.toLowerCase())) > -1 ||
          (_bgmu.UserCount.toString().toLowerCase().indexOf(searchWord)) > -1
        );
      })
    } else this.resetGroupInfo()
  }

  resetUserListsInfo() {
    this.userManagementAllUserInfo = this.bk_userManagementAllUserInfo
  }

  resetAllRolesInfo() {
    this.roleManagementUsersAllRoles = this.bk_roleManagementUsersAllRoles;
  }

  resetRoleAssignmentInfo() {
    this.roleManagementUsersAssignRoles = this.bk_roleManagementUsersAssignRoles;
  }

  resetGroupInfo() {
    this.groupManagementUsers = this.bk_groupManagementUsers
  }

  resetAllInfo() {
    if (this.searchUserInput) {
      this.resetUserListsInfo();
      this.resetAllRolesInfo();
      this.resetRoleAssignmentInfo();
      this.resetGroupInfo();
    }
    this.searchUserInput = '';
  }
}
